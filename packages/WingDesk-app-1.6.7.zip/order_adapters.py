"""Order reads normalized without rounding marketplace identifiers.

Writes are deliberately limited to the documented Coupang/Naver fulfilment
operations. Other marketplaces retain read-only API collection in this release.
"""
from __future__ import annotations
import json,re,threading
from datetime import date,datetime,timedelta
from decimal import Decimal,InvalidOperation
from urllib.parse import quote
from core import KST,now,Uncertain,RemoteRejected

STATUS={'ACCEPT':'신규','INSTRUCT':'상품 준비','DEPARTURE':'배송 중','DELIVERING':'배송 중','FINAL_DELIVERY':'배송 완료','NONE_TRACKING':'배송 중',
 'PAYED':'신규','PAYMENT_WAITING':'결제 대기','DELIVERED':'배송 완료','PURCHASE_DECIDED':'구매 확정','CANCELED':'취소','RETURNED':'반품','EXCHANGED':'교환',
 'ShippingRequest':'신규','ShippingWaiting':'상품 준비','ShippingProgress':'배송 중','ShippingComplete':'배송 완료','PayCancelComplete':'취소',
 'BuyDecision':'구매 확정','PayComplete':'신규','PayWaiting':'결제 대기','ReturnRefundComplete':'반품','ReturnCancelComplete':'반품','UnpaidCancelComplete':'취소',
 'BEFORE_PAYMENT':'결제 대기','ShippingCancelComplete':'취소','ExchangeShippingComplete':'교환',
 'PAID':'신규','PREPARING_PRODUCT':'상품 준비','CONFIRMED_ORDER':'구매 확정',
 '1':'신규','2':'상품 준비','3':'배송 중','4':'배송 완료','5':'구매 확정'}

def ident(v):
    if isinstance(v,bool) or isinstance(v,float):raise ValueError('주문번호가 정확하지 않습니다. 숫자 형식 대신 텍스트로 전달해야 합니다.')
    s=str(v or '').strip()
    if not s or len(s)>100 or any(ord(c)<32 for c in s):raise ValueError('주문번호가 누락되었거나 올바르지 않습니다.')
    return s

def money(v):
    if isinstance(v,dict):v=v.get('units',0)
    try:
        n=Decimal(str(v or 0).replace(',',''))
        if not n.is_finite() or abs(n)>10**12:raise ValueError()
        return int(n)
    except (ValueError,InvalidOperation):raise ValueError('주문 금액 형식을 확인하지 못했습니다.') from None

def array(v):
    if not isinstance(v,list):raise ValueError('주문 목록 응답 형식을 확인하지 못했습니다. 기존 내역은 유지됩니다.')
    return v

def obj(v):
    if not isinstance(v,dict):raise ValueError('주문 상세 응답 형식을 확인하지 못했습니다.')
    return v

def item(id,name,option='',quantity=1,total=0,**extra):
    q=money(quantity)
    if q<0 or q>999999:raise ValueError('주문 수량을 확인하지 못했습니다.')
    return dict(id=ident(id),name=str(name or ''),option=str(option or ''),quantity=q,total=money(total),**extra)

def row(id,order_id,status,items,**extra):
    return dict(remote_id=ident(id),order_id=ident(order_id),status=STATUS.get(str(status),'확인 필요'),raw_status=str(status),items=items,
                ordered_at='',receiver='',phone='',zipcode='',address='',orderer='',memo_shipping='',courier='',invoice='',claims=[],blocked=False,**extra)

def date_text(v):
    s=str(v or '')
    if re.fullmatch(r'\d{14}',s):return datetime.strptime(s,'%Y%m%d%H%M%S').isoformat()
    return s

def normalize(m,x):
    x=obj(x)
    if m=='coupang':
        receiver=x.get('receiver') or {};buyer=x.get('orderer') or {};items=[]
        for i in array(x.get('orderItems')):
            items.append(item(i.get('vendorItemId'),i.get('sellerProductName'),i.get('sellerProductItemName') or i.get('vendorItemName'),i.get('shippingCount'),i.get('orderPrice'),cancel=money(i.get('cancelCount')),hold=money(i.get('holdCountForCancel')),canceled=bool(i.get('canceled'))))
        r=row(x.get('shipmentBoxId'),x.get('orderId'),x.get('status'),items)
        r.update(ordered_at=str(x.get('orderedAt') or x.get('paidAt') or ''),receiver=receiver.get('name',''),phone=receiver.get('safeNumber') or receiver.get('receiverNumber',''),zipcode=receiver.get('postCode',''),address=' '.join(str(receiver.get(k) or '') for k in ('addr1','addr2')).strip(),orderer=buyer.get('name',''),memo_shipping=x.get('parcelPrintMessage',''),courier=x.get('deliveryCompanyName',''),invoice=str(x.get('invoiceNumber') or ''),split=bool(x.get('splitShipping') or x.get('preSplitShipped')),shipping=money(x.get('shippingPrice')))
        if r['status']=='배송 완료' and x['orderItems'] and all(i.get('confirmDate') for i in x['orderItems']):r['status']='구매 확정'
        r['blocked']=r['split'] or not items or any(i['cancel'] or i['hold'] or i['canceled'] for i in items)
        return r
    if m=='naver':
        x=x.get('content',x);p=obj(x.get('productOrder'));o=x.get('order') or {};a=p.get('shippingAddress') or {};d=x.get('delivery') or {};c=x.get('currentClaim') or {}
        r=row(p.get('productOrderId'),o.get('orderId') or p.get('orderId'),p.get('productOrderStatus'),[item(p.get('productOrderId'),p.get('productName'),p.get('productOption'),p.get('quantity'),p.get('totalPaymentAmount'))])
        r.update(ordered_at=o.get('orderDate',''),receiver=a.get('name',''),phone=a.get('tel1',''),zipcode=a.get('zipCode',''),address=' '.join(str(a.get(k) or '') for k in ('baseAddress','detailedAddress')).strip(),orderer=o.get('ordererName',''),memo_shipping=p.get('shippingMemo',''),courier=d.get('deliveryCompanyCode',''),invoice=str(d.get('trackingNumber') or ''),place_status=p.get('placeOrderStatus',''))
        claim=p.get('claimType') or c.get('claimType');cs=p.get('claimStatus') or c.get('claimStatus')
        if claim or cs:r['claims']=[dict(type=str(claim or '클레임'),status=str(cs or ''),id=r['remote_id'])];r['blocked']=True
        if p.get('placeOrderStatus')=='OK' and r['status']=='신규':r['status']='상품 준비'
        return r
    if m in ('auction','gmarket'):
        r=row(x.get('OrderNo'),x.get('OrderNo'),x.get('OrderStatus'),[item(x.get('SiteGoodsNo') or x.get('OrderNo'),x.get('GoodsName'),' / '.join(str(i.get('ItemOptionValue') or '') for i in (x.get('ItemOptionSelectList') or [])+(x.get('ItemOptionAdditionList') or [])),x.get('ContrAmount'),x.get('OrderAmount'))])
        r.update(ordered_at=x.get('OrderDate',''),receiver=x.get('ReceiverName',''),phone=x.get('HpNo',''),zipcode=x.get('ZipCode',''),address=' '.join(str(x.get(k) or '') for k in ('DelFrontAddress','DelBackAddress')).strip(),orderer=x.get('BuyerName',''),memo_shipping=x.get('DelMemo',''),courier=x.get('TakbaeName',''),invoice=str(x.get('NoSongjang') or ''))
        return r
    if m=='kakao':
        o=obj(x.get('orderBase'));p=obj(x.get('orderProduct'));a=x.get('orderDeliveryRequest') or {};d=x.get('orderDelivery') or {}
        r=row(x.get('id') or o.get('id'),o.get('paymentId') or o.get('id'),o.get('status'),[item(p.get('id'),p.get('name'),p.get('optionContent'),p.get('quantity'),money(p.get('settlementBasicPrice'))*money(p.get('quantity')))])
        r.update(ordered_at=date_text(o.get('createdAt','')),receiver=a.get('receiverName',''),phone=a.get('receiverMobileNumber',''),zipcode=a.get('zipcode',''),address=' '.join(str(a.get(k) or '') for k in ('receiverAddress1','receiverAddress2')).strip(),memo_shipping=a.get('requirement',''),courier=d.get('deliveryCompanyCode',''),invoice=str(d.get('invoiceNumber') or ''))
        for k,label in [('orderClaimCancel','취소'),('orderClaimReturn','반품'),('orderClaimExchange','교환')]:
            if x.get(k):r['claims'].append(dict(type=label,status=str(x[k].get('claimItemStatus') or x[k].get('status') or '확인 필요'),id=ident(x[k].get('claimId') or r['remote_id']),created_at=date_text(x[k].get('createdAt'))));r['blocked']=True
        if r['raw_status'].startswith('Return'):r['status']='반품'
        elif r['raw_status'].startswith('Exchange'):r['status']='교환'
        elif 'Cancel' in r['raw_status']:r['status']='취소'
        return r
    if m=='toss':
        r=row(x.get('orderProductId'),x.get('orderId'),x.get('orderProductStatus'),[item(x.get('orderProductId'),x.get('productName'),x.get('optionName'),x.get('quantity'),x.get('price'))])
        r.update(ordered_at=x.get('orderedAt',''),receiver=x.get('receiverName',''),phone=x.get('receiverPhone',''),zipcode=x.get('zipCode',''),address=' '.join(str(x.get(k) or '') for k in ('address','detailAddress')).strip(),orderer=x.get('ordererName',''),memo_shipping=x.get('shippingNote',''),courier=x.get('deliveryCompanyCode',''),invoice=str(x.get('shippingTrackingNumber') or ''))
        s=r['raw_status']
        for key,label in [('CANCEL','취소'),('RETURN','반품'),('EXCHANGE','교환')]:
            if key in s:r['claims']=[dict(type=label,status=s,id=r['remote_id'])];r['blocked']=True;r['status']=label
        return r
    raise ValueError('이 마켓은 주문 파일 가져오기를 사용하세요.')

def days(start,end,width=1):
    a=date.fromisoformat(start);b=date.fromisoformat(end)
    if b<a or (b-a).days>30:raise ValueError('조회 기간은 1~31일로 선택하세요.')
    while a<=b:
        z=min(b,a+timedelta(days=width-1));yield a,z;a=z+timedelta(days=1)

class Adapter:
    def __init__(self,registry,id,cancel=None,progress=None):
        self.registry,self.id=registry,id;self.store=registry.get(id);self.market=self.store['market'];self.keys=registry.keys(id);self.client=registry.client(id);self.cancel=cancel or threading.Event();self.progress=progress or (lambda s:None)
    def call(self,*a,**kw):
        if self.cancel.is_set():raise ValueError('주문 수집을 중단했습니다. 수집 완료된 상점의 내역은 유지합니다.')
        return self.client.call(*a,**kw)
    def cp(self,version,tail):return '/v2/providers/openapi/apis/api/'+version+'/vendors/'+quote(self.keys['vendor_id'],safe='')+'/'+tail
    def fetch(self,start,end):
        chunks=list(days(start,end,1 if self.market in ('naver','kakao') else 31));result={};claims=[]
        def put(x):
            if self.market=='coupang' and x.get('vendorId') and x['vendorId']!=self.keys['vendor_id']:raise ValueError('응답의 판매자 ID가 선택한 상점과 다릅니다.')
            r=normalize(self.market,x);old=result.get(r['remote_id'])
            if old and old['order_id']!=r['order_id']:raise ValueError('주문번호가 중복된 응답입니다.')
            result[r['remote_id']]=r
        for a,b in chunks:
            self.progress(f'{self.store["name"]} · {a}~{b} 주문 조회')
            if self.market=='coupang':
                for status in ('ACCEPT','INSTRUCT','DEPARTURE','DELIVERING','FINAL_DELIVERY','NONE_TRACKING'):
                    for x in self.pages(self.cp('v5','ordersheets'),dict(createdAtFrom=str(a)+'+09:00',createdAtTo=str(b)+'+09:00',status=status,maxPerPage=50),'data','nextToken'):put(x)
            elif self.market=='naver':
                page=1;seen=set()
                while True:
                    r=obj(self.call('GET','/v1/pay-order/seller/product-orders',params={'from':str(a)+'T00:00:00.000+09:00','to':str(b)+'T23:59:59.999+09:00','page':page,'pageSize':100}).get('data'))
                    content=array(r.get('contents'));sig=json.dumps(content,sort_keys=True)
                    if content and sig in seen:raise ValueError('주문 페이지가 반복되어 수집을 중단했습니다.')
                    seen.add(sig)
                    for x in content:put(x)
                    pg=r.get('pagination') or {}
                    if pg.get('hasNext') is False or pg.get('hasNextPage') is False or (pg.get('totalPages') is not None and page>=int(pg['totalPages'])) or len(content)<100:break
                    page+=1
                    if page>1000:raise ValueError('조회 범위를 줄여 주세요.')
            elif self.market in ('auction','gmarket'):
                for state in range(1,6):
                    page=1;seen=set()
                    while True:
                        r=obj(self.call('POST','/shipping/v1/Order/RequestOrders',dict(siteType=1 if self.market=='auction' else 2,orderStatus=state,requestDateType=1,requestDateFrom=str(a)+' 00:00',requestDateTo=str(b+timedelta(days=1))+' 00:00',pageIndex=page,pageSize=100)))
                        if str(r.get('SellerId','')).lower()!=self.keys['seller_id'].lower():raise ValueError('ESM 응답의 판매자 ID가 선택한 상점과 다릅니다.')
                        content=array(r.get('RequestOrders'));total=int(r.get('TotalCount',0));sig=json.dumps(content,sort_keys=True)
                        if content and sig in seen:raise ValueError('ESM 주문 페이지가 반복되어 수집을 중단했습니다.')
                        seen.add(sig)
                        for x in content:put(x)
                        if self.cancel.wait(5):raise ValueError('주문 수집을 중단했습니다.')
                        if page*100>=total:break
                        if not content or page>1000:raise ValueError('ESM 주문 페이지가 누락되었습니다.')
                        page+=1
            elif self.market=='kakao':
                for x in self.pages('/v2/shopping/orders/paidAt',dict(from_=str(a)+' 00:00:00',to=str(b)+' 23:59:59',size=100),'contents','token',kakao=True):
                    put(self.call('GET','/v1/shopping/order',params={'order_id':ident(x.get('id') or x.get('orderId'))}))
            elif self.market=='toss':
                for x in self.pages('/api/v3/shopping-fep/orders/v2',dict(startDate=str(a),endDate=str(b),limit=50,partnerName='WingDesk'),'results','nextCursor'):put(x)
            else:raise ValueError('이 마켓은 주문 파일 가져오기를 사용하세요.')
        if self.market=='coupang':
            # Claim states are fetched separately; no cancellation is inferred from disappearance.
            for kind,status in [('CANCEL',None),('RETURN','RU'),('RETURN','UC'),('RETURN','CC'),('RETURN','PR')]:
                params=dict(createdAtFrom=start,createdAtTo=end,receiptType=kind,maxPerPage=50)
                if status:params['status']=status
                for x in self.pages(self.cp('v6','returnRequests'),params,'data','nextToken'):
                    claims.append(dict(id=ident(x.get('receiptId')),order_id=ident(x.get('orderId')),type='취소' if kind=='CANCEL' else '반품',status=str(x.get('receiptStatus') or x.get('status') or ''),created_at=x.get('createdAt','')))
            for a,b in days(start,end,7):
                for x in self.pages(self.cp('v4','exchangeRequests'),dict(createdAtFrom=str(a)+'T00:00:00',createdAtTo=str(b)+'T23:59:59',maxPerPage=10),'data','nextToken'):
                    claims.append(dict(id=ident(x.get('exchangeId')),order_id=ident(x.get('orderId')),type='교환',status=str(x.get('exchangeStatus') or ''),created_at=x.get('createdAt','')))
            for r in result.values():
                r['claims']=[c for c in claims if c['order_id']==r['order_id']]
                if r['claims']:r['blocked']=True
        return list(result.values()),claims
    def pages(self,path,params,content,cursor,kakao=False):
        seen=set();params=dict(params)
        if 'from_' in params:params['from']=params.pop('from_')
        for _ in range(1000):
            r=obj(self.call('GET',path,params=params));xs=array(r.get(content))
            for x in xs:yield obj(x)
            token=r.get(cursor)
            if not token:break
            key=json.dumps(token,sort_keys=True)
            if key in seen:raise ValueError('다음 주문 페이지가 반복되어 수집을 중단했습니다.')
            seen.add(key)
            if not xs:raise ValueError('주문 페이지가 누락되어 수집을 중단했습니다.')
            params['token' if kakao else cursor]=token
        else:raise ValueError('조회 주문이 많습니다. 기간을 줄여 주세요.')
    def detail(self,r):
        if self.market=='coupang':x=self.call('GET',self.cp('v5','ordersheets/'+quote(r['remote_id'],safe='')))['data']
        elif self.market=='naver':
            xs=array(self.call('POST','/v1/pay-order/seller/product-orders/query',{'productOrderIds':[r['remote_id']]}).get('data'))
            if len(xs)!=1:raise ValueError('주문 상세를 한 건으로 확인하지 못했습니다.')
            x=xs[0]
        elif self.market=='kakao':x=self.call('GET','/v1/shopping/order',params={'order_id':r['remote_id']})
        elif self.market in ('auction','gmarket'):
            data=obj(self.call('POST','/shipping/v1/Order/RequestOrders',dict(siteType=1 if self.market=='auction' else 2,orderStatus=0,orderNo=int(r['remote_id']))))
            if str(data.get('SellerId','')).lower()!=self.keys['seller_id'].lower():raise ValueError('ESM 판매자 ID가 다릅니다.')
            xs=array(data.get('RequestOrders'))
            if len(xs)!=1:raise ValueError('주문을 조회하지 못했습니다. 클레임 여부를 판매자센터에서 확인하세요.')
            x=xs[0]
        elif self.market=='toss':x=self.call('GET','/api/v3/shopping-fep/orders/products/'+quote(r['remote_id'],safe=''),params={'partnerName':'WingDesk'})
        else:raise ValueError('주문 수집을 다시 실행해 최신 내역을 확인하세요.')
        n=normalize(self.market,x)
        if (n['remote_id'],n['order_id'])!=(r['remote_id'],r['order_id']):raise ValueError('조회한 주문번호가 기존 내역과 다릅니다.')
        return n
    def supports(self):return self.market in ('coupang','naver')
    def validate_action(self,r,action):
        if not self.supports():raise ValueError('이 마켓의 발주·송장 처리는 판매자센터에서 실행한 후 주문을 다시 수집하세요.')
        if r.get('origin')=='file':raise ValueError('파일로 가져온 주문은 마켓 API 처리 대상이 아닙니다. API로 주문을 먼저 수집하세요.')
        if r.get('blocked') or r.get('claims'):raise ValueError('분할배송·취소·클레임 내역이 있는 주문은 판매자센터에서 처리하세요.')
        if action=='confirm' and r['status']!='신규':raise ValueError('신규 주문만 상품 준비 처리할 수 있습니다.')
        if action=='invoice' and (r['status']!='상품 준비' or r.get('invoice')):raise ValueError('송장이 없는 상품 준비 주문만 발송 처리할 수 있습니다.')
        if not r['items'] or any(x['quantity']<=0 for x in r['items']):raise ValueError('주문 수량을 확인하세요.')
    def write(self,r,action,values):
        self.validate_action(r,action)
        if self.market=='coupang':
            if action=='confirm':response=self.call('PATCH',self.cp('v4','ordersheets/acknowledgement'),dict(vendorId=self.keys['vendor_id'],shipmentBoxIds=[int(r['remote_id'])]))
            else:
                response=self.call('POST',self.cp('v4','orders/invoices'),dict(vendorId=self.keys['vendor_id'],orderSheetInvoiceApplyDtos=[dict(shipmentBoxId=int(r['remote_id']),orderId=int(r['order_id']),vendorItemId=int(i['id']),deliveryCompanyCode=values['courier'],invoiceNumber=values['invoice'],splitShipping=False,preSplitShipped=False,estimatedShippingDate='') for i in r['items']]))
            data=obj(response.get('data'));entries=array(data.get('responseList'))
            if str(data.get('responseCode')) not in ('0','1'):raise RemoteRejected('쿠팡이 배송 처리 요청을 거절했습니다. 주문을 다시 수집하세요.')
            matching=[x for x in entries if str(x.get('shipmentBoxId'))==r['remote_id']]
            if not matching or not all(x.get('succeed') is True for x in matching):raise Uncertain('쿠팡의 주문별 처리 성공을 확인하지 못했습니다. 결과 조회로 확인하세요.')
        elif self.market=='naver':
            if action=='confirm':response=self.call('POST','/v1/pay-order/seller/product-orders/confirm',dict(productOrderIds=[r['remote_id']]))
            else:response=self.call('POST','/v1/pay-order/seller/product-orders/dispatch',dict(dispatchProductOrders=[dict(productOrderId=r['remote_id'],deliveryMethod='DELIVERY',deliveryCompanyCode=values['courier'],trackingNumber=values['invoice'],dispatchDate=now())]))
            data=obj(response.get('data'));failures=data.get('failProductOrderInfos') or []
            if failures:raise RemoteRejected('스마트스토어가 배송 처리 요청을 거절했습니다. 주문 상세를 확인하세요.')
        return self.detail(r)
