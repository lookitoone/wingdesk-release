"""Readable API errors and a shareable log containing no keys or request bodies."""
from __future__ import annotations
import json,re,threading
from html import unescape
from datetime import datetime,timezone,timedelta
from pathlib import Path
_LOCK=threading.RLock()

def message_text(value):
    for _ in range(3):
        if isinstance(value,dict):
            value=value.get('message') or value.get('errorMessage') or value.get('error') or '';continue
        if not isinstance(value,str):return ''
        try:
            parsed=json.loads(value)
            if isinstance(parsed,(str,dict)):value=parsed;continue
        except (ValueError,TypeError):pass
        break
    if not isinstance(value,str):return ''
    # Some gateways double-escape just the Korean text. Decode these sequences
    # without applying unicode_escape to already decoded UTF-8 Korean strings.
    return re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m[1],16)),value)

def friendly_error(status,value,method='GET'):
    msg=message_text(value).lower()
    if 'not allowed ip' in msg or 'ip is not allowed' in msg:
        reason='현재 PC의 인터넷 IP가 쿠팡 API에 허용되어 있지 않습니다. Wing의 판매자정보 → 추가판매정보 → Open API에서 자체개발 연동 IP를 확인하세요. 변경했다면 최대 30분 뒤 다시 확인하세요.'
    elif 'access denied' in msg:
        reason='쿠팡이 현재 인터넷 연결의 접근을 제한했습니다. 연결 확인을 반복하지 말고 10분 뒤 다시 시도하세요. 계속되면 쿠팡의 IP 제한을 확인하세요.'
    elif 'expired' in msg and ('signature' in msg or 'signed' in msg):
        reason='쿠팡 인증 시간이 맞지 않습니다. Windows 설정 → 시간 및 언어에서 자동 시간 설정과 지금 동기화를 실행한 뒤 다시 확인하세요.'
    elif 'signature' in msg:
        reason='쿠팡 API 키와 인증 서명이 일치하지 않습니다. 같은 발급 화면의 Access Key와 Secret Key를 한 쌍으로 다시 복사해 저장하세요.'
    elif status==401 or any(t in msg for t in ('invalid access','invalid secret','access key','accesskey','unauthorized')):
        reason='쿠팡 API 인증에 실패했습니다. 발급받은 키의 유효기간과 Access Key·Secret Key가 같은 판매자의 키인지 확인하세요.'
    elif status==403:
        reason='쿠팡 API 접근 권한이 없습니다. 업체코드, API 키의 연동업체 선택과 허용 IP를 Wing에서 확인하세요.'
    elif status==429:
        reason='쿠팡 API 요청이 많아 잠시 제한되었습니다. 잠시 뒤 다시 확인하세요.'
    elif status==404:
        reason='쿠팡에서 요청한 정보를 찾지 못했습니다. 업체코드와 등록 정보가 올바른지 확인하세요.'
    elif status==400:
        reason='쿠팡이 요청값을 처리하지 못했습니다. 업체코드와 입력 내용을 확인하세요.'
    elif status is not None and status>=500:
        reason='쿠팡 서버가 정상적으로 응답하지 않았습니다. 잠시 뒤 다시 확인하세요.'
    else:
        reason='쿠팡 응답을 확인하지 못했습니다. 인터넷 연결을 확인하고 연결 오류 기록을 저장해 주세요.'
    suffix=f' (HTTP {status})' if status is not None else ''
    if method!='GET' and (status is None or status>=500 or status==408):reason+=' 전송한 작업은 쿠팡 Wing에서 결과를 확인하세요. 자동으로 다시 전송하지 않습니다.'
    return reason+suffix

def response_details(value,secrets=(),body=None):
    """Read only documented diagnostic fields, never the entire response/request.

    Used for the local product result, not the shareable connection log.
    Keys and sensitive request values echoed by a gateway must not survive.
    """
    hidden=[str(x) for x in secrets if x]
    sensitive=('address','contact','phone','zipcode','zip_code','email','secret','accesskey','access_key','authorization','signature','token','password','vendorid','vendor_id','vendoruserid','wing_id','returnchargename')
    def request_values(obj):
        if isinstance(obj,dict):
            for key,v in obj.items():
                if any(t in str(key).lower() for t in sensitive) and isinstance(v,(str,int)) and len(str(v))>=4:hidden.append(str(v))
                elif isinstance(v,(dict,list)):request_values(v)
        elif isinstance(obj,list):
            for v in obj[:200]:request_values(v)
    request_values(body)
    def clean(v):
        text=message_text(v)
        if not text.strip() or text.strip().upper() in ('[]','{}','NULL','NONE','SUCCESS'):return ''
        text=unescape(text)
        for word in sorted(set(hidden),key=len,reverse=True):text=text.replace(word,'[숨김]')
        text=re.sub(r'(?is)<(script|style)\b[^>]*>.*?</\1>','',text)
        text=re.sub(r'<[^>]*>','',text)
        text=re.sub(r'(?i)\b(?:access[-_ ]?key|secret[-_ ]?key|signature|authorization|token|password)\s*[:=]\s*[^\s,;]+', '[인증정보 숨김]',text)
        text=re.sub(r'\b01[016789][- ]?\d{3,4}[- ]?\d{4}\b','[연락처 숨김]',text)
        text=re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}','[이메일 숨김]',text)
        return re.sub(r'[\x00-\x1f\x7f]+',' ',text).strip()[:1400]
    if not isinstance(value,dict):return ''
    parts=[]
    def add(text):
        if text and text not in parts:parts.append(text)
    for key in ('message','errorMessage','details'):
        v=value.get(key)
        if isinstance(v,list):
            for entry in v[:10]:add(clean(entry))
        elif isinstance(v,(str,dict)):add(clean(v))
    items=value.get('errorItems')
    if isinstance(items,list):
        for item in items[:20]:
            if not isinstance(item,dict):continue
            label=clean(item.get('itemName')) or ('옵션 '+str(item['itemIndex']+1) if type(item.get('itemIndex')) is int and item['itemIndex']>=0 else '옵션')
            attrs=item.get('itemAttributes')
            if isinstance(attrs,list):
                for attr in attrs[:20]:
                    if not isinstance(attr,dict):continue
                    reason=clean(attr.get('message'))
                    if reason:add(label+' · '+(clean(attr.get('attributeTypeName')) or '구매 옵션')+': '+reason)
            reason=clean(item.get('message'))
            if reason:add(label+': '+reason)
    return '\n'.join(parts)[:6000]

def rejection_message(status,value,method='GET',secrets=(),body=None):
    details=response_details(value,secrets,body)
    # Authentication/rate-limit/server guidance stays separate from product validation.
    if details and status in (None,400,409,422):
        label='쿠팡이 상품 등록을 거절했습니다.' if method=='POST' and isinstance(body,dict) and 'sellerProductName' in body else '쿠팡이 요청을 거절했습니다.'
        action='표시된 사유를 확인·수정한 뒤 필요한 상품만 다시 등록하세요.' if method=='POST' and isinstance(body,dict) and 'sellerProductName' in body else '표시된 사유를 확인한 뒤 다시 요청하세요.'
        return label+(f' (HTTP {status})' if status is not None else '')+'\n'+details+'\n'+action
    if status is None:return '쿠팡이 요청 실패를 반환했습니다. 상세 사유가 비어 있습니다. 연결 오류 기록을 저장해 주세요. 자동으로 다시 전송하지 않습니다.'
    return friendly_error(status,value,method)

def record(directory,version,method,path,message,status=None):
    """Only generated user guidance goes into the log, never remote bodies."""
    at=datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds')
    endpoint=re.sub(r'/vendors/[^/]+/', '/vendors/[업체코드]/',str(path).split('?')[0])
    endpoint=re.sub(r'/(seller-products|vendor-items)/[^/]+',r'/\1/[상품ID]',endpoint)
    endpoint=re.sub(r'/(ordersheets|orders)/[0-9]+',r'/\1/[주문ID]',endpoint)
    line=f'{at} | WingDesk {version} | {method} {endpoint} | '+str(message).replace('\r',' ').replace('\n',' ')[:1200]
    dest=Path(directory)/'api-diagnostics.txt'
    try:
        with _LOCK:
            lines=dest.read_text(encoding='utf-8').splitlines() if dest.exists() else []
            dest.write_text('\n'.join((lines+[line])[-80:])+'\n',encoding='utf-8')
    except OSError:pass  # Logging must never replace the actual API result.

def report(directory,version):
    dest=Path(directory)/'api-diagnostics.txt'
    with _LOCK:
        try:content=dest.read_text(encoding='utf-8')
        except OSError:content='아직 연결 오류 기록이 없습니다. 쿠팡 연결 확인을 누른 뒤 다시 저장하세요.\n'
    return f'WingDesk {version} 연결 오류 기록\nAPI 키·인증 서명·입력한 주소·요청 본문은 기록하지 않습니다.\n\n'+content
