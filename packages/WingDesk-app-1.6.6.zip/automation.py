"""Persistent, account-scoped shop operations. No remote writes on startup.

Supplier commercial changes come from the seller's exported CSV/XLSX, never
from guesses about guest/member prices on supplier pages. Network requests are
bounded, paginated and serialized with registration and stock operations.
"""
from __future__ import annotations
import base64, copy, hashlib, json, math, re, secrets, threading, time, uuid
from datetime import datetime, timedelta
from pathlib import Path
from core import BASE, KST, Coupang, RemoteRejected, Uncertain, integer, now, price, read_table, validate

DEFAULTS = dict(enabled=False, hour=10, minute=0, register=False, requested=False,
                limit=20, cleanup=False, days=30, cleanup_action='stop',
                price_up='notify', price_down='notify', shipping_up='notify', shipping_down='notify',
                max_change=30, feed_path='', feed_source='오너클랜')
KINDS = ('price_up','price_down','shipping_up','shipping_down')
ORDER_STATUSES = ('ACCEPT','INSTRUCT','DEPARTURE','DELIVERING','FINAL_DELIVERY','NONE_TRACKING')

def date_time(value):
    dt=datetime.fromisoformat(str(value).replace('Z','+00:00'))
    return dt.replace(tzinfo=KST) if dt.tzinfo is None else dt.astimezone(KST)

class Automation:
    def __init__(self,store,credentials,batches,stock):
        self.store,self.credentials,self.batches,self.stock=store,credentials,batches,stock
        self.active=False;self.cancel=threading.Event();self.closed=stock.closed;self.thread=None
        self.progress='';self.last_error=''
        self.plans={}
        with store.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS automation_data(account TEXT,key TEXT,data TEXT,
                PRIMARY KEY(account,key));
                CREATE TABLE IF NOT EXISTS automation_events(id INTEGER PRIMARY KEY AUTOINCREMENT,
                account TEXT,data TEXT);''')
    def account(self):
        value=str(self.store.settings().get('vendor_id','')).strip()
        if not re.fullmatch(r'[A-Za-z0-9]+',value):raise ValueError('쿠팡 연결 설정에서 업체코드를 먼저 저장하세요.')
        return value
    def read(self,key,default=None):
        with self.store.connect() as db:
            r=db.execute('SELECT data FROM automation_data WHERE account=? AND key=?',(self.account(),key)).fetchone()
        return json.loads(r[0]) if r else copy.deepcopy(default)
    def write(self,key,data):
        with self.store.connect() as db:
            db.execute('INSERT OR REPLACE INTO automation_data VALUES(?,?,?)',(self.account(),key,json.dumps(data,ensure_ascii=False)))
    def event(self,kind,message,**extra):
        with self.store.connect() as db:
            db.execute('INSERT INTO automation_events(account,data) VALUES(?,?)',
                       (self.account(),json.dumps(dict(at=now(),kind=kind,message=message,**extra),ensure_ascii=False)))
            db.execute('DELETE FROM automation_events WHERE id NOT IN (SELECT id FROM automation_events ORDER BY id DESC LIMIT 3000)')
    def config(self):return {**DEFAULTS,**self.read('settings',{})}
    def save(self,p):
        with self.stock.lock,self.store.lock:
            self.idle()
            s=self.config()
            for k in ('enabled','register','requested','cleanup'):
                if k in p:
                    if not isinstance(p[k],bool):raise ValueError('켜기/끄기 값을 확인하세요.')
                    s[k]=p[k]
            for k,a,b in [('hour',0,23),('minute',0,59),('limit',1,1000),('days',30,90),('max_change',1,50)]:
                if k in p:s[k]=integer(p[k],k,a,b)
            for k in KINDS:
                if k in p:
                    if p[k] not in ('notify','stop','update'):raise ValueError('변동 처리 방식을 확인하세요.')
                    s[k]=p[k]
            if 'cleanup_action' in p:
                if p['cleanup_action'] not in ('stop','delete'):raise ValueError('미판매 상품 처리 방식을 확인하세요.')
                s['cleanup_action']=p['cleanup_action']
            for k in ('feed_path','feed_source'):
                if k in p:s[k]=str(p[k]).strip()
            if s['feed_source'] not in ('오너클랜','도매매','나비엠알오','글로벌엠알오','기타'):raise ValueError('공급사를 확인하세요.')
            if s['feed_path'] and (not Path(s['feed_path']).is_absolute() or Path(s['feed_path']).suffix.lower() not in ('.csv','.xlsx')):
                raise ValueError('자동으로 읽을 CSV/XLSX 파일의 전체 경로를 입력하세요.')
            self.write('settings',s);self.event('설정 저장','자동 상품 관리 규칙을 저장했습니다.')
        return self.state()
    def idle(self):
        if self.closed.is_set():raise ValueError('프로그램이 종료 중입니다.')
        if self.active or self.stock.active or self.batches.active:raise ValueError('진행 중인 작업이 끝난 뒤 다시 눌러 주세요.')
    def daily_time(self,current,s):
        target=current.replace(hour=s['hour'],minute=s['minute'],second=0,microsecond=0)
        if self.read('scheduled_day')==current.date().isoformat():target+=timedelta(days=1)
        return target
    def queue_status(self,queue,current,s):
        result=[];position=0
        for source in queue:
            row=copy.deepcopy(source);row['scheduled_for']='';row['requested']=row.get('requested',s['requested'])
            if row['state']!='대기':reason='등록 작업 내역을 확인하세요.' if row['state']=='전송 예약됨' else row.get('message','상태를 확인하세요.')
            elif row.get('scheduled_at'):
                row['scheduled_for']=row['scheduled_at']
                reason='예약 시각 도래 · 진행 중인 작업이 끝나면 순차 전송' if date_time(row['scheduled_at'])<=current else '지정 시각부터 순차 전송'
                if date_time(row['scheduled_at'])<=current and not self.credentials.ready():reason='쿠팡 API 키 설정 필요 · 연결 설정 후 자동 재검사'
            elif not s['enabled'] or not s['register']:reason='매일 예약 꺼짐 · 관리 설정을 켜거나 시간을 지정하세요.'
            else:
                row['scheduled_for']=(self.daily_time(current,s)+timedelta(days=position//s['limit'])).isoformat();position+=1
                reason=f"매일 {s['hour']:02}:{s['minute']:02} · 한 번에 최대 {s['limit']}개"
            row['schedule_message']=reason;result.append(row)
        return result
    def state(self):
        try:
            s=self.config();catalog=self.read('catalog',[]);queue=self.read('queue',[])
            changes=self.read('changes',[]);excluded=self.read('excluded',[])
            with self.store.connect() as db:
                events=[json.loads(r[0]) for r in db.execute('SELECT data FROM automation_events WHERE account=? ORDER BY id DESC LIMIT 60',(self.account(),))]
            current=datetime.now(KST);next_run=self.daily_time(current,s)
            return dict(settings=s,catalog=catalog,queue=self.queue_status(queue,current,s),changes=changes,excluded=excluded,events=events,
                        active=self.active,progress=self.progress,last_error=self.last_error,
                        last_sync=self.read('last_sync',''),last_run=self.read('last_run',{}),
                        orders=self.read('orders',{}),next_run=next_run.isoformat() if s['enabled'] else '')
        except ValueError:
            return dict(settings=dict(DEFAULTS),catalog=[],queue=[],changes=[],excluded=[],events=[],active=self.active,
                        progress='',last_error='',last_sync='',last_run={},orders={},next_run='')
    def queue(self,p):
        with self.stock.lock,self.store.lock:
            self.idle();ids=p.get('ids')
            if not isinstance(ids,list) or not ids or len(ids)>1000 or any(not isinstance(x,str) or not x for x in ids):raise ValueError('예약할 상품을 1~1,000개 선택하세요.')
            queue=self.read('queue',[])
            if p.get('remove'):
                queue=[x for x in queue if x['id'] not in ids]
            else:
                scheduled=None
                if 'scheduled_at' in p:
                    value=p['scheduled_at'];current=datetime.now(KST)
                    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?(Z|[+-]\d{2}:\d{2})',value):raise ValueError('예약 날짜와 시간을 한국 시간 기준으로 지정하세요.')
                    try:scheduled=date_time(value)
                    except ValueError:raise ValueError('올바른 예약 날짜와 시간을 입력하세요.') from None
                    if not current<scheduled<=current+timedelta(days=365):raise ValueError('현재 이후부터 1년 이내의 예약 시간을 지정하세요.')
                    if type(p.get('requested')) is not bool:raise ValueError('예약 상품의 판매 승인 요청 또는 임시저장을 선택하세요.')
                    batch_limit=integer(p.get('batch_limit',len(set(ids))),'예약 등록 수량',1,1000);group=uuid.uuid4().hex
                for id in dict.fromkeys(ids):
                    pr=self.store.get(id)
                    if pr['demo'] or pr['remote_id'] or pr['state'] in ('전송 중','전송 대기','결과 확인 필요'):raise ValueError(pr['name']+': 신규 등록 가능한 상품만 예약할 수 있습니다.')
                    existing=next((x for x in queue if x['id']==id),None)
                    if existing and scheduled is not None:
                        if existing['state'] not in ('대기','수정 필요','중단됨'):raise ValueError('전송한 예약은 변경할 수 없습니다. 등록 작업 내역을 확인하세요.')
                        existing.update(scheduled_at=scheduled.isoformat(),requested=p['requested'],batch_limit=batch_limit,schedule_group=group,state='대기',message='')
                    elif not existing:
                        row=dict(id=id,name=pr['name'],state='대기',added=now())
                        if scheduled is not None:row.update(scheduled_at=scheduled.isoformat(),requested=p['requested'],batch_limit=batch_limit,schedule_group=group)
                        queue.append(row)
            self.write('queue',queue)
            self.event('예약 해제' if p.get('remove') else '등록 예약',f"상품 {len(set(ids))}개 · "+('예약 해제' if p.get('remove') else scheduled.isoformat()+'부터 순차 전송' if scheduled is not None else '매일 관리 시간에 등록'))
        return self.state()
    def exclude(self,p):
        with self.stock.lock,self.store.lock:
            self.idle();rid=str(p.get('id',''))
            if rid not in {x['id'] for x in self.read('catalog',[])}:raise ValueError('불러온 매장 상품을 선택하세요.')
            ids=set(self.read('excluded',[]))
            ids.add(rid) if p.get('excluded') else ids.discard(rid)
            self.write('excluded',sorted(ids))
        return self.state()
    def start(self,p):
        kind=p.get('kind','run')
        if kind not in ('sync','run','scheduled','orders','changes','cleanup','resolve','manual-stop','manual-delete'):raise ValueError('지원하지 않는 자동 관리 작업입니다.')
        ids=p.get('ids',[])
        if kind=='resolve':
            if not re.fullmatch(r'[a-f0-9]{32}',str(p.get('change_id',''))):raise ValueError('확인할 변동을 선택하세요.')
            ids=[p['change_id']]
        elif not isinstance(ids,list) or len(ids)>100 or any(not re.fullmatch(r'[1-9]\d*',str(x)) for x in ids):raise ValueError('쿠팡 상품 ID를 숫자로 입력하세요.')
        with self.stock.lock:
            self.idle();self.account()
            if not self.credentials.ready():raise ValueError('쿠팡 API 키를 먼저 저장하세요.')
            if kind.startswith('manual-'):
                plan=self.plans.pop(p.get('ticket',''),None)
                if not plan or plan['expires']<time.monotonic() or plan['account']!=self.account() or plan['kind']!=kind or plan['keys']!=self.key_fingerprint():raise ValueError('상품 확인이 만료되었습니다. 다시 확인해 주세요.')
                ids=[plan['row']]
            self.active=True;self.stock.active=True;self.cancel.clear();self.last_error='';self.progress='작업 준비 중'
            threading.Thread(target=self.run,args=(kind,ids),daemon=True).start()
        return {'ok':True}
    def run(self,kind,ids):
        try:
            # Shared locks freeze account and credential identity for all writes.
            with self.stock.lock,self.store.lock,self.credentials.lock:
                c=Coupang(self.credentials)
                if kind=='sync':self.sync(c,ids)
                elif kind=='orders':self.sync_orders(c)
                elif kind=='cleanup':self.cleanup(c)
                elif kind=='changes':self.process_changes(c)
                elif kind=='resolve':self.resolve_change(c,ids[0])
                elif kind.startswith('manual-'):self.remove_listing(c,ids[0],kind=='manual-delete',manual=True)
                elif kind=='scheduled':self.register(c,scheduled_only=True)
                else:
                    self.read_feed_file()
                    self.sync(c,[])
                    self.process_changes(c)
                    if self.config()['cleanup']:self.cleanup(c)
                    if self.config()['register'] and not self.cancel.is_set():self.register(c)
                self.write('last_run',dict(at=now(),kind=kind,state='중단됨' if self.cancel.is_set() else '완료'))
                self.event('작업 종료','작업을 중단했습니다.' if self.cancel.is_set() else '자동 관리 작업을 완료했습니다.')
        except Exception as ex:
            self.last_error=str(ex) if isinstance(ex,(ValueError,RemoteRejected,Uncertain)) else '작업을 완료하지 못했습니다. 연결 설정과 작업 내역을 확인하세요.'
            self.event('확인 필요',self.last_error)
            self.write('last_run',dict(at=now(),kind=kind,state='확인 필요'))
        finally:
            self.progress=''
            with self.stock.lock:self.active=False;self.stock.active=False
    def pages(self,client,path,params):
        token='';seen=set()
        for _ in range(1000):
            if self.cancel.is_set():raise ValueError('작업을 중단했습니다. 완료하지 못한 조회는 처리에 사용하지 않습니다.')
            r=client.call('GET',path,params={**params,**({'nextToken':token} if token else {})})
            rows=r.get('data')
            if not isinstance(rows,list) or any(not isinstance(x,dict) for x in rows):raise ValueError('목록 응답을 확인하지 못했습니다. 기존 자료를 유지합니다.')
            yield rows
            token=str(r.get('nextToken') or '')
            if not token:return
            if token in seen:raise ValueError('다음 페이지가 반복되어 조회를 중단했습니다.')
            seen.add(token)
        raise ValueError('조회량이 너무 많습니다. 상품코드로 나누어 불러와 주세요.')
    def detail(self,c,rid):
        d=c.call('GET',BASE+'/seller-products/'+str(rid)).get('data')
        if not isinstance(d,dict) or str(d.get('vendorId'))!=self.account() or str(d.get('sellerProductId'))!=str(rid):
            raise ValueError('현재 매장의 상품인지 확인할 수 없습니다.')
        return d
    def sync(self,c,ids):
        self.progress='쿠팡 상품 불러오는 중';old={r['id']:r for r in self.read('catalog',[])};found=[]
        if ids:
            for rid in dict.fromkeys(map(str,ids)):
                d=self.detail(c,rid);found.append(d)
        else:
            for rows in self.pages(c,BASE+'/seller-products',dict(vendorId=self.account(),maxPerPage=100)):found.extend(rows)
        result=dict(old) if ids else {}
        for d in found:
            rid=str(d.get('sellerProductId',''))
            if not re.fullmatch(r'[1-9]\d*',rid) or str(d.get('vendorId'))!=self.account():raise ValueError('상품 목록의 업체코드 또는 상품 ID를 확인하세요.')
            result[rid]=dict(id=rid,name=str(d.get('sellerProductName','')),state=str(d.get('statusName','확인 필요')),
                            created=str(d.get('createdAt','')),synced=now())
        self.write('catalog',list(result.values()));self.write('last_sync',now())
        self.event('상품 불러오기',f'쿠팡 상품 {len(found)}개를 확인했습니다.')
    def feed_preview(self,p):
        raw=base64.b64decode(p.get('data',''),validate=True)
        table=read_table(raw,p.get('filename',''),header_row=p.get('header_row',1))
        return dict(headers=table['headers'],sample=table['rows'][:5],mapping=table['mapping'],count=len(table['rows']))
    def feed(self,p):
        with self.stock.lock,self.store.lock:
            self.idle()
            raw=base64.b64decode(p.get('data',''),validate=True)
            return self.ingest(raw,p.get('filename',''),p.get('source',''),p.get('mapping'),p.get('header_row',1))
    def ingest(self,raw,filename,source,mapping=None,header_row=1):
        table=read_table(raw,filename,header_row=header_row);mapping=mapping or table['mapping']
        if 'sku' not in mapping or not any(k in mapping for k in ('cost','supplier_shipping')):raise ValueError('상품코드와 원가 또는 공급사 배송비 열을 연결하세요.')
        for k,index in mapping.items():
            if not isinstance(index,int) or not 0<=index<len(table['headers']):raise ValueError('파일 열 연결을 확인하세요.')
        ps={(p['source'],p['sku']):p for p in self.store.products() if not p['demo']}
        changes=self.read('changes',[]);errors=[];unmatched=0;staged=[];seen=set()
        for i,row in enumerate(table['rows'],2):
            try:
                def cell(k):return row[mapping[k]] if mapping[k]<len(row) else ''
                sku=str(cell('sku')).strip()
                if not sku:continue
                if sku in seen:raise ValueError('상품코드 중복: 옵션별 원가는 상품 상세에서 확인하세요.')
                seen.add(sku);pr=ps.get((source,sku))
                if not pr:unmatched+=1;continue
                values={}
                for k in ('cost','supplier_shipping'):
                    if k in mapping and str(cell(k)).strip()!='':values[k]=integer(cell(k),'원가' if k=='cost' else '공급사 배송비')
                if values.get('cost')==0:raise ValueError('원가 0원은 변동 처리에 사용할 수 없습니다.')
                if pr['options']:raise ValueError('옵션 상품은 잘못된 일괄 가격 변경을 막기 위해 이 파일 처리에서 제외합니다.')
                existing=next((x for x in changes if x['product_id']==pr['id'] and x['state']=='대기'),None)
                if any(x['product_id']==pr['id'] and x['state']=='확인 필요' for x in changes):raise ValueError('이전 반영 결과를 먼저 Wing에서 확인해 주세요.')
                target={k:v for k,v in values.items() if v!=pr[k]}
                if not target:
                    if existing:staged.append(dict(existing,state='취소됨',message='최신 파일에서 기준값과 같아져 변동 취소'))
                    continue
                ch=dict(id=uuid.uuid4().hex,product_id=pr['id'],name=pr['name'],sku=sku,at=now(),state='대기',
                        before={k:pr[k] for k in target},after=target,message='규칙 처리 대기',remote_id=pr['remote_id'])
                if existing:ch['id']=existing['id']
                staged.append(ch)
            except (ValueError,IndexError,TypeError) as ex:errors.append(f'{i}행: {ex}')
        # Duplicate rows make a feed ambiguous: never partly apply that file.
        if any('상품코드 중복' in e for e in errors):raise ValueError('상품코드가 중복된 파일입니다. 단일 상품당 한 행으로 정리해 주세요.')
        for ch in staged:
            changes=[x for x in changes if x['id']!=ch['id']];changes.append(ch)
        if len([x for x in changes if x['state']=='대기'])>1000:raise ValueError('대기 변동이 1,000개를 넘었습니다. 먼저 기존 변동을 처리하세요.')
        pending=[x for x in changes if x['state'] in ('대기','확인 필요')]
        finished=[x for x in changes if x['state'] not in ('대기','확인 필요')][-300:]
        self.write('changes',finished+pending)
        self.event('공급사 변동 읽기',f'변동 {len(staged)}개 · 미연결 {unmatched}개 · 확인 필요 {len(errors)}개')
        return dict(changed=len(staged),unmatched=unmatched,errors=errors[:30])
    def read_feed_file(self):
        s=self.config();path=s['feed_path']
        if not path:return
        p=Path(path)
        if p.stat().st_size>12*1024*1024:raise ValueError('공급사 자동 읽기 파일은 12MB 이하여야 합니다.')
        with p.open('rb') as f:raw=f.read(12*1024*1024+1)
        if len(raw)>12*1024*1024:raise ValueError('공급사 자동 읽기 파일은 12MB 이하여야 합니다.')
        digest=hashlib.sha256(raw+b'\0'+s['feed_source'].encode()).hexdigest()
        if digest==self.read('feed_digest',''):return
        self.ingest(raw,p.name,s['feed_source']);self.write('feed_digest',digest)
    def process_changes(self,c):
        self.progress='가격·배송비 변동 처리 중';s=self.config();changes=self.read('changes',[])
        for ch in changes:
            if self.cancel.is_set():break
            if ch['state']!='대기':continue
            try:
                p=self.store.get(ch['product_id'])
                if p['remote_id']!=ch['remote_id'] or any(p[k]!=v for k,v in ch['before'].items()):raise ValueError('상품 정보가 변경되었습니다. 공급사 파일을 다시 읽어 주세요.')
                modes={k:s[('price_' if k=='cost' else 'shipping_')+('up' if v>ch['before'][k] else 'down')] for k,v in ch['after'].items()}
                if 'stop' in modes.values():
                    if p['remote_id']:self.stock._apply(p['id'],False)
                    else:self.store.state(p['id'],'자동 등록 제외')
                    ch.update(state='판매 중지',message='변동 규칙에 따라 판매 중지 또는 신규 등록 제외')
                else:
                    updates={k:v for k,v in ch['after'].items() if modes[k]=='update'}
                    if not updates:
                        ch['message']='변동을 안내했습니다. 자동 반영 규칙을 선택하면 처리할 수 있습니다.';continue
                    if any(abs(v-ch['before'][k])/max(ch['before'][k],1)*100>s['max_change'] for k,v in updates.items()):
                        raise ValueError(f"변동 폭이 {s['max_change']}%를 넘어 직접 확인이 필요합니다.")
                    if p['options']:raise ValueError('옵션 상품은 개별 가격을 확인하세요.')
                    target={**p,**updates};new_price=price(target['cost'],p['markup'],math.lcm(10,p['rounding']))
                    new_ship=max(0,p['shipping']+updates.get('supplier_shipping',p['supplier_shipping'])-p['supplier_shipping'])
                    if 'cost' in updates:target['sale_price']=new_price
                    if 'supplier_shipping' in updates:target['shipping']=new_ship
                    if target['sale_price']*(1-p['fee']/100)-target['cost']+target['shipping']-target['supplier_shipping']<0:
                        raise ValueError('예상 이익이 음수여서 자동 반영을 보류했습니다.')
                    if p['remote_id']:
                        ids=self.stock.remote_items(p,c)
                        if len(ids)!=1:raise ValueError('단일 옵션 상품만 가격을 자동 반영합니다.')
                        item=ids[0];rid=str(p['remote_id'])
                        inventory=c.call('GET',BASE+'/vendor-items/'+item+'/inventories').get('data')
                        remote=self.detail(c,rid)
                        if not isinstance(inventory,dict) or inventory.get('salePrice')!=p['sale_price'] or remote.get('deliveryCharge')!=p['shipping']:
                            raise ValueError('현재 쿠팡 가격·배송비가 WingDesk 기준값과 달라 반영을 보류했습니다.')
                        if 'supplier_shipping' in updates and remote.get('deliveryChargeType') not in ('FREE','NOT_FREE'):
                            raise ValueError('조건부 무료·착불 상품의 배송비는 Wing에서 확인하세요.')
                        # Write intent before mutation. Any interruption blocks replay.
                        ch['intent']=dict(target=target,updates=updates,item=item)
                        ch.update(state='확인 필요',message='쿠팡 반영 중 · 중단되면 Wing에서 결과 확인');self.write('changes',changes)
                        if 'cost' in updates and new_price!=p['sale_price']:
                            c.call('PUT',BASE+'/vendor-items/'+item+'/prices/'+str(new_price))
                            v=c.call('GET',BASE+'/vendor-items/'+item+'/inventories').get('data')
                            if not isinstance(v,dict) or v.get('salePrice')!=new_price:raise Uncertain('가격 반영 후 결과를 확인하지 못했습니다.')
                        if 'supplier_shipping' in updates and new_ship!=p['shipping']:
                            body=dict(sellerProductId=int(rid),deliveryCharge=new_ship,deliveryChargeType='FREE' if new_ship==0 else 'NOT_FREE',freeShipOverAmount=0)
                            if new_ship==0:body['deliveryChargeOnReturn']=remote.get('returnCharge',3000)
                            c.call('PUT',BASE+'/seller-products/'+rid+'/partial',body)
                            v=self.detail(c,rid)
                            if v.get('deliveryCharge')!=new_ship or v.get('deliveryChargeType')!=body['deliveryChargeType']:raise Uncertain('배송비 반영 후 결과를 확인하지 못했습니다.')
                    data={k:v for k,v in target.items() if k not in ('id','state','remote_id','created','updated','profit')}
                    with self.store.connect() as db:db.execute('UPDATE products SET data=?,updated=? WHERE id=?',(json.dumps(data,ensure_ascii=False),now(),p['id']))
                    remaining={k:v for k,v in ch['after'].items() if k not in updates}
                    ch.update(state='대기' if remaining else '반영 완료',message='가격·배송비 반영 완료'+(' · 나머지 변동 안내 대기' if remaining else ''))
                    if remaining:
                        ch['after']=remaining;ch['before']={k:p[k] for k in remaining}
                self.event('변동 처리',ch['message'],name=ch['name'])
            except Exception as ex:
                ch.update(state='확인 필요',message=str(ex) if isinstance(ex,(ValueError,RemoteRejected,Uncertain)) else '처리 결과를 확인해 주세요.')
                self.event('변동 확인 필요',ch['message'],name=ch['name'])
            finally:self.write('changes',changes)
    def resolve_change(self,c,id):
        changes=self.read('changes',[]);ch=next((x for x in changes if x['id']==id),None)
        if not ch or ch['state']!='확인 필요':raise ValueError('확인 필요한 변동을 선택하세요.')
        intent=ch.get('intent')
        if not intent:
            ch.update(state='대기',message='반영 요청 전 보류된 변동 · 규칙과 상품을 보완한 뒤 다시 처리하세요.')
        else:
            p=self.store.get(ch['product_id']);target=intent['target'];updates=intent['updates']
            if str(p['remote_id'])!=str(target['remote_id']):raise ValueError('연결 상품이 변경되었습니다.')
            ids=self.stock.remote_items(p,c)
            if ids!=[intent['item']]:raise ValueError('옵션 연결이 변경되었습니다.')
            inventory=c.call('GET',BASE+'/vendor-items/'+ids[0]+'/inventories').get('data');remote=self.detail(c,p['remote_id'])
            if not isinstance(inventory,dict) or inventory.get('salePrice')!=target['sale_price'] or remote.get('deliveryCharge')!=target['shipping']:
                raise ValueError('일부 변경이 완료되지 않았습니다. Wing에서 목표 가격·배송비로 맞춘 뒤 다시 확인하세요. 자동 재전송은 하지 않습니다.')
            data={k:v for k,v in target.items() if k not in ('id','state','remote_id','created','updated','profit')}
            with self.store.connect() as db:db.execute('UPDATE products SET data=?,updated=? WHERE id=?',(json.dumps(data,ensure_ascii=False),now(),p['id']))
            remaining={k:v for k,v in ch['after'].items() if k not in updates}
            ch.update(state='대기' if remaining else '반영 완료',message='조회로 쿠팡 반영 완료를 확인했습니다.')
            if remaining:ch['after']=remaining;ch['before']={k:p[k] for k in remaining}
            ch.pop('intent',None)
        self.write('changes',changes);self.event('변동 결과 확인',ch['message'],name=ch['name'])
    def sync_orders(self,c):
        self.progress='주문·취소·반품 이력 확인 중';s=self.config();current=datetime.now(KST)
        start=(current-timedelta(days=90)).date();end=current.date()
        seen=set(self.read('ever_ordered',[]));collected=set();cursor=start
        previous=self.read('orders',{})
        tracking=now()
        if previous.get('complete') and previous.get('at') and (current-date_time(previous['at'])).total_seconds()<=48*3600:
            tracking=previous.get('tracking_started',tracking)
        self.write('tracking_started',tracking)
        self.write('orders',dict(previous,complete=False))
        while cursor<=end:
            to=min(cursor+timedelta(days=29),end)
            params=dict(createdAtFrom=cursor.isoformat()+'+09:00',createdAtTo=to.isoformat()+'+09:00',maxPerPage=50)
            for status in ORDER_STATUSES:
                for rows in self.pages(c,f'/v2/providers/openapi/apis/api/v5/vendors/{self.account()}/ordersheets',dict(params,status=status)):
                    for r in rows:
                        items=r.get('orderItems')
                        if not isinstance(items,list) or not items:raise ValueError('주문 상품 정보를 확인하지 못해 정리를 보류합니다.')
                        for item in items:
                            rid=str(item.get('sellerProductId',''))
                            if not re.fullmatch(r'[1-9]\d*',rid):raise ValueError('주문 상품 ID를 확인하지 못했습니다.')
                            collected.add(rid)
                        self.write('ever_ordered',sorted(seen|collected))
            for kind,status in [('RETURN',x) for x in ('RU','UC','CC','PR')]+[('CANCEL',None)]:
                rp=dict(createdAtFrom=cursor.isoformat(),createdAtTo=to.isoformat(),maxPerPage=50,cancelType=kind)
                if status:rp['status']=status
                for rows in self.pages(c,f'/v2/providers/openapi/apis/api/v6/vendors/{self.account()}/returnRequests',rp):
                    for r in rows:
                        items=r.get('returnItems')
                        if not isinstance(items,list) or not items:raise ValueError('취소·반품 상품 정보를 확인하지 못해 정리를 보류합니다.')
                        for item in items:
                            rid=str(item.get('sellerProductId',''))
                            if not re.fullmatch(r'[1-9]\d*',rid):raise ValueError('취소·반품 상품 ID를 확인하지 못했습니다.')
                            collected.add(rid)
                        self.write('ever_ordered',sorted(seen|collected))
            cursor=to+timedelta(days=1)
        seen.update(collected);self.write('ever_ordered',sorted(seen))
        result=dict(start=start.isoformat(),end=end.isoformat(),at=now(),complete=True,seen=len(seen),tracking_started=tracking)
        self.write('orders',result);self.event('주문 이력 확인',f'{start} ~ {end} 주문·취소·반품 조회 완료 · 주문 이력 상품 {len(seen)}개 보호')
        return result
    def candidates(self):
        orders=self.read('orders',{});s=self.config();seen=set(self.read('ever_ordered',[]));excluded=set(self.read('excluded',[]));out=[]
        for r in self.read('catalog',[]):
            reason='';age=0
            try:
                created=date_time(r['created']);age=(datetime.now(KST)-created).days
                if not orders.get('complete') or (datetime.now(KST)-date_time(orders['at'])).total_seconds()>3600:reason='주문 이력 조회 필요'
                elif r['id'] in excluded:reason='제외 상품'
                elif r['id'] in seen:reason='주문 이력 있음 · 보호'
                elif age<s['days']:reason=f"등록 {s['days']}일 이내 · 보호"
                elif created<date_time(orders.get('tracking_started',now())):reason='관찰 시작 전 등록 상품 · 이력 보호'
                elif created.date().isoformat()<orders['start']:reason='등록 이후 전체 주문 이력 부족 · 보호'
                elif r['state'] not in ('승인완료','APPROVED','부분승인완료','PARTIAL_APPROVED'):reason='판매 승인 상태 확인 필요'
            except (ValueError,KeyError,TypeError):reason='등록일 확인 필요'
            out.append(dict(**r,age=age,eligible=not reason,reason=reason or '주문 없는 상품 · 정리 가능'))
        return out
    def cleanup(self,c):
        if not self.config()['cleanup']:raise ValueError('미판매 상품 자동 정리를 먼저 켜 주세요.')
        self.sync_orders(c);self.progress='미판매 상품 정리 중';s=self.config()
        for r in [x for x in self.candidates() if x['eligible']][:min(s['limit'],20)]:
            if self.cancel.is_set():break
            self.remove_listing(c,r,s['cleanup_action']=='delete')
    def key_fingerprint(self):
        with self.credentials.lock:return hashlib.sha256(json.dumps(self.credentials.values,sort_keys=True).encode()).hexdigest()
    def prepare_manual(self,p):
        with self.stock.lock,self.store.lock,self.credentials.lock:
            self.idle();rid=str(p.get('id',''))
            row=next((x for x in self.read('catalog',[]) if x['id']==rid),None)
            if not row:raise ValueError('불러온 매장 상품을 선택하세요.')
            d=self.detail(Coupang(self.credentials),rid)
            if not isinstance(d.get('items'),list) or not d['items']:raise ValueError('상품 옵션을 확인하지 못했습니다.')
            epoch=time.monotonic();self.plans={k:v for k,v in self.plans.items() if v['expires']>epoch}
            ticket=secrets.token_urlsafe(24);kind='manual-delete' if p.get('delete') else 'manual-stop'
            row=dict(row,created=str(d.get('createdAt','')),state=str(d.get('statusName','')))
            row['reviewed_items']=[str(x.get('vendorItemId','')) for x in d['items']]
            self.plans[ticket]=dict(row=row,kind=kind,expires=epoch+180,account=self.account(),keys=self.key_fingerprint())
            return dict(ticket=ticket,kind=kind,name=row['name'],id=rid,options=len(d['items']))
    def remove_listing(self,c,r,delete,manual=False):
        rid=r['id'];key='cleanup:'+rid;op=self.read(key,{})
        if op.get('state') in ('sending','unknown','deleted'):return
        # Recheck ownership and the complete option list immediately before writes.
        d=self.detail(c,rid)
        if str(d.get('statusName')) not in ('승인완료','APPROVED','부분승인완료','PARTIAL_APPROVED'):raise ValueError('현재 판매 승인 상태를 확인하지 못했습니다.')
        if str(d.get('createdAt',''))!=r['created']:raise ValueError('상품 등록일이 달라 정리를 보류했습니다.')
        items=d.get('items')
        if not isinstance(items,list) or not items:raise ValueError('상품 옵션을 확인하지 못했습니다.')
        ids=[str(x.get('vendorItemId','')) for x in items]
        if len(set(ids))!=len(ids) or any(not re.fullmatch(r'[1-9]\d*',x) for x in ids):raise ValueError('모든 옵션 ID를 확인하지 못했습니다.')
        if manual and ids!=r.get('reviewed_items'):raise ValueError('확인한 상품 옵션이 변경되었습니다. 다시 확인하세요.')
        # Lifetime evidence was fully queried only for recently created products.
        if not manual and (rid in self.read('ever_ordered',[]) or rid in self.read('excluded',[])):return
        self.write(key,dict(state='sending',at=now()))
        try:
            for id in ids:
                state=c.call('GET',BASE+'/vendor-items/'+id+'/inventories').get('data')
                if not isinstance(state,dict) or not isinstance(state.get('onSale'),bool):raise Uncertain('판매 상태를 확인하지 못했습니다.')
                if state['onSale']:
                    c.call('PUT',BASE+'/vendor-items/'+id+'/sales/stop')
                    state=c.call('GET',BASE+'/vendor-items/'+id+'/inventories').get('data')
                    if not isinstance(state,dict) or state.get('onSale') is not False:raise Uncertain('판매 중지 결과를 확인하지 못했습니다.')
            if delete:
                result=c.call('DELETE',BASE+'/seller-products/'+rid)
                if str(result.get('data'))!=rid:raise Uncertain('매장 삭제 결과를 확인하지 못했습니다.')
            self.write(key,dict(state='deleted' if delete else 'stopped',at=now()))
            for p in self.store.products():
                if str(p['remote_id'])==rid:self.store.state(p['id'],'매장 삭제됨' if delete else '판매 중지됨')
            catalog=self.read('catalog',[])
            for row in catalog:
                if row['id']==rid:row['state']='매장 삭제됨' if delete else '판매 중지됨'
            self.write('catalog',catalog)
            self.event('수동 상품 정리' if manual else '미판매 상품 정리','쿠팡 상품 삭제 완료' if delete else '쿠팡 판매 중지 완료',name=r['name'])
        except Exception:
            self.write(key,dict(state='unknown',at=now()));raise Uncertain('미판매 상품 처리 결과를 Wing에서 확인하세요. 자동으로 재전송하지 않습니다.')
    def register(self,c,scheduled_only=False,current=None):
        self.progress='예약 상품 등록 준비 중';queue=self.read('queue',[]);s=self.config();ids=[]
        current=current or datetime.now(KST);requested=None;group=None;limit=s['limit']
        if scheduled_only:queue.sort(key=lambda r:r.get('scheduled_at') or '9999')
        for row in queue:
            if row['state']!='대기':continue
            at=row.get('scheduled_at')
            if scheduled_only:
                if not at or date_time(at)>current:continue
            elif at:continue
            mode=row.get('requested',s['requested'])
            if requested is not None and mode!=requested:continue
            if scheduled_only and group is not None and row.get('schedule_group','')!=group:continue
            try:
                p=self.store.get(row['id'])
                if p['demo'] or p['remote_id'] or p['state'] not in ('대기','실패'):raise ValueError('이미 전송했거나 신규 등록 대상이 아닙니다.')
                meta=c.call('GET',BASE+'/meta/category-related-metas/display-category-codes/'+p['category']).get('data')
                from registration import metadata
                meta=metadata(meta)
                self.store.meta(p['category'],meta)
                from productinfo import fill_product
                filled,_=fill_product(p,meta,self.store.settings().get('product_info_policy'));p=self.store.save(filled,p['id'])
                issues=validate(p,self.store.settings(),meta,True)
                if issues:raise ValueError('\n'.join(issues[:5]))
                ids.append(p['id']);requested=mode;row['state']='전송 예약됨'
                if scheduled_only:group=row.get('schedule_group','');limit=row.get('batch_limit',s['limit'])
            except Exception as ex:
                row.update(state='수정 필요',message=str(ex) if isinstance(ex,(ValueError,RemoteRejected,Uncertain)) else '상품 정보를 확인하세요.')
            if len(ids)>=limit:break
        self.write('queue',queue)
        if ids:
            j=self.batches.start(ids,True,requested);self.event('예약 등록',f'{len(ids)}개 상품 등록을 시작했습니다. 등록 작업 내역에서 결과를 확인하세요.',job_id=j['id'])
        else:self.event('예약 등록','이번에 등록할 준비된 상품이 없습니다.')
    def reconcile_queue(self):
        queue=self.read('queue',[]);changed=False
        for row in queue:
            if row['state']!='전송 예약됨':continue
            try:
                p=self.store.get(row['id'])
                if p['state'] not in ('전송 중','전송 대기'):
                    row['state']='중단됨' if p['state']=='대기' else p['state']
                    if row['state']=='중단됨':row['message']='전송 전 중단됨 · 시간을 다시 지정하거나 바로 등록 준비로 진행하세요.'
                    changed=True
            except ValueError:row['state']='상품 없음';changed=True
        if changed:self.write('queue',queue)
    def start_background(self):
        if self.thread is None:
            self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()
    def tick(self,current=None):
        current=current or datetime.now(KST)
        with self.stock.lock,self.store.lock:
            if self.active or self.stock.active or self.batches.active or self.closed.is_set():return
            self.reconcile_queue();s=self.config()
            if any(r['state']=='대기' and r.get('scheduled_at') and date_time(r['scheduled_at'])<=current for r in self.read('queue',[])):
                self.start({'kind':'scheduled'});return
            day=current.date().isoformat()
            if not s['enabled'] or (current.hour,current.minute)<(s['hour'],s['minute']) or self.read('scheduled_day')==day:return
            # Persist the daily claim before starting: restart never repeats writes.
            self.write('scheduled_day',day)
            self.start({'kind':'run'})
    def loop(self):
        while not self.closed.wait(20):
            try:self.tick()
            except ValueError:pass
            except Exception:pass
