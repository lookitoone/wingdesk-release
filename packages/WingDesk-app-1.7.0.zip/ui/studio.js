'use strict';
let studioData=null,studioDraft=null,studioDirty=false,studioBusy=false,studioPendingProduct='',studioRequest=0;
const studioLocal=new Map();
const studioURL=id=>'/studio/asset/'+encodeURIComponent(id)+'?token='+encodeURIComponent(sessionToken);
const studioPayload=()=>({id:studioDraft.id,revision:studioDraft.revision,name:studioDraft.name,description:studioDraft.description,request:studioDraft.request||'',style:studioDraft.style,length:studioDraft.length,count:studioDraft.count,references:studioDraft.references,summary:studioDraft.summary,scenes:studioDraft.scenes});
const studioFrozen=()=>studioBusy||!!studioData?.active||!!studioDraft?.applied_at;
function studioMark(){studioDirty=true;if(studioDraft)studioLocal.set(studioDraft.id,structuredClone(studioDraft));if($('#studioSaved'))$('#studioSaved').textContent='저장하지 않은 내용이 있습니다.';}
window.addEventListener('beforeunload',e=>{if(studioDirty){e.preventDefault();e.returnValue='';}});
function openStudioForProduct(){
 if(selected.size!==1){toast('상세페이지를 만들 상품 한 개를 선택하세요.');return;}
 studioPendingProduct=[...selected][0];location.hash='studio';
}
async function studioView(){
 const epoch=++studioRequest;
 $('#content').innerHTML=head('AI 상세페이지','상품 사진으로 문구와 연출 이미지를 만들고, 확인 후 상품에 적용하세요.',`<button id="studioSettings">AI 연결 설정</button>`)+`<div id="studioError" class="form-error" role="alert"></div><div id="studioWorkspace"><p class="hint">저장한 초안을 불러오고 있습니다.</p></div>`;
 $('#studioSettings').onclick=studioSettings;
 try{
  studioData=await api('/api/studio/state',studioDraft?{id:studioDraft.id}:{});
  if(view!=='studio'||epoch!==studioRequest)return;
  if(studioPendingProduct&&!studioData.active){const product=studioPendingProduct;studioPendingProduct='';studioDraft=await api('/api/studio/create',{product_id:product});studioDirty=false;}
  else if(studioDraft&&studioLocal.has(studioDraft.id)&&!studioData.active){studioDraft=structuredClone(studioLocal.get(studioDraft.id));studioDirty=true;}
  else{studioDraft=studioData.draft;studioDirty=false;}
  studioDraw();
 }catch(e){if(view==='studio')err('#studioError',e);}
}
function studioDraw(){
 const d=studioDraft,s=studioData;
 $('#studioWorkspace').innerHTML=`${!s.configured?'<div class="notice amber"><strong>처음 한 번 AI 계정을 연결하세요.</strong><p>Gemini 무료 프로젝트와 Cloudflare Workers Free 계정의 키가 필요합니다. 사무용 노트북에서도 서버에서 생성합니다.</p><button id="studioConnect" class="primary">AI 연결 설정 열기</button></div>':''}
 <div class="studio-top"><label>상품에서 새로 만들기<select id="studioProduct"><option value="">상품을 선택하세요</option>${data.products.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.sku)}</option>`).join('')}</select></label><button id="studioNew">새 초안</button><label>저장한 초안<select id="studioHistory"><option value="">초안을 선택하세요</option>${s.drafts.map(x=>`<option value="${esc(x.id)}" ${x.id===d?.id?'selected':''}>${esc(x.name||'제목 없는 초안')} · ${esc(x.state)}</option>`).join('')}</select></label></div>
 <div class="studio-usage">오늘 이 PC에서 요청한 분석 ${s.usage.analyses||0} / ${s.limits.analyses}회 · 이미지 ${s.usage.images||0} / ${s.limits.images}장 <small>실패 요청도 포함 · 서비스의 실제 무료 한도는 별도이며 먼저 제한될 수 있습니다.</small></div>
 ${d?`<div id="studioProgress" aria-live="polite"></div><div class="studio-layout"><section class="panel"><div class="panel-head"><h2>1. 상품 정보와 사진</h2></div><div class="panel-body"><fieldset id="studioInputs" ${studioFrozen()?'disabled':''}>
 <div class="field"><label for="studioName">상품명</label><input id="studioName" maxlength="100" value="${esc(d.name)}"></div>
 <div class="field"><label for="studioDescription">상품 설명 · 알고 있는 특징</label><textarea id="studioDescription" rows="5" maxlength="8000" placeholder="소재, 구성, 크기 등 확인한 정보를 적으세요. 비워두고 사진으로 시작해도 됩니다.">${esc(d.description)}</textarea></div>
 <div class="field"><label>상품 사진 · 최대 3장</label><div class="studio-refs">${d.references.map((id,i)=>`<div><img src="${studioURL(id)}" alt="상품 참고 사진 ${i+1}"><button type="button" data-studio-remove="${i}">빼기</button></div>`).join('')}</div><div class="actions"><label class="button studio-file">사진 파일 선택<input id="studioFiles" type="file" accept="image/png,image/jpeg,image/webp" multiple hidden></label>${d.product_id?'<button type="button" id="studioProductImage">기존 상품 사진 가져오기</button>':''}</div><small>사진은 AI에 보내기 전 최대 512px로 줄입니다. 실제 상품을 확인할 수 있는 사진을 넣으세요.</small></div>
 <div class="form-grid"><div class="field"><label for="studioStyle">분위기</label><select id="studioStyle">${['깔끔한','따뜻한','고급스러운'].map(x=>`<option ${d.style===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label for="studioLength">설명 길이</label><select id="studioLength">${['간결','보통','자세'].map(x=>`<option ${d.length===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label for="studioCount">만들 이미지</label><select id="studioCount">${[1,2,3].map(n=>`<option value="${n}" ${d.count===n?'selected':''}>${n}장</option>`).join('')}</select></div></div>
 <div class="field"><label for="studioRequest">추가 요청 · 선택</label><textarea id="studioRequest" maxlength="1000" rows="2" placeholder="예: 밝은 배경, 상품을 사용하는 장면을 넣어 주세요.">${esc(d.request||'')}</textarea></div>
 <label class="studio-check"><input id="studioConsent" type="checkbox">선택한 상품 사진과 설명을 Gemini·Cloudflare에 보내 생성합니다. 사용할 수 있는 사진인지 확인했습니다.</label>
 <div class="actions"><button id="studioSave">입력 내용 저장</button><button id="studioGenerate" class="primary" ${!s.configured?'disabled':''}>${d.scenes.length?'AI로 다시 만들기':'AI 상세페이지 만들기'}</button></div><p class="hint" id="studioSaved">${studioDirty?'저장하지 않은 내용이 있습니다.':'저장됨'}</p>
 </fieldset></div></section><section class="panel"><div class="panel-head"><h2>2. 문구 확인과 미리보기</h2></div><div class="panel-body"><div id="studioResult"></div></div></section></div>`:'<div class="empty"><h3>상품을 선택하고 새 초안을 만드세요</h3><p>사진과 간단한 설명으로 시작할 수 있습니다. 생성만으로 상품이 등록되지는 않습니다.</p></div>'}`;
 if($('#studioConnect'))$('#studioConnect').onclick=studioSettings;
 $('#studioNew').disabled=!!s.active;$('#studioProduct').disabled=!!s.active;$('#studioHistory').disabled=!!s.active;
 $('#studioNew').onclick=()=>studioCreate($('#studioProduct').value);
 $('#studioHistory').onchange=async e=>{if(!e.target.value)return;try{studioRemember();studioDraft=studioLocal.has(e.target.value)?structuredClone(studioLocal.get(e.target.value)):(await api('/api/studio/state',{id:e.target.value})).draft;studioDirty=studioLocal.has(studioDraft.id);studioDraw();}catch(ex){err('#studioError',ex);}};
 if(!d)return;
 for(const [id,key]of [['studioName','name'],['studioDescription','description'],['studioRequest','request'],['studioStyle','style'],['studioLength','length'],['studioCount','count']]){$('#'+id).oninput=e=>{d[key]=key==='count'?Number(e.target.value):e.target.value;studioMark();};}
 $$('[data-studio-remove]').forEach(b=>b.onclick=()=>{d.references.splice(Number(b.dataset.studioRemove),1);studioMark();studioDraw();});
 $('#studioFiles').onchange=async e=>{const files=[...e.target.files];await studioWithBusy(async()=>{if(d.references.length+files.length>3)throw Error('상품 사진은 최대 3장입니다.');for(const file of files){if(file.size>6*1024*1024)throw Error('6MB 이하의 사진을 선택하세요.');const raw=await studioResize(file);await studioSaveDraft();studioDraft=await api('/api/studio/reference',{id:studioDraft.id,revision:studioDraft.revision,data:raw});}studioDirty=false;studioLocal.delete(studioDraft.id);});};
 if($('#studioProductImage'))$('#studioProductImage').onclick=()=>studioWithBusy(async()=>{if(d.references.length>=3)throw Error('상품 사진은 최대 3장입니다.');await studioSaveDraft();const r=await api('/api/studio/product-image',{id:d.id});const raw=await studioResize(await (await fetch(studioURL(r.asset))).blob());studioDraft=await api('/api/studio/reference',{id:studioDraft.id,revision:studioDraft.revision,data:raw});studioDirty=false;studioLocal.delete(d.id);});
 $('#studioSave').onclick=()=>studioWithBusy(()=>studioSaveDraft());
 $('#studioGenerate').onclick=()=>studioWithBusy(async()=>{if(!$('#studioConsent').checked)throw Error('사진과 설명을 AI에 보내는 동의 칸을 체크하세요.');await studioSaveDraft();studioDraft=await api('/api/studio/start',{id:studioDraft.id,revision:studioDraft.revision,consent:true,regenerate:true});studioData.active=studioDraft.id;});
 studioProgress();studioResult();
}
function studioRemember(){if(studioDraft&&studioDirty)studioLocal.set(studioDraft.id,structuredClone(studioDraft));}
async function studioCreate(product){await studioWithBusy(async()=>{studioRemember();studioDraft=await api('/api/studio/create',{product_id:product});studioDirty=false;studioData=await api('/api/studio/state',{id:studioDraft.id});});}
async function studioWithBusy(task){
 if(studioBusy)return;studioBusy=true;
 if($('#studioError'))$('#studioError').textContent='';
 const target=$('#studioInputs');if(target)target.disabled=true;
 try{await task();}catch(e){if(view==='studio')err('#studioError',e);else toast(e.message);}
 finally{studioBusy=false;if(view==='studio'&&$('#studioWorkspace'))studioDraw();}
}
async function studioSaveDraft(){
 if(studioDraft.applied_at)return;
 // Persist text edits before render, upload, or generation. The revision guards
 // protect against another tab changing the same draft.
 studioDraft=await api('/api/studio/save',studioPayload());studioDirty=false;studioLocal.delete(studioDraft.id);
}
function studioProgress(){
 const d=studioDraft;if(!d||!$('#studioProgress'))return;
 $('#studioProgress').innerHTML=`<div class="notice"><strong>${esc(d.state)}</strong><p>${esc(d.message)}</p>${studioData.active?`<progress max="100" value="${d.progress||0}" aria-label="AI 작업 진행률"></progress><button id="studioCancel">현재 작업 중단</button>`:''}</div>`;
 if($('#studioCancel'))$('#studioCancel').onclick=async()=>{try{await api('/api/studio/cancel',{});toast('현재 요청 응답을 받은 뒤 멈춥니다. 이미 보낸 요청의 사용량은 남을 수 있습니다.');}catch(e){err('#studioError',e);}};
}
function studioResult(){
 const d=studioDraft,finished=d.scenes.length&&d.scenes.every(s=>s.image);
 $('#studioResult').innerHTML=`${d.warnings?.length?`<div class="notice amber"><strong>확인할 내용</strong><ul>${d.warnings.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`:''}
 ${d.scenes.length?`<fieldset id="studioTextEdit" ${studioFrozen()?'disabled':''}><div class="field"><label for="studioSummary">상품 소개</label><textarea id="studioSummary" rows="3" maxlength="200">${esc(d.summary)}</textarea></div>${d.scenes.map((s,i)=>`<div class="studio-scene"><strong>${i+1}번째 페이지</strong><div class="field"><label for="studioTitle${i}">제목</label><input id="studioTitle${i}" maxlength="80" value="${esc(s.title)}"></div><div class="field"><label for="studioBody${i}">설명</label><textarea id="studioBody${i}" maxlength="300" rows="4">${esc(s.body)}</textarea></div>${s.image?`<img class="studio-scene-photo" src="${studioURL(s.image)}" alt="AI가 만든 상품 연출 이미지 ${i+1}">`:'<p class="hint">아직 생성되지 않은 이미지입니다.</p>'}</div>`).join('')}</fieldset>
 <p class="hint">상품 모습과 문구를 확인하세요. AI 연출 이미지는 실제 촬영이나 사용 후기가 아닙니다.</p>
 <div class="actions"><button id="studioRender" class="primary" ${!finished||studioFrozen()?'disabled':''}>문구 저장하고 미리보기 완성</button></div><div id="studioCanvases" class="studio-canvases"></div>
 <div id="studioFinish" ${d.pages.length?'':'hidden'}><div class="actions"><button id="studioDownload">완성 파일 내려받기</button></div><div class="modal-section">3. 상품에 적용하기</div><p class="hint">쿠팡 등록에 필요한 공개 이미지 주소를 준비합니다. 처음에는 연결한 Cloudflare Free 계정에 이미지 보관소를 만듭니다. 공개 이미지는 노트북을 꺼도 유지되며 서비스 한도의 영향을 받습니다.</p><label class="studio-check"><input id="studioPublicConsent" type="checkbox">이 상품 이미지를 인터넷 주소로 공개합니다.</label><button id="studioPublish" ${studioFrozen()?'disabled':''}>${d.state==='주소 확인 대기'?'공개 주소 다시 준비·확인':'쿠팡 등록용 이미지 주소 준비'}</button>${d.state==='적용 준비'?`<div class="notice"><label class="studio-check"><input id="studioReview" type="checkbox">실제 상품과 사진·문구가 맞는지 확인했습니다.</label><label class="studio-check"><input id="studioKeep" type="checkbox" checked>기존 공급사 상세설명도 아래에 유지</label><button id="studioApply" class="primary">이 상품에 상세페이지 적용</button></div>`:''}${d.state==='적용됨'?'<button id="studioRestore">원래 상세설명으로 되돌리기</button>':''}</div>`:'<p class="hint">생성이 끝나면 여기에서 문구를 고치고 상세페이지를 확인할 수 있습니다.</p>'}`;
 if(!d.scenes.length)return;
 $('#studioSummary').oninput=e=>{d.summary=e.target.value;studioMark();$('#studioFinish').hidden=true;};
 d.scenes.forEach((s,i)=>{for(const [prefix,key]of [['studioTitle','title'],['studioBody','body']])$('#'+prefix+i).oninput=e=>{s[key]=e.target.value;studioMark();$('#studioFinish').hidden=true;};});
 $('#studioRender').onclick=()=>studioWithBusy(async()=>{await studioSaveDraft();const pages=await studioCompose(studioDraft);studioDraft=await api('/api/studio/pages',{id:studioDraft.id,revision:studioDraft.revision,pages});toast('미리보기와 완성 파일을 저장했습니다.');});
 $('#studioDownload').onclick=()=>{if(studioDirty){toast('문구 저장하고 미리보기를 다시 완성하세요.');return;}location.href='/studio/export/'+d.id+'?token='+encodeURIComponent(sessionToken);};
 $('#studioPublish').onclick=()=>studioWithBusy(async()=>{if(!$('#studioPublicConsent').checked)throw Error('이미지를 인터넷에 공개하는 동의 칸을 체크하세요.');if(studioDirty)throw Error('문구 저장 후 미리보기를 다시 완성하세요.');studioDraft=await api('/api/studio/publish',{id:d.id,revision:d.revision,consent:true});studioData.active=d.id;});
 if($('#studioApply'))$('#studioApply').onclick=()=>studioWithBusy(async()=>{if(!$('#studioReview').checked)throw Error('실제 상품과 사진·문구가 맞는지 확인해 주세요.');const r=await api('/api/studio/apply',{id:d.id,revision:d.revision,confirmed:true,keep_original:$('#studioKeep').checked});studioDraft=r.draft;await refresh(false);toast('상품에 상세페이지를 저장했습니다. 쿠팡 등록은 기존 등록 화면에서 진행하세요.');});
 if($('#studioRestore'))$('#studioRestore').onclick=()=>studioWithBusy(async()=>{studioDraft=await api('/api/studio/restore',{id:d.id,revision:d.revision});await refresh(false);toast('원래 상세설명으로 되돌렸습니다.');});
 if(d.pages.length&&!studioDirty)$('#studioCanvases').innerHTML=d.pages.map((p,i)=>`<img src="${studioURL(p.asset)}" alt="완성 상세페이지 ${i+1}">`).join('');
}
async function studioResize(blob){
 const raw=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('사진을 읽지 못했습니다.'));reader.readAsDataURL(blob);});
 const img=await studioImage(raw);if(img.width*img.height>40000000)throw Error('사진이 너무 큽니다. 크기를 줄인 파일을 선택하세요.');
 const canvas=document.createElement('canvas'),scale=Math.min(1,512/Math.max(img.width,img.height));canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/png');
}
function studioImage(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('사진을 표시하지 못했습니다. PNG·JPG·WEBP 파일을 확인하세요.'));img.src=src;});}
function studioWrap(ctx,value,width){
 const lines=[];for(const paragraph of String(value).split('\n')){let line='';for(const c of paragraph){if(line&&ctx.measureText(line+c).width>width){lines.push(line);line=c;}else line+=c;}lines.push(line);}return lines;
}
function studioCanvasText(ctx,value,x,y,width,height,size,min,color,weight='400'){
 let lines,step;
 for(;;){ctx.font=weight+' '+size+'px "WingDesk KR", "Malgun Gothic", sans-serif';step=Math.ceil(size*1.45);lines=studioWrap(ctx,value,width);if(lines.length*step<=height)break;if(size<=min)throw Error('문구가 페이지에 들어가지 않습니다. 제목이나 설명을 조금 줄여 주세요.');size--;}
 ctx.fillStyle=color;ctx.textBaseline='top';for(const [i,line]of lines.entries())ctx.fillText(line,x,y+i*step);
}
async function studioCompose(d){
 await document.fonts.ready;
 await Promise.all([document.fonts.load('400 24px "WingDesk KR"'),document.fonts.load('700 46px "WingDesk KR"')]);
 const palette={'깔끔한':['#f6f8fb','#163a59','#202d3c'],'따뜻한':['#faf5ec','#775538','#392f28'],'고급스러운':['#18272a','#d3bc80','#f4efe2']}[d.style];
 const pages=[];
 for(const [i,s]of d.scenes.entries()){
  const canvas=document.createElement('canvas');canvas.width=860;canvas.height=1600;const ctx=canvas.getContext('2d');ctx.fillStyle=palette[0];ctx.fillRect(0,0,860,1600);
  studioCanvasText(ctx,d.name,50,38,700,80,24,18,palette[2],'600');
  ctx.fillStyle=palette[1];ctx.fillRect(50,135,50,5);
  studioCanvasText(ctx,s.title,50,165,760,130,46,26,palette[1],'700');
  const img=await studioImage(studioURL(s.image)),scale=Math.min(760/img.width,760/img.height),w=img.width*scale,h=img.height*scale;
  ctx.fillStyle='#ffffff';ctx.fillRect(50,310,760,760);ctx.drawImage(img,50+(760-w)/2,310+(760-h)/2,w,h);
  studioCanvasText(ctx,(i===0&&d.summary?d.summary+'\n\n':'')+s.body,50,1110,760,390,27,18,palette[2]);
  ctx.font='17px "WingDesk KR", "Malgun Gothic",sans-serif';ctx.fillStyle=palette[2];ctx.fillText('AI 연출 이미지 · 실제 상품의 상세정보를 확인하세요',50,1555);ctx.fillText(String(i+1).padStart(2,'0'),775,1555);
  pages.push(canvas.toDataURL('image/png'));
 }
 return pages;
}
async function studioSettings(){
 try{
 const state=await api('/api/studio/state',{}),s=state.settings;
 modal('AI 무료 계정 연결',`<p>키는 이 PC에서만 사용하며 다른 사용자에게 배포하지 않습니다. 생성할 상품 사진과 설명만 AI 서비스로 보냅니다.</p>
 <ol class="studio-setup"><li><a href="https://aistudio.google.com/api-keys" target="_blank" rel="noopener noreferrer">Google AI Studio에서 API 키 만들기</a><p>결제를 연결하지 않은 <strong>Free 프로젝트</strong>를 선택하세요. 무료 이용 데이터는 Google의 서비스 개선에 사용될 수 있습니다.</p></li><li><a href="https://dash.cloudflare.com/" target="_blank" rel="noopener noreferrer">Cloudflare 무료 계정 만들기</a><p>Workers & Pages에서 무료 workers.dev 주소를 정하세요. 유료 플랜이나 도메인 구매는 필요하지 않습니다.</p></li><li><a href="https://dash.cloudflare.com/profile/api-tokens" target="_blank" rel="noopener noreferrer">Cloudflare 사용자 지정 API 토큰 만들기</a><p>이 계정에만 Workers AI 조회·편집, Workers Scripts 편집, Workers KV Storage 편집, Account Settings 조회, Billing 조회 권한을 부여하세요.</p></li></ol>
 <div class="field"><label for="studioGeminiKey">Gemini API 키 ${s.has_gemini?'· 연결값 있음':''}</label><input id="studioGeminiKey" type="password" autocomplete="new-password" placeholder="${s.has_gemini?'빈칸이면 기존 키 유지':'AI Studio에서 복사한 키'}"></div>
 <div class="field"><label for="studioCloudflareAccount">Cloudflare Account ID</label><input id="studioCloudflareAccount" value="${esc(s.account_id)}" maxlength="32" autocomplete="off"></div>
 <div class="field"><label for="studioCloudflareKey">Cloudflare API 토큰 ${s.has_cloudflare?'· 연결값 있음':''}</label><input id="studioCloudflareKey" type="password" autocomplete="new-password" placeholder="${s.has_cloudflare?'빈칸이면 기존 토큰 유지':'사용자 지정 API 토큰'}"></div>
 <label class="studio-check"><input id="studioFree" type="checkbox">Gemini는 결제 미연결 Free 프로젝트, Cloudflare는 Workers Free 계정입니다.</label><p class="hint">앱은 Cloudflare 구독을 조회해 유료 Workers를 차단합니다. Gemini 키만으로는 요금제를 확인할 수 없으므로 반드시 Free 프로젝트를 선택하세요. 앱 내 생성 상한은 서비스 요금제 확인을 대신하지 않습니다.</p>
 <label class="studio-check"><input id="studioRemember" type="checkbox" ${s.remembered?'checked':''}>이 Windows 사용자에 암호화해 저장</label><div id="studioSettingsError" class="form-error" role="alert"></div><p id="studioConnectionResult" role="status"></p>`, '<button id="studioForget">저장한 키 지우기</button><button id="studioTestConnection">저장 후 연결 확인</button><button id="studioSaveSettings" class="primary">연결 설정 저장</button>');
 const save=async()=>{studioData=await api('/api/studio/settings',{account_id:$('#studioCloudflareAccount').value,gemini:$('#studioGeminiKey').value,cloudflare:$('#studioCloudflareKey').value,free_confirmed:$('#studioFree').checked,remember:$('#studioRemember').checked});$('#studioGeminiKey').value='';$('#studioCloudflareKey').value='';};
 $('#studioSaveSettings').onclick=async e=>{e.target.disabled=true;try{await save();$('#modal').close();studioDraw();toast('AI 연결 설정을 저장했습니다.');}catch(ex){err('#studioSettingsError',ex);}finally{e.target.disabled=false;}};
 $('#studioTestConnection').onclick=async e=>{e.target.disabled=true;try{await save();const r=await api('/api/studio/connection',{});$('#studioConnectionResult').textContent=r.message;$('#studioSettingsError').textContent='';}catch(ex){err('#studioSettingsError',ex);}finally{e.target.disabled=false;}};
 $('#studioForget').onclick=async()=>{try{studioData=await api('/api/studio/forget',{});$('#modal').close();studioDraw();toast('저장한 AI 키를 지웠습니다. 공개한 상품 이미지는 유지됩니다.');}catch(ex){err('#studioSettingsError',ex);}};
 }catch(e){err('#studioError',e);}
}
setInterval(async()=>{
 if(view!=='studio'||studioBusy||!studioDraft||!studioData?.active)return;
 try{const r=await api('/api/studio/state',{id:studioDraft.id});if(view!=='studio'||studioBusy)return;const old=studioDraft.state;studioData=r;studioDraft=r.draft;studioProgress();if(old!==studioDraft.state||!r.active)studioDraw();}catch(e){if($('#studioError'))err('#studioError',e);}
},1500);
