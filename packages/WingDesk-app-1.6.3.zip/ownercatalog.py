"""Read-only Ownerclan seller API integration and reviewed local product import.
Official endpoints: ownerclan.com/V2/service/api-center-{guide,item}.php
No marketplace creation, supplier order, or arbitrary GraphQL is exposed.
"""
from __future__ import annotations
import base64,hashlib,html,ipaddress,json,os,re,secrets,sqlite3,threading,time,uuid
from decimal import Decimal,InvalidOperation
from html.parser import HTMLParser
from urllib import request,error,parse
from core import VERSION,dpapi,now,normalize,integer,price
from suppliercodes import SOURCE,product_url

AUTH='https://auth.ownerclan.com/auth'
API='https://api.ownerclan.com/v1/graphql'
FIELDS='''key name model production origin price pricePolicy fixedPrice content
category { key name } shippingFee shippingType status images(size: large)
options { key optionAttributes { name value } price quantity }
taxFree adultOnly returnable openmarketSellable boxQuantity metadata'''
class OwnerError(ValueError):
    def __init__(self,message,*,stage='',http_status=None):
        super().__init__(message);self.stage=stage;self.http_status=http_status
class OwnerAuthError(OwnerError):pass
class OwnerRateError(OwnerError):pass
class OwnerPartialError(OwnerError):
    def __init__(self,message,partial):
        super().__init__(message,stage='items');self.partial=partial

def field_error_hint(errors):
    # Only schema field names and numeric indexes are shown, never upstream messages.
    allowed=set(re.findall(r'[A-Za-z]+',FIELDS))|{'itemsByKeys'}
    fields=[]
    for e in errors:
        path=e.get('path') if isinstance(e,dict) else None
        if isinstance(path,list):
            names=[x for x in path if isinstance(x,str) and x in allowed and x!='itemsByKeys']
            if names:fields.append(' → '.join(names))
    return ' · 응답 필드: '+', '.join(dict.fromkeys(fields))[:200] if fields else ''


def api_request(url,body,token=None):
    if url not in (AUTH,API):raise OwnerError('지원하지 않는 오너클랜 API 주소입니다.')
    class NoRedirect(request.HTTPRedirectHandler):
        def redirect_request(self,*a):return None
    stage='auth' if url==AUTH else 'items'
    label='계정 로그인' if stage=='auth' else '상품 조회'
    headers={'Accept':'application/json','User-Agent':'WingDesk/'+VERSION}
    if stage=='auth':
        headers['Content-Type']='application/json'
        req=request.Request(url,json.dumps(body,ensure_ascii=False).encode(),headers=headers,method='POST')
    else:
        # Seller manual specifies GET for READ queries. Never place credentials in the URL.
        if token:headers['Authorization']='Bearer '+token
        req=request.Request(url+'?'+parse.urlencode(body),headers=headers,method='GET')
    try:
        with request.build_opener(NoRedirect()).open(req,timeout=40) as r:raw=r.read(12*1024*1024+1)
    except error.HTTPError as e:
        # Do not echo upstream bodies/headers: they may include credentials or tokens.
        info=dict(stage=stage,http_status=e.code)
        if e.code in (401,403):
            if stage=='auth':
                message='오너클랜 계정 로그인 실패 (HTTP '+str(e.code)+'). 판매사 ID·비밀번호로 홈페이지에 로그인되는지 확인하세요. 홈페이지 로그인이 된다면 API 이용 권한 또는 접속 제한을 확인하세요. 상품 조회 전 단계에서 중단되었습니다.'
            else:
                message='오너클랜 상품 조회 거절 (HTTP '+str(e.code)+'). 로그인 토큰 발급 후 상품 조회 API에서 거절됐습니다. 상품 조회 API 이용 권한·접속 제한을 확인하세요.'
            raise OwnerAuthError(message,**info) from None
        if e.code==429:raise OwnerRateError(f'오너클랜 {label} 요청 제한 (HTTP 429). 잠시 뒤 다시 실행하세요.',**info) from None
        raise OwnerError(f'오너클랜 {label} 응답 오류 (HTTP {e.code}). 잠시 뒤 다시 확인하세요.',**info) from None
    except (OSError,TimeoutError):raise OwnerError(f'오너클랜 {label} 서버에 연결하지 못했습니다. 인터넷 연결을 확인하세요.',stage=stage) from None
    if len(raw)>12*1024*1024:raise OwnerError('오너클랜 응답이 너무 큽니다. 더 적은 상품을 선택해 수집하세요.')
    try:
        text=raw.decode('utf-8-sig')
        try:return json.loads(text)
        except ValueError:
            if url==AUTH and re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',text.strip()):return text.strip()
            raise ValueError()
    except (ValueError,UnicodeError):raise OwnerError('오너클랜 응답 형식을 확인하지 못했습니다. 기존 상품은 유지합니다.') from None

class OwnerAccount:
    def __init__(self,store):
        self.path=store.directory/'ownerclan-credentials.dpapi';self.lock=threading.RLock();self.values={};self.token='';self.token_expiry=0;self.receipt=None;self.load_error=''
        if os.name=='nt' and self.path.exists():
            try:
                v=json.loads(dpapi(self.path.read_bytes(),True).decode())
                if not isinstance(v,dict) or not isinstance(v.get('username'),str) or not isinstance(v.get('password'),str):raise ValueError()
                self.values={k:v[k] for k in ('username','password')}
            except Exception:self.load_error='오너클랜 계정을 읽지 못했습니다. 같은 Windows 사용자로 실행하세요. 저장된 파일은 덮어쓰지 않습니다.'
    def ready(self):return bool(self.values.get('username') and self.values.get('password'))
    def fingerprint(self):return hashlib.sha256(json.dumps(self.values,sort_keys=True).encode()).hexdigest()
    def public(self):
        with self.lock:
            r=self.receipt if self.receipt and self.receipt['scope']==self.fingerprint() else None
            state='not_configured' if not self.ready() else 'not_checked'
            if r and time.monotonic()-r['epoch']<600:state='verified' if r['success'] else 'failed'
            return dict(username=self.values.get('username',''),has_password=bool(self.values.get('password')),configured=self.ready(),remembered=self.path.exists(),encrypted=os.name=='nt',status=state,checked_at=r['at'] if r else '',error=self.load_error or (r.get('message','') if r else ''))
    def save(self,p):
        with self.lock:
            if p.get('clear'):
                try:self.path.unlink(missing_ok=True)
                except OSError:raise OwnerError('저장한 오너클랜 계정을 삭제하지 못했습니다.') from None
                self.values={};self.token='';self.token_expiry=0;self.receipt=None;self.load_error='';return self.public()
            if self.load_error:raise OwnerError(self.load_error)
            username=str(p.get('username') or self.values.get('username') or '').strip();password=p.get('password')
            # A changed seller ID may never inherit another seller's password.
            if password in (None,''):
                if username!=self.values.get('username') and self.values.get('password'):raise OwnerError('판매사 ID를 바꾸면 해당 계정의 비밀번호도 입력하세요.')
                password=self.values.get('password','')
            if not isinstance(password,str) or not username or not password or len(username)>200 or len(password)>512 or any(ord(c)<32 for c in username+password):raise OwnerError('오너클랜 판매사 ID와 비밀번호를 입력하세요.')
            values=dict(username=username,password=password);remember=bool(p.get('remember'))
            if remember and os.name!='nt':raise OwnerError('이 환경은 계정을 메모리에만 보관합니다. Windows 배포본에서 암호화 저장할 수 있습니다.')
            temp=self.path.with_suffix('.tmp')
            try:
                if remember:temp.write_bytes(dpapi(json.dumps(values).encode()));os.replace(temp,self.path)
                elif self.path.exists():self.path.unlink()
            except (OSError,ValueError):raise OwnerError('오너클랜 계정을 저장하지 못했습니다. 기존 계정은 유지합니다.') from None
            finally:
                try:temp.unlink(missing_ok=True)
                except OSError:pass
            self.values=values;self.token='';self.token_expiry=0;self.receipt=None;return self.public()
    def tested(self,success,message=''):self.receipt=dict(scope=self.fingerprint(),success=success,message=message,at=now(),epoch=time.monotonic())
    def authenticate(self,force=False):
        with self.lock:
            if not self.ready():raise OwnerAuthError('오너클랜 계정을 먼저 연결하세요.')
            if not force and self.token and self.token_expiry>time.time()+60:return self.token
            r=api_request(AUTH,dict(service='ownerclan',userType='seller',**self.values))
            token=r if isinstance(r,str) else (r.get('token') or r.get('access_token') or '') if isinstance(r,dict) else ''
            if not isinstance(token,str) or len(token)>16384 or not re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',token):raise OwnerAuthError('오너클랜 인증 토큰을 확인하지 못했습니다. 판매사 계정과 API 이용 설정을 확인하세요.')
            expiry=time.time()+300
            try:
                payload=json.loads(base64.urlsafe_b64decode(token.split('.')[1]+'==='));expiry=float(payload.get('exp',expiry))
            except (ValueError,TypeError):pass
            if expiry<=time.time():raise OwnerAuthError('오너클랜 인증 토큰이 만료되어 연결하지 못했습니다. PC 시간을 확인하세요.')
            self.token=token;self.token_expiry=expiry;return token

class OwnerClient:
    def __init__(self,account):self.account=account
    def items(self,codes):
        query='query WingDeskItems { itemsByKeys(keys: '+json.dumps(codes)+') { '+FIELDS+' } }'
        for attempt in range(2):
            token=self.account.authenticate(force=bool(attempt))
            try:r=api_request(API,{'query':query},token);break
            except OwnerAuthError as e:
                self.account.token='';self.account.token_expiry=0
                # Only an expired/rejected bearer token can justify one login refresh.
                # Permission denials (403) are never retried as password authentication.
                if attempt or e.stage!='items' or e.http_status!=401:raise
        if not isinstance(r,dict):raise OwnerError('상품 조회 응답 형식을 확인하지 못했습니다.')
        errors=r.get('errors') or []
        if not isinstance(errors,list):raise OwnerError('상품 조회 오류 응답 형식을 확인하지 못했습니다.')
        # Authentication/rate failures can also arrive in a GraphQL HTTP 200 response.
        for e in errors:
            ext=e.get('extensions') if isinstance(e,dict) else None
            code=ext.get('code') if isinstance(ext,dict) else None
            if code in ('UNAUTHENTICATED','FORBIDDEN'):
                raise OwnerAuthError('오너클랜 상품 조회 API가 인증·권한 오류를 반환했습니다. 연결을 다시 검사하세요.',stage='items')
            if code in ('TOO_MANY_REQUESTS','RATE_LIMITED'):
                raise OwnerRateError('오너클랜 상품 조회 요청이 제한되었습니다. 잠시 뒤 다시 실행하세요.',stage='items')
        data=r.get('data');values=data.get('itemsByKeys') if isinstance(data,dict) else None
        if not isinstance(values,list):
            # With no data key, GraphQL validation failed before executing any item.
            if errors and 'data' in r:
                raise OwnerPartialError('상품 묶음 조회에 오류가 있어 개별 조회로 분리합니다.'+field_error_hint(errors),{})
            raise OwnerError('상품 조회 요청 또는 응답 형식에 오류가 있습니다. API 규격·조회 권한을 확인하세요.'+field_error_hint(errors))
        result={};by_index={}
        for index,x in enumerate(values):
            if x is None:continue
            if not isinstance(x,dict) or x.get('key') not in codes or x['key'] in result:raise OwnerError('응답의 상품코드가 요청과 다르거나 중복되었습니다. 이 묶음은 가져오지 않습니다.')
            result[x['key']]=x;by_index[index]=x['key']
        if errors:
            partial=dict(result)
            for e in errors:
                path=e.get('path') if isinstance(e,dict) else None
                if not isinstance(path,list) or len(path)<2 or path[0]!='itemsByKeys' or type(path[1]) is not int or not 0<=path[1]<len(values):
                    partial={};break
                partial.pop(by_index.get(path[1]),None)
            raise OwnerPartialError('상품 응답의 일부 항목을 읽지 못했습니다. 해당 코드를 개별 조회합니다.'+field_error_hint(errors),partial)
        return result

def public_url(value):
    if not isinstance(value,str) or len(value)>4096:return ''
    if value.startswith('//'):value='https:'+value
    try:
        p=parse.urlsplit(value);host=(p.hostname or '').lower()
        if p.scheme not in ('http','https') or not host or p.username or p.password or p.port not in (None,80,443) or any(ord(c)<32 for c in value):return ''
        if host=='localhost' or '.' not in host or host.endswith(('.local','.internal','.localhost')):return ''
        try:
            if not ipaddress.ip_address(host.strip('[]')).is_global:return ''
        except ValueError:
            if re.fullmatch(r'[0-9.]+',host):return ''
    except ValueError:return ''
    return value

class CleanHTML(HTMLParser):
    tags={'div','span','p','br','hr','table','tbody','thead','tr','td','th','ul','ol','li','strong','b','em','i','u','h1','h2','h3','h4','img','center'}
    drop={'script','style','iframe','object','embed','form','textarea','noscript','svg','math','template'}
    void={'img','br','hr'}
    def __init__(self):super().__init__(convert_charrefs=True);self.parts=[];self.hidden=[];self.stack=[]
    def handle_starttag(self,tag,attrs):
        if self.hidden:
            if tag in self.drop:self.hidden.append(tag)
            return
        if tag in self.drop:self.hidden.append(tag);return
        if tag not in self.tags:return
        attrs=dict(attrs);kept=[]
        if tag=='img':
            src=public_url(attrs.get('src',''))
            if not src:return
            kept=[('src',src),('alt',str(attrs.get('alt') or '')[:200])]
        for k in ('width','height','colspan','rowspan'):
            if re.fullmatch(r'\d{1,5}%?',str(attrs.get(k,''))):kept.append((k,attrs[k]))
        styles=[]
        for entry in str(attrs.get('style','')).split(';'):
            if ':' not in entry:continue
            k,v=map(str.strip,entry.split(':',1))
            if k.lower() in ('width','max-width','height','margin','padding','text-align','font-size','font-weight','color','background-color') and re.fullmatch(r'[A-Za-z0-9#.,%\s-]{1,60}',v):styles.append(k+':'+v)
        if styles:kept.append(('style',';'.join(styles)))
        self.parts.append('<'+tag+''.join(' '+k+'="'+html.escape(v,quote=True)+'"' for k,v in kept)+'>')
        if tag not in self.void:self.stack.append(tag)
    def handle_endtag(self,tag):
        if self.hidden:
            if tag in self.hidden:
                while self.hidden:
                    if self.hidden.pop()==tag:break
            return
        if tag in self.stack:
            while self.stack:
                t=self.stack.pop();self.parts.append('</'+t+'>')
                if t==tag:break
    def handle_data(self,data):
        if not self.hidden:self.parts.append(html.escape(data))
    def result(self):return ''.join(self.parts)+''.join('</'+t+'>' for t in reversed(self.stack))

def clean_html(value):
    if not isinstance(value,str) or len(value.encode())>2*1024*1024:raise OwnerError('상세설명 형식 또는 크기를 확인하세요.')
    p=CleanHTML();p.feed(value);return p.result()

def won(v,label):
    if v is None or isinstance(v,bool):raise OwnerError(label+' 정보가 없습니다.')
    try:n=Decimal(str(v))
    except InvalidOperation:raise OwnerError(label+' 형식을 확인하세요.') from None
    if not n.is_finite() or n<0 or n>10**10 or n!=n.to_integral_value():raise OwnerError(label+'는 원 단위 금액이어야 합니다.')
    return int(n)

def map_item(x):
    """Map only the documented fields; unsupported conditions remain reviewable."""
    issues=[];code=x['key'];metadata=x.get('metadata') or {}
    if not isinstance(metadata,dict):metadata={}
    name=x.get('name');content=x.get('content');raw_options=x.get('options');status=x.get('status');policy=x.get('pricePolicy');shipping_type=x.get('shippingType')
    images=[clean for u in (x.get('images') or []) if (clean:=public_url(u))] if isinstance(x.get('images'),list) else []
    if not isinstance(name,str) or not name.strip():issues.append('상품명 없음')
    elif len(name.strip())>100:issues.append('상품명이 100자를 넘습니다. 상품명을 검토하세요.')
    if not images:issues.append('대표이미지 없음 또는 허용하지 않는 URL')
    try:detail=clean_html(content)
    except OwnerError as e:detail='';issues.append(str(e))
    if not html.unescape(re.sub(r'<[^>]*>','',detail)).strip() and '<img ' not in detail:issues.append('상세설명 없음')
    try:cost=won(x.get('price'),'공급가')
    except OwnerError as e:cost=None;issues.append(str(e))
    try:shipping=won(x.get('shippingFee'),'배송비')
    except OwnerError as e:shipping=None;issues.append(str(e))
    if policy!='free':issues.append('소비자 준수가격 상품: '+str(x.get('fixedPrice'))+'원' if policy=='fixed' else '가격 정책 확인 필요')
    if shipping_type not in ('inAdvance','free'):issues.append('착불 전용 또는 지원하지 않는 배송비 유형')
    if shipping_type=='free' and shipping not in (None,0):issues.append('무료 배송 표시와 배송비가 다릅니다.')
    for key,label in [('openmarketSellable','오픈마켓 판매 가능 여부'),('returnable','반품 가능 여부')]:
        if x.get(key) is not True:issues.append(label+' 확인 필요')
    if x.get('taxFree') is not False:issues.append('면세 여부 확인 필요 · 이 가져오기는 일반 과세 상품용입니다.')
    if x.get('adultOnly') is not False:issues.append('성인 상품 여부 확인 필요 · 이 가져오기는 일반 상품용입니다.')
    if status not in ('available','soldout','discontinued','unavailable'):issues.append('공급사 판매 상태 확인 필요')
    availability={'available':'정상','soldout':'품절','unavailable':'품절','discontinued':'단종'}.get(status,'품절')
    options=[];total=0
    if not isinstance(raw_options,list) or not raw_options:issues.append('옵션·재고 정보 없음')
    else:
        if len(raw_options)>200:issues.append('옵션이 200개를 넘습니다.')
        names=set()
        for i,o in enumerate(raw_options[:200]):
            try:
                if not isinstance(o,dict):raise OwnerError('옵션 형식을 확인하세요.')
                attrs=o.get('optionAttributes')
                if not isinstance(attrs,list) or any(not isinstance(a,dict) or not isinstance(a.get('name'),str) or not isinstance(a.get('value'),str) for a in attrs):raise OwnerError('입력형 또는 확인할 수 없는 옵션이 있습니다.')
                option_name=' / '.join(a['name']+': '+a['value'] for a in attrs) or '단일상품'
                if len(option_name)>150 or option_name in names:raise OwnerError('옵션명 길이 또는 중복을 확인하세요.')
                names.add(option_name);ocost=won(o.get('price'),'옵션 공급가');quantity=integer(o.get('quantity'),'옵션 재고',0,99999)
                if ocost<=0:raise OwnerError('옵션 공급가가 0원입니다.')
                if status!='available':quantity=0
                total+=quantity;options.append(dict(name=option_name,cost=ocost,stock=quantity,attributes=[],status='정상' if quantity else '품절'))
            except (ValueError,TypeError) as e:issues.append(f'옵션 {i+1}: '+str(e))
    if total>99999:issues.append('전체 재고가 99,999개를 넘습니다.')
    if cost is not None and cost<=0:issues.append('공급가가 0원입니다.')
    category=str(metadata.get('coupangCategoryCode') or '')
    if not re.fullmatch(r'[1-9]\d*',category):category=''
    brief=dict(code=code,name=name if isinstance(name,str) else '',cost=cost,shipping=shipping,stock=total,availability=availability,image=images[0] if images else '',price_policy=policy,fixed_price=x.get('fixedPrice'),shipping_type=shipping_type,category=category,options_count=len(raw_options) if isinstance(raw_options,list) else 0)
    p=None
    if not issues:
        p=normalize(dict(source=SOURCE,sku=code,name=name.strip(),cost=cost,markup=30,rounding=10,shipping=shipping,supplier_shipping=shipping,fee=10.8,stock=total,availability=availability,image=images[0],detail=detail,brand='',source_url=product_url(code),category=category,options=options,notices=[],certifications=[],attributes=[],documents=[],memo='오너클랜 공식 API 상품 조회 · '+now()+'\n제조사: '+str(x.get('production') or '')+' / 원산지: '+str(x.get('origin') or '')+'\n공급사 고시·인증 원문은 상품코드 보관함의 수집 상세에서 확인하세요.'))
    return dict(brief=brief,product=p,issues=list(dict.fromkeys(issues)),detail=detail,images=images,source_info={k:x.get(k) for k in ('model','production','origin','status','pricePolicy','fixedPrice','shippingType','boxQuantity','taxFree','adultOnly','returnable','openmarketSellable','category','options')},metadata={k:metadata.get(k) for k in ('productNotificationInformation','certificateInformation','vendorNotice','coupangCategoryCode','coupangCategoryFullName') if k in metadata})

class OwnerCatalog:
    def __init__(self,store,stock,batches):
        self.store,self.stock,self.batches=store,stock,batches;self.account=OwnerAccount(store);self.lock=threading.RLock();self.cancel=threading.Event();self.active=False;self.delete_tickets={}
        with store.connect() as db:
            db.executescript('CREATE TABLE IF NOT EXISTS owner_items(scope TEXT,code TEXT,data TEXT,fetched REAL,error TEXT,PRIMARY KEY(scope,code));CREATE TABLE IF NOT EXISTS owner_job(id INTEGER PRIMARY KEY,data TEXT);')
            r=db.execute('SELECT data FROM owner_job WHERE id=1').fetchone();self.job=json.loads(r[0]) if r else dict(state='대기',total=0,done=0,message='')
            if self.job.get('state')=='진행 중':self.job.update(state='중단됨',message='프로그램이 종료되었습니다. 수집된 내역을 확인하고 필요한 코드만 다시 수집하세요.');db.execute('UPDATE owner_job SET data=? WHERE id=1',(json.dumps(self.job,ensure_ascii=False),))
    def save_job(self):
        with self.store.connect() as db:db.execute('INSERT OR REPLACE INTO owner_job VALUES(1,?)',(json.dumps(self.job,ensure_ascii=False),))
    def save_account(self,p):
        with self.stock.lock:
            if self.stock.active or self.batches.active:raise OwnerError('진행 중인 작업이 끝난 뒤 오너클랜 계정을 변경하세요.')
            return self.account.save(p)
    def rows(self):
        if not self.account.ready():return []
        with self.store.connect() as db:rows=db.execute('SELECT * FROM owner_items WHERE scope=? ORDER BY fetched DESC,code',(self.account.fingerprint(),)).fetchall()
        return [dict(code=r['code'],mapped=json.loads(r['data']) if r['data'] else None,fetched=r['fetched'],error=r['error']) for r in rows]
    def listed_rows(self):
        products={r['sku'].upper():r for r in self.store.products() if r['source']==SOURCE};rows=[];current=time.time()
        for r in self.rows():
            m=r['mapped'];brief=m['brief'] if m else dict(code=r['code'],name='',cost=None,shipping=None,stock=0,availability='',image='');existing=products.get(r['code']);issues=m['issues'] if m else []
            if r['error']:state='수집 실패'
            elif existing:state='기존 상품 유지'
            elif current-r['fetched']>1800:state='다시 수집 필요'
            elif issues:state='조건 검토 필요'
            else:state='상품 추가 가능'
            rows.append(dict(**brief,status=state,issues=issues,error=r['error'],fetched_at=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(r['fetched'])),product_id=existing['id'] if existing else '',importable=state=='상품 추가 가능'))
        return rows
    def filtered_rows(self,p):
        q=str(p.get('search','')).upper();status=str(p.get('status',''))
        return [r for r in self.listed_rows() if (not q or q in r['code'] or q in r['name'].upper()) and (not status or r['status']==status)]
    def selection(self,p):
        if self.active:raise OwnerError('상품 수집이 끝난 뒤 전체 선택하세요.')
        rows=self.filtered_rows(p)
        if len(rows)>10000:raise OwnerError('검색 조건을 좁혀 10,000개 이하로 선택하세요.')
        return dict(rows=[dict(code=r['code'],importable=r['importable'],failed=bool(r['error'])) for r in rows])
    def state(self,p=None):
        p=p or {};rows=self.listed_rows();q=str(p.get('search','')).upper();status=str(p.get('status',''))
        filtered=[r for r in rows if (not q or q in r['code'] or q in r['name'].upper()) and (not status or r['status']==status)]
        size=50;page=min(integer(p.get('page',1),'페이지',1,100000),max(1,(len(filtered)+size-1)//size))
        job={k:v for k,v in self.job.items() if k!='scope'}
        if self.job.get('scope') and self.job['scope']!=self.account.fingerprint():job=dict(state='대기',total=0,done=0,message='현재 오너클랜 계정으로 상품을 수집하세요.')
        return dict(account=self.account.public(),active=self.active,job=job,rows=filtered[(page-1)*size:page*size],total=len(rows),failed=sum(bool(r['error']) for r in rows),review=sum(r['status']=='조건 검토 필요' for r in rows),filtered=len(filtered),ready=sum(r['importable'] for r in rows),page=page,size=size)
    def delete_preview(self,p):
        with self.stock.lock,self.lock:
            if self.stock.active or self.batches.active:raise OwnerError('진행 중인 작업이 끝난 뒤 오류 내역을 삭제하세요.')
            rows={r['code']:r for r in self.rows() if r['error']}
            if p.get('all_failed') is True:codes=list(rows)
            else:
                codes=p.get('codes')
                if not isinstance(codes,list) or not codes or len(codes)>10000 or any(not isinstance(c,str) or not re.fullmatch(r'W[A-Z0-9]{6}',c) for c in codes) or len(set(codes))!=len(codes):raise OwnerError('삭제할 오류 상품을 선택하세요.')
                codes=[c for c in codes if c in rows]
            if not codes:raise OwnerError('삭제할 오류 내역이 없습니다.')
            if len(codes)>10000:raise OwnerError('오류 내역을 10,000개 이하로 나누어 삭제하세요.')
            ticket=secrets.token_urlsafe(24);self.delete_tickets={k:v for k,v in self.delete_tickets.items() if v['expires']>time.monotonic()}
            while len(self.delete_tickets)>=8:self.delete_tickets.pop(next(iter(self.delete_tickets)))
            self.delete_tickets[ticket]=dict(scope=self.account.fingerprint(),codes=codes,expires=time.monotonic()+900)
            return dict(ticket=ticket,count=len(codes),sample=codes[:50])
    def delete_errors(self,p):
        with self.stock.lock,self.lock,self.store.lock:
            if self.stock.active or self.batches.active:raise OwnerError('진행 중인 작업이 끝난 뒤 오류 내역을 삭제하세요.')
            ticket=p.get('ticket');review=self.delete_tickets.get(ticket) if isinstance(ticket,str) else None
            if not review or review['expires']<=time.monotonic() or review['scope']!=self.account.fingerprint():raise OwnerError('삭제 확인이 만료되었거나 계정이 바뀌었습니다. 삭제 대상을 다시 확인하세요.')
            remove_codes=p.get('remove_codes',False)
            if not isinstance(remove_codes,bool):raise OwnerError('보관 코드 삭제 여부를 확인하세요.')
            self.delete_tickets.pop(ticket);deleted=0;codes_removed=0
            with self.store.connect() as db:
                for code in review['codes']:
                    # Recheck each row: an item that recovered after preview must survive.
                    r=db.execute("DELETE FROM owner_items WHERE scope=? AND code=? AND COALESCE(error,'')<>''",(review['scope'],code))
                    if r.rowcount:
                        deleted+=1
                        if remove_codes:codes_removed+=db.execute('DELETE FROM supplier_codes WHERE source=? AND code=?',(SOURCE,code)).rowcount
            return dict(deleted=deleted,skipped=len(review['codes'])-deleted,codes_removed=codes_removed,message=f'오류 수집 내역 {deleted}개 삭제 · 보관 코드 {codes_removed}개 삭제')
    def detail(self,code):
        r=next((r for r in self.rows() if r['code']==code),None)
        if not r:raise OwnerError('수집 내역이 없습니다. 코드를 다시 조회하세요.')
        if not r['mapped']:return dict(failure_only=True,code=code,error=r['error'] or '상품 정보가 조회되지 않았습니다.')
        return dict(**r['mapped'],error=r['error'])
    def start(self,p,test=False):
        codes=p.get('codes')
        if p.get('failed_only'):
            if test or codes is not None:raise OwnerError('실패 항목 재조회는 전체 실패 목록으로 실행하세요.')
            codes=[r['code'] for r in self.rows() if r['error']]
            if not codes:raise OwnerError('다시 조회할 실패 상품이 없습니다.')
        if codes is None:
            with self.store.connect() as db:codes=[r[0] for r in db.execute('SELECT code FROM supplier_codes WHERE source=? ORDER BY rowid',(SOURCE,))]
        if test:codes=(codes[:1] or ['W000000']) if isinstance(codes,list) else codes
        if not isinstance(codes,list) or not 1<=len(codes)<=10000 or any(not isinstance(c,str) or not re.fullmatch(r'W[A-Z0-9]{6}',c) for c in codes) or len(set(codes))!=len(codes):raise OwnerError('수집할 오너클랜 상품코드 1~10,000개를 선택하거나 먼저 TXT를 읽으세요.')
        if not self.account.ready():raise OwnerAuthError('오너클랜 계정을 먼저 연결하세요.')
        with self.stock.lock,self.lock:
            if self.stock.closed.is_set() or self.stock.active or self.batches.active:raise OwnerError('진행 중인 작업이 끝난 뒤 상품 정보를 수집하세요.')
            self.stock.active=True;self.active=True;self.cancel.clear();self.job=dict(state='진행 중',total=len(codes),done=0,success=0,failed=0,message='오너클랜 상품 정보를 조회합니다.',scope=self.account.fingerprint());self.save_job()
            try:threading.Thread(target=self.collect,args=(list(codes),test),daemon=True).start()
            except Exception:self.active=False;self.stock.active=False;raise
        return {'ok':True}
    def query_group(self,client,codes):
        if self.cancel.is_set():return
        try:result=client.items(codes)
        except OwnerPartialError as e:
            self.account.tested(True)
            # Preserve fully valid products before retrying unresolved codes.
            for code in codes:
                if self.cancel.is_set():return
                if code in e.partial:yield code,e.partial[code],''
            missing=[code for code in codes if code not in e.partial]
            if len(codes)==1:
                yield codes[0],None,str(e).replace('해당 코드를 개별 조회합니다.','개별 조회에서도 오류가 발생했습니다.');return
            for code in missing:
                if self.cancel.wait(.5):return
                self.job['message']='묶음 응답 오류 분리 · '+code+' 개별 조회';self.save_job()
                try:yield from self.query_group(client,[code])
                except (OwnerAuthError,OwnerRateError):raise
                except OwnerError as single:yield code,None,str(single)
            return
        self.account.tested(True)
        for code in codes:
            if self.cancel.is_set():return
            yield code,result.get(code),''
    def collect(self,codes,test=False):
        client=OwnerClient(self.account);scope=self.account.fingerprint();processed=set()
        try:
            for index in range(0,len(codes),25):
                if self.cancel.is_set():break
                group=codes[index:index+25];self.job['message']=f'상품 정보 조회 {index+1}~{index+len(group)} / {len(codes)}';self.save_job()
                try:
                    if test:
                        client.items(group);self.account.tested(True)
                        self.job['done']=len(group);self.job['success']=len(group);self.job['message']='오너클랜 인증·상품 조회 API 응답을 확인했습니다.';break
                    for code,value,message in self.query_group(client,group):
                        if self.cancel.is_set():break
                        if scope!=self.account.fingerprint():raise OwnerAuthError('오너클랜 계정이 변경되었습니다.')
                        mapped=None
                        try:
                            if message:raise OwnerError(message)
                            if value is None:raise OwnerError('상품이 조회되지 않았습니다. 삭제·품절로 단정하지 않습니다. 상품코드와 API 조회 권한을 확인하세요.')
                            mapped=map_item(value)
                        except (ValueError,TypeError,KeyError) as e:message=str(e) if isinstance(e,OwnerError) else '상품 정보가 없거나 형식이 올바르지 않습니다. 원본 상품과 API 조회 권한을 확인하세요.'
                        self.store_row(scope,code,mapped,message);processed.add(code);self.job['done']+=1;self.job['success' if mapped else 'failed']+=1
                except (OwnerAuthError,OwnerRateError) as e:
                    self.account.tested(False,str(e));self.job['message']=str(e)
                    if not test:
                        for code in codes[index:]:
                            if code not in processed:self.store_row(scope,code,None,str(e))
                    self.job['failed']+=len(codes)-self.job['done'];self.job['done']=len(codes);self.job['state']='실패';break
                except Exception as e:
                    message=str(e) if isinstance(e,OwnerError) else '오너클랜 상품 정보 조회 중 오류가 발생했습니다. 기존 상품은 유지합니다.';self.account.tested(False,message)
                    if not test:
                        for code in group:
                            if code not in processed:self.store_row(scope,code,None,message)
                    remaining=sum(code not in processed for code in group);self.job['done']+=remaining;self.job['failed']+=remaining;self.job['message']=message
                self.save_job()
                if self.cancel.wait(.5):break
            if self.job['state']=='진행 중':self.job['state']='중단됨' if self.cancel.is_set() else '완료' if not self.job['failed'] else '일부 실패'
            if not test and self.job['state'] in ('완료','일부 실패'):self.job['message']=f"상품 정보 수집 완료 · 조회 성공 {self.job['success']}개 · 실패 {self.job['failed']}개. 실패 항목만 보기에서 원인을 확인하고 다시 조회할 수 있습니다."
        except Exception:self.job.update(state='실패',message='수집 결과를 저장하지 못했습니다. 저장 공간과 기존 수집 내역을 확인하세요.')
        finally:
            try:self.save_job()
            finally:
                with self.stock.lock,self.lock:self.active=False;self.stock.active=False
    def store_row(self,scope,code,mapped,message):
        with self.store.connect() as db:
            if mapped:db.execute('INSERT OR REPLACE INTO owner_items VALUES(?,?,?,?,?)',(scope,code,json.dumps(mapped,ensure_ascii=False),time.time(),message))
            else:
                db.execute('INSERT OR IGNORE INTO owner_items VALUES(?,?,?,?,?)',(scope,code,'',time.time(),message));db.execute('UPDATE owner_items SET error=? WHERE scope=? AND code=?',(message,scope,code))
    def commit(self,p):
        codes=p.get('codes')
        if p.get('all_ready'):
            existing={r['sku'].upper() for r in self.store.products() if r['source']==SOURCE}
            codes=[r['code'] for r in self.rows() if r['code'] not in existing and not r['error'] and r['mapped'] and r['mapped']['product'] and time.time()-r['fetched']<=1800][:1000]
        if not isinstance(codes,list) or not codes or len(codes)>1000 or len(set(codes))!=len(codes):raise OwnerError('추가할 상품을 1~1,000개 선택하세요.')
        with self.stock.lock,self.store.lock:
            if self.stock.active or self.batches.active:raise OwnerError('진행 중인 작업이 끝난 뒤 상품을 추가하세요.')
            rows={r['code']:r for r in self.rows()};products={r['sku'].upper() for r in self.store.products() if r['source']==SOURCE};prepared=[];skipped=0;added_ids=[]
            for code in codes:
                if code in products:skipped+=1;continue
                r=rows.get(code)
                if not r or r['error'] or not r['mapped'] or not r['mapped']['product'] or time.time()-r['fetched']>1800:raise OwnerError('추가할 수 없는 상품이 포함되어 있습니다. 수집 결과와 검토 조건을 확인하고 30분 지난 내역은 다시 수집하세요.')
                prepared.append(normalize(r['mapped']['product']))
            with self.store.connect() as db:
                for product in prepared:
                    id=uuid.uuid4().hex;db.execute('INSERT INTO products(id,source,sku,data,created,updated) VALUES(?,?,?,?,?,?)',(id,product['source'],product['sku'],json.dumps(product,ensure_ascii=False),now(),now()));added_ids.append(id)
        return dict(added=len(prepared),ids=added_ids,skipped=skipped,message=f'상품 {len(prepared)}개 추가 · 기존 상품 {skipped}개 유지. 마진·쿠팡 카테고리·고시·인증정보를 확인한 뒤 등록하세요.')
