from pathlib import Path
import os, sys, traceback, json
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'lib'))
if os.name=='nt':sys.path.insert(0,str(root/'lib-win'))
sys.path.insert(0,str(root))
error_path=None
if '--error-file' in sys.argv:
    index=sys.argv.index('--error-file')
    error_path=Path(sys.argv[index+1])
    del sys.argv[index:index+2]
try:
    import app
    app.main()
except Exception as error:
    directory=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'WingDesk'
    directory.mkdir(parents=True,exist_ok=True)
    (directory/'startup-error.log').write_text(traceback.format_exc(),encoding='utf-8')
    if error_path:
        try:error_path.write_text(json.dumps({'type':type(error).__name__,'message':str(error)},ensure_ascii=False),encoding='utf-8')
        except OSError:pass
    sys.exit(1)
