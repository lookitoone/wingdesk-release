from __future__ import annotations
import argparse, base64, csv, io, json, os, re, secrets, sqlite3, sys, tempfile, threading, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from core import Store, Credentials, Coupang, Batches, BASE, VERSION, HEADERS, read_table, import_rows, validate, payload, safe_cell, template_bytes
from shipping import Shipping,COURIERS,return_mode
from stockwatch import StockWatch
from automation import Automation
from orders import Orders
from suppliercodes import SupplierCodes
from ownercatalog import OwnerCatalog
from registration import Registration,metadata

ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
def open_window(url):
    import subprocess
    for root in [os.getenv('PROGRAMFILES(X86)','C:/Program Files (x86)'),os.getenv('PROGRAMFILES','C:/Program Files'),os.getenv('LOCALAPPDATA','')]:
        program=Path(root)/'Microsoft/Edge/Application/msedge.exe'
        if program.exists():
            try:subprocess.Popen([str(program),'--app='+url,'--start-maximized']);return
            except OSError:pass
    if not webbrowser.open(url):raise RuntimeError('인터넷 화면을 여는 프로그램을 찾을 수 없습니다.')

def existing_session(directory):
    from urllib import request
    try:
        state=json.loads((Path(directory)/'session.json').read_text(encoding='utf-8'))
        port=int(state['port']);token=state['token']
        if not 1<=port<=65535 or not isinstance(token,str) or len(token)>128:return False
        req=request.Request(f'http://127.0.0.1:{port}/api/state',headers={'Cookie':f'wingdesk={token}; wingdesk_{port}={token}','X-WingDesk-Session':token})
        with request.build_opener(request.ProxyHandler({})).open(req,timeout=2) as response:
            data=json.load(response)
            if not data.get('settings',{}).get('version'):return None
        return dict(port=port,token=token,state=data)
    except (OSError,ValueError,KeyError,TypeError):return None

def reopen_existing(directory,ready_file=None):
    state=existing_session(directory)
    if not state:return False
    url=f"http://127.0.0.1:{state['port']}/?token={state['token']}"
    if ready_file:
        from urllib import request
        if state['state']['settings']['version']!=VERSION:
            raise RuntimeError('이전 버전이 실행 중입니다. 진행 중인 전송을 마친 뒤 프로그램을 종료하고 다시 실행해 주세요.')
        marker=Path(ready_file)
        if marker.parent.resolve()!=Path(directory).resolve():raise ValueError('실행 확인 파일 위치가 올바르지 않습니다.')
        req=request.Request(f"http://127.0.0.1:{state['port']}/api/prepare-open",json.dumps({'marker':marker.name}).encode(),
            headers={'X-WingDesk-Session':state['token'],'Content-Type':'application/json','X-WingDesk':'1'})
        with request.build_opener(request.ProxyHandler({})).open(req,timeout=3) as response:launch=json.load(response)['launch']
        url+='&launch='+launch
    open_window(url)
    if ready_file:
        deadline=time.monotonic()+25
        while not Path(ready_file).exists():
            if time.monotonic()>deadline:raise RuntimeError('상품 관리 화면 연결을 확인하지 못했습니다. 열린 WingDesk 창을 확인하고 다시 시도해 주세요.')
            threading.Event().wait(.1)
    return True

def stop_previous_version(directory):
    """Gracefully replace an idle older server; never interrupt a transmission."""
    from urllib import request
    state=existing_session(directory)
    if not state or state['state'].get('active') or state['state'].get('stock_active') or state['state']['settings']['version']==VERSION:return False
    req=request.Request(f"http://127.0.0.1:{state['port']}/api/shutdown",data=b'{}',
        headers={'Cookie':f"wingdesk={state['token']}; wingdesk_{state['port']}={state['token']}",'X-WingDesk-Session':state['token'],'Content-Type':'application/json','X-WingDesk':'1'})
    try:
        with request.build_opener(request.ProxyHandler({})).open(req,timeout=3) as response:
            return bool(json.load(response).get('ok'))
    except (OSError,ValueError):return False

def notify_error(message):
    if os.name=='nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,message,'WingDesk 실행 안내',0x10)
    elif sys.stderr:print(message,file=sys.stderr)

def instance_lock(directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    lock=(directory/'instance.lock').open('a+b');lock.seek(0)
    if os.name=='nt':
        import msvcrt
        # Windows enforces byte locks on reads too. Lock directly, including
        # an empty file; the CRT explicitly permits locking beyond EOF.
        lock.seek(0)
        try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:lock.close();raise RuntimeError('WingDesk가 이미 실행 중입니다. 기존 창을 확인하세요.')
    else:
        import fcntl
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:lock.close();raise RuntimeError('WingDesk가 이미 실행 중입니다. 기존 창을 확인하세요.')
    return lock

class Application:
    def __init__(self,directory):
        self.store=Store(directory);self.credentials=Credentials(directory);self.batches=Batches(self.store,self.credentials)
        self.token=secrets.token_urlsafe(32);self.imports={};self.import_lock=threading.Lock();self.port=0
        self.ready_file=None
        self.pending_ready={};self.ready_lock=threading.Lock()
        self.shipping=Shipping(self.store,self.credentials)
        self.stock=StockWatch(self.store,self.credentials,self.batches)
        self.automation=Automation(self.store,self.credentials,self.batches,self.stock)
        self.orders=Orders(self.store,self.credentials,self.batches,self.stock)
        self.codes=SupplierCodes(self.store)
        self.catalog=OwnerCatalog(self.store,self.stock,self.batches)
        self.registration=Registration(self)
    def public_settings(self):
        settings=self.store.settings()
        for key in ('outbound_pending','access_key','secret_key','clear_keys'):settings.pop(key,None)
        return {**settings,'has_keys':self.credentials.ready(),'version':VERSION,'encrypted':os.name=='nt',
            'has_access_key':bool(self.credentials.values.get('access_key')),'has_secret_key':bool(self.credentials.values.get('secret_key')),
            'key_load_error':self.credentials.load_error,
            'connection':self.shipping.connection_state(),
            'courier_choices':[dict(value=k,name=v) for k,v in COURIERS],'effective_return_mode':return_mode(settings)}
    def endpoint(self,path,p):
        st=self.store
        if path=='/api/jobs/state':
            jobs=st.jobs();active=self.batches.active
            chosen=next((j for j in jobs if j['id']==p.get('id')),None)
            chosen=chosen or next((j for j in jobs if j['id']==active),None) or (jobs[0] if jobs else None)
            return dict(active=active,stock_active=self.stock.active,
                jobs=[{k:v for k,v in j.items() if k!='results'} for j in jobs],
                job=chosen if p.get('detail') is True else None)
        if path.startswith('/api/registration/'):
            action={'state':self.registration.state,'editor':self.registration.editor,'autofill':self.registration.autofill,'prepare':self.registration.prepare,'keywords':self.registration.keywords,'exclusion':self.registration.exclusion,'policy':self.registration.save_policy,'review':self.registration.review,'commit':self.registration.commit,'recommend':self.registration.recommend,'common':self.registration.common}.get(path.rsplit('/',1)[-1])
            if not action:raise ValueError('지원하지 않는 상품 등록 작업입니다.')
            return action(p)
        if path.startswith('/api/catalog/'):
            c=self.catalog
            if path=='/api/catalog/state':return c.state(p)
            if path=='/api/catalog/account':return c.save_account(p)
            if path=='/api/catalog/test':return c.start(p,test=True)
            if path=='/api/catalog/start':return c.start(p)
            if path=='/api/catalog/cancel':c.cancel.set();return {'ok':True}
            if path=='/api/catalog/detail':return c.detail(p.get('code'))
            if path=='/api/catalog/import':return c.commit(p)
            if path=='/api/catalog/selection':return c.selection(p)
            if path=='/api/catalog/delete/preview':return c.delete_preview(p)
            if path=='/api/catalog/delete/commit':return c.delete_errors(p)
            raise ValueError('지원하지 않는 상품 수집 작업입니다.')
        if path=='/api/codes/state' :return self.codes.state(p)
        if path=='/api/codes/preview':return self.codes.preview(p)
        if path=='/api/codes/commit':return self.codes.commit(p)
        if path.startswith('/api/stores/'):
            o=self.orders
            if path=='/api/stores/state':return o.registry.state()
            if path=='/api/stores/save':
                with self.stock.lock:
                    if self.stock.active or self.batches.active:raise ValueError('진행 중인 작업이 끝난 뒤 상점을 저장하세요.')
                    return o.registry.save(p)
            if path=='/api/stores/test':return o.test(p.get('id'))
            raise ValueError('지원하지 않는 상점 작업입니다.')
        if path.startswith('/api/orders/'):
            o=self.orders
            if path=='/api/orders/state':return o.query(p)
            if path=='/api/orders/detail':
                r=o.get(p.get('id'));r.pop('scope',None);return r
            if path=='/api/orders/sync':return o.sync(p)
            if path=='/api/orders/cancel':o.cancel.set();return {'ok':True}
            if path=='/api/orders/settings':return o.save_settings(p)
            if path=='/api/orders/memo':return o.memo(p)
            if path=='/api/orders/refresh':return o.refresh_one(p.get('id'))
            if path=='/api/orders/prepare':return o.prepare(p)
            if path=='/api/orders/execute':return o.execute(p)
            if path=='/api/orders/reconcile':return o.reconcile(p.get('id'))
            if path=='/api/orders/import-preview':return o.import_preview(p)
            if path=='/api/orders/import':return o.import_commit(p)
            raise ValueError('지원하지 않는 주문 작업입니다.')
        if path.startswith('/api/automation/'):
            a=self.automation
            if path=='/api/automation/state':return dict(a.state(),candidates=a.candidates() if st.settings().get('vendor_id') else [])
            if path=='/api/automation/settings':return a.save(p)
            if path=='/api/automation/start':return a.start(p)
            if path=='/api/automation/cancel':a.cancel.set();return {'ok':True}
            if path=='/api/automation/queue':return a.queue(p)
            if path=='/api/automation/exclude':return a.exclude(p)
            if path=='/api/automation/feed-preview':return a.feed_preview(p)
            if path=='/api/automation/feed':return a.feed(p)
            if path=='/api/automation/prepare-manual':return a.prepare_manual(p)
            raise ValueError('지원하지 않는 자동 관리 작업입니다.')
        if path=='/api/prepare-open':
            marker=p.get('marker','')
            if not isinstance(marker,str) or not re.fullmatch(r'ready-[a-f0-9]{32}',marker):raise ValueError('실행 확인 파일 이름이 올바르지 않습니다.')
            launch=secrets.token_urlsafe(16)
            with self.ready_lock:
                self.pending_ready={k:v for k,v in self.pending_ready.items() if v[1]>time.monotonic()}
                if len(self.pending_ready)>=8:raise ValueError('열린 실행 준비 화면을 먼저 확인해 주세요.')
                self.pending_ready[launch]=(st.directory/marker,time.monotonic()+30)
            return {'launch':launch}
        if path=='/api/ui-ready':
            with self.ready_lock:
                if self.ready_file:
                    Path(self.ready_file).write_text('ready',encoding='utf-8');self.ready_file=None
                pending=self.pending_ready.pop(p.get('launch',''),None)
                if pending and pending[1]>time.monotonic():pending[0].write_text('ready',encoding='utf-8')
            return {'ok':True}
        if path.startswith('/api/stock/'):
            if path=='/api/stock/state':return self.stock.state()
            if path=='/api/stock/settings':return self.stock.settings(p)
            if path=='/api/stock/configure':return self.stock.configure(p)
            if path=='/api/stock/check':return self.stock.start(p.get('ids'))
            if path=='/api/stock/cancel':self.stock.cancel.set();return {'ok':True}
            if path=='/api/stock/prepare':return self.stock.prepare(p.get('id'),bool(p.get('delete')))
            if path=='/api/stock/execute':return self.stock.execute(p.get('ticket'))
            raise ValueError('지원하지 않는 품절 관리 작업입니다.')
        if path in ('/api/products/save','/api/products/delete','/api/products/bulk'):
            with self.stock.lock:
                if self.stock.active:raise ValueError('품절 확인 작업이 끝난 뒤 상품을 수정해 주세요.')
                if path=='/api/products/save':return st.save(p['product'],p.get('id'))
                if path=='/api/products/delete':st.delete(p['ids']);return {'ok':True}
                return {'updated':st.bulk(p['ids'],p['changes'])}
        if path=='/api/settings':
            if self.stock.active:raise ValueError('품절 관리 작업이 끝난 뒤 연결 설정을 저장해 주세요.')
            try:self.shipping.save(p)
            except (ValueError,OSError):
                from apierrors import record
                record(st.directory,VERSION,'LOCAL','/settings','설정 저장에 실패했습니다. 입력값과 Windows 저장 권한을 확인하세요.')
                raise
            return self.public_settings()
        if path.startswith('/api/shipping/'):
            if self.batches.active or self.stock.active:raise ValueError('진행 중인 작업이 끝난 뒤 주소를 연결해 주세요.')
            if path=='/api/shipping/test':return self.shipping.check()
            if path=='/api/shipping/list':return self.shipping.load(p.get('kind'))
            if path=='/api/shipping/choose':self.shipping.choose(p.get('selection'));return self.public_settings()
            if path=='/api/shipping/prepare-outbound':return self.shipping.prepare()
            if path=='/api/shipping/register-outbound':return self.shipping.register(p.get('ticket'))
            raise ValueError('지원하지 않는 주소 작업입니다.')
        if path=='/api/meta':
            cat=str(p['category'])
            if not cat.isdigit() or int(cat)<=0:raise ValueError('노출 카테고리코드를 입력하세요.')
            r=Coupang(self.credentials).call('GET',BASE+'/meta/category-related-metas/display-category-codes/'+cat)
            if not isinstance(r.get('data'),dict):raise ValueError('카테고리 응답 형식을 확인하세요.')
            value=metadata(r['data']);st.meta(cat,value);return value
        if path=='/api/validate':
            s=st.settings();return {'results':[dict(id=id,sku=(pr:=st.get(id))['sku'],issues=validate(pr,s,st.meta(pr['category']))) for id in p['ids']]}
        if path=='/api/payload':
            pr=st.get(p['id']);return {'payload':payload(pr,st.settings()),'issues':validate(pr,st.settings(),st.meta(pr['category']))}
        if path=='/api/import/preview':
            raw=base64.b64decode(p['data'],validate=True)
            table=read_table(raw,p['filename'],p.get('sheet'),p.get('header_row',1))
            key=secrets.token_urlsafe(16)
            with self.import_lock:
                self.imports.clear();self.imports[key]=table
            return dict(id=key,headers=table['headers'],sample=table['rows'][:5],sheets=table['sheets'],mapping=table['mapping'],count=len(table['rows']))
        if path=='/api/import/commit':
            with self.import_lock:
                table=self.imports.get(p['id'])
                if table is None:raise ValueError('파일을 다시 선택하세요.')
                r=import_rows(st,table['rows'],p['mapping'],p['source']);self.imports.pop(p['id'],None)
            return r
        if path=='/api/batches':
            if self.stock.active:raise ValueError('품절 확인 작업이 끝난 뒤 등록해 주세요.')
            live=bool(p.get('live'))
            if live:
                self.registration.ids(p)
                # Category metadata is refreshed immediately before real creation.
                for c in {st.get(id)['category'] for id in p['ids']}:
                    if not c.isdigit():raise ValueError('카테고리코드를 입력하세요.')
                    r=Coupang(self.credentials).call('GET',BASE+'/meta/category-related-metas/display-category-codes/'+c)
                    if not isinstance(r.get('data'),dict):raise ValueError('카테고리 응답을 확인할 수 없습니다.')
                    st.meta(c,r['data'])
            with self.stock.lock:
                if self.stock.active:raise ValueError('품절 확인 작업이 끝난 뒤 등록해 주세요.')
                return self.batches.start(p['ids'],live,bool(p.get('requested')))
        if path=='/api/batches/stop':self.batches.cancel.set();return {'ok':True}
        if path=='/api/reconcile':
            if self.stock.active:raise ValueError('품절 관리 작업이 끝난 뒤 등록 결과를 연결해 주세요.')
            with self.stock.lock,st.lock:
                if self.stock.active:raise ValueError('품절 관리 작업이 끝난 뒤 등록 결과를 연결해 주세요.')
                pr=st.get(p['id']);rid=str(p.get('remote_id') or pr.get('remote_id') or '')
                if not rid.isdigit():raise ValueError('Wing에 표시된 등록상품 ID를 입력하세요.')
                if pr.get('remote_id') and str(pr['remote_id'])!=rid:raise ValueError('이미 연결된 쿠팡 상품 ID와 다릅니다. Wing에서 기존 등록 상품을 확인해 주세요.')
                r=Coupang(self.credentials).call('GET',BASE+'/seller-products/'+rid)
                data=r.get('data',{})
                if data.get('vendorId')!=st.settings().get('vendor_id'):raise ValueError('현재 업체의 상품이 아닙니다.')
                expected=pr['source']+':'+pr['sku']+':'
                if not any(str(x.get('externalVendorSku','')).startswith(expected) for x in data.get('items',[])):
                    raise ValueError('조회한 상품의 공급사/상품코드가 일치하지 않습니다. 다른 상품 ID를 연결할 수 없습니다.')
                st.state(pr['id'],str(data.get('statusName') or '등록됨·확인 필요'),rid);return st.get(pr['id'])
        if path=='/api/demo':
            for i,(name,cost,stock,state) in enumerate([('데스크 정리 트레이',7200,40,'정상'),('스테인리스 텀블러 500ml',11000,12,'정상'),('접이식 수납 바구니',4900,0,'품절')]):
                try:st.save(dict(sku=f'DEMO-{i+1:03}',name=name,source='연습 데이터',cost=cost,stock=stock,availability=state,demo=True))
                except sqlite3.IntegrityError:pass
            return {'ok':True}
        if path=='/api/shutdown':
            if self.batches.active or self.stock.active:raise ValueError('작업이 진행 중입니다. 먼저 중단한 후 결과 저장이 끝나면 종료하세요.')
            with self.stock.lock,self.batches.lock:
                if self.batches.active or self.stock.active:raise ValueError('작업이 진행 중입니다. 먼저 중단한 후 결과 저장이 끝나면 종료하세요.')
                self.stock.closed.set()
            return {'ok':True}
        raise ValueError('지원하지 않는 작업입니다.')

def handler_for(app):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def matches_session(self,value):
            try:return secrets.compare_digest(value,app.token)
            except (TypeError,ValueError):return False
        def respond(self,body,status=200,type='application/json; charset=utf-8',filename=None,set_session=False):
            if isinstance(body,(dict,list)):body=json.dumps(body,ensure_ascii=False).encode()
            elif isinstance(body,str):body=body.encode()
            self.send_response(status);self.send_header('Content-Type',type);self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            if set_session:self.send_header('Set-Cookie',f'wingdesk_{app.port}={app.token}; HttpOnly; SameSite=Lax; Path=/')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: http: data:; connect-src 'self'; frame-src 'none'; frame-ancestors 'none'; object-src 'none'")
            if filename:self.send_header('Content-Disposition','attachment; filename="'+filename+'"')
            self.end_headers();self.wfile.write(body)
        def trusted_host(self):return self.headers.get('Host')==f'127.0.0.1:{app.port}'
        def authorized(self):
            token=self.headers.get('X-WingDesk-Session','')
            if self.matches_session(token):return True
            try:c=SimpleCookie(self.headers.get('Cookie',''));return self.matches_session(c[f'wingdesk_{app.port}'].value)
            except (KeyError,ValueError,TypeError):return False
        def do_GET(self):
            if not self.trusted_host():return self.respond({'error':'Invalid host'},403)
            parts=urlsplit(self.path);path=parts.path
            launch_token=self.matches_session(parse_qs(parts.query).get('token',[''])[0])
            # This public script contains no session/data. It can restore a
            # same-tab session after a cookie-free refresh, but the server
            # still validates the recovered token before serving any data.
            if path=='/session-recovery.js':return self.respond((ROOT/'ui/session-recovery.js').read_bytes(),type='text/javascript; charset=utf-8')
            if not self.authorized() and not launch_token:
                if path=='/':return self.respond((ROOT/'ui/session-expired.html').read_bytes(),401,'text/html; charset=utf-8')
                return self.respond({'error':'화면 연결이 만료되었습니다. WingDesk 실행 아이콘을 다시 눌러 주세요.'},401)
            try:
                if path=='/api/state':return self.respond(dict(products=app.store.products(),settings=app.public_settings(),jobs=app.store.jobs(),active=app.batches.active,stock_active=app.stock.active))
                if path=='/download/connection-errors.txt':
                    from apierrors import report
                    return self.respond(report(app.store.directory,VERSION),type='text/plain; charset=utf-8',filename='WingDesk-connection-errors.txt')
                if path=='/download/template.xlsx':return self.respond(template_bytes(),type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',filename='WingDesk-template.xlsx')
                if path=='/download/products.csv':
                    o=io.StringIO();w=csv.writer(o);keys=['sku','name','source','cost','markup','sale_price','shipping','supplier_shipping','fee','profit','stock','availability','state','remote_id','created']
                    w.writerow(['상품코드','상품명','공급사','원가','마진율','판매가','배송비','공급사배송비','예상수수료율','예상이익','재고','공급상태','등록상태','쿠팡등록상품ID','추가일'])
                    for p in app.store.products():w.writerow([safe_cell(p.get(k,'')) for k in keys])
                    return self.respond(o.getvalue().encode('utf-8-sig'),type='text/csv; charset=utf-8',filename='WingDesk-products.csv')
                if path=='/download/results.csv':
                    o=io.StringIO();w=csv.writer(o);w.writerow(['작업ID','작업시간','작업구분','상품코드','상품명','결과','쿠팡등록상품ID','메시지'])
                    for j in app.store.jobs():
                        for r in j['results']:w.writerow([safe_cell(x) for x in [j['id'],j['created'],j['mode'],r['sku'],r['name'],r['state'],r['remote_id'],r['message']]])
                    return self.respond(o.getvalue().encode('utf-8-sig'),type='text/csv; charset=utf-8',filename='WingDesk-results.csv')
                if path=='/download/backup.sqlite3':
                    with tempfile.TemporaryDirectory() as temp:
                        dest=sqlite3.connect(Path(temp)/'backup.db')
                        with app.store.connect() as src:src.backup(dest)
                        dest.close();raw=(Path(temp)/'backup.db').read_bytes()
                    return self.respond(raw,type='application/octet-stream',filename='WingDesk-backup.sqlite3')
                if path in ('/download/orders.xlsx','/download/order-template.xlsx'):
                    params={k:v[0] for k,v in parse_qs(parts.query).items() if k!='token'}
                    return self.respond(app.orders.export(params,path.endswith('order-template.xlsx')),type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',filename='WingDesk-order-template.xlsx' if path.endswith('order-template.xlsx') else 'WingDesk-orders.xlsx')
                names={'/registration.js':'registration.js','/catalog.js':'catalog.js','/codes.js':'codes.js','/orders.js':'orders.js','/stores.js':'stores.js','/':'index.html' ,'/app.js':'app.js','/automation.js':'automation.js','/style.css':'style.css'}
                if path not in names:return self.respond('Not found',404,'text/plain')
                f=ROOT/'ui'/names[path]
                if path=='/':
                    html=f.read_text(encoding='utf-8').replace('<head>',f'<head><meta name="wingdesk-session" content="{app.token}">',1)
                    html=html.replace('href="/style.css"',f'href="/style.css?token={app.token}"').replace('src="/app.js"',f'src="/app.js?token={app.token}"')
                    for script in ('automation','orders','stores','codes','catalog','registration'):html=html.replace('src="/'+script+'.js"',f'src="/{script}.js?token={app.token}"')
                    return self.respond(html,type='text/html; charset=utf-8',set_session=True)
                return self.respond(f.read_bytes(),type='text/css; charset=utf-8' if path=='/style.css' else 'text/javascript; charset=utf-8')
            except Exception:return self.respond({'error':'파일 또는 데이터 읽기 오류입니다.'},500)
        def do_POST(self):
            if not self.trusted_host() or not self.authorized() or self.headers.get('X-WingDesk')!='1':return self.respond({'error':'Unauthorized'},403)
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://127.0.0.1:{app.port}':return self.respond({'error':'Invalid origin'},403)
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<=0 or length>18*1024*1024:raise ValueError('요청 크기가 허용 범위를 벗어났습니다.')
                p=json.loads(self.rfile.read(length))
                if not isinstance(p,dict):raise ValueError('올바르지 않은 요청입니다.')
                path=urlsplit(self.path).path
                self.respond(app.endpoint(path,p))
                if path=='/api/shutdown':
                    # Finish the acknowledgement before the main process can
                    # exit and abandon this daemon HTTP handler.
                    self.wfile.flush()
                    threading.Thread(target=app.server.shutdown,daemon=True).start()
                return
            except sqlite3.IntegrityError:return self.respond({'error':'동일 공급사의 상품코드가 이미 있습니다.'},400)
            except (ValueError,KeyError,TypeError) as ex:return self.respond({'error':str(ex)},400)
            except Exception as ex:
                from core import RemoteRejected,Uncertain
                msg=str(ex) if isinstance(ex,(RemoteRejected,Uncertain)) else '작업 오류입니다. 입력값과 연결 설정을 확인하세요.'
                return self.respond({'error':msg},400)
    return Handler

def main():
    p=argparse.ArgumentParser();p.add_argument('--no-open',action='store_true');p.add_argument('--data-dir');p.add_argument('--ready-file');p.add_argument('--port',type=int,default=0);args=p.parse_args()
    directory=args.data_dir or Path(os.getenv('LOCALAPPDATA',str(Path.home()/'.local/share')))/'WingDesk'
    try:lock=instance_lock(directory)
    except RuntimeError as ex:
        lock=None
        if not args.no_open and stop_previous_version(directory):
            for attempt in range(50):
                try:lock=instance_lock(directory);break
                except RuntimeError:threading.Event().wait(0.1)
        if lock is None:
            if not args.no_open and reopen_existing(directory,args.ready_file):
                return
            raise RuntimeError('프로그램이 준비 중입니다. 잠시 뒤 WingDesk 실행을 다시 눌러 주세요.') from ex
    app=Application(directory);server=ThreadingHTTPServer(('127.0.0.1',args.port),handler_for(app));app.port=server.server_address[1];app.server=server
    url=f'http://127.0.0.1:{app.port}/?token={app.token}'
    session=Path(directory)/'session.json'
    session.write_text(json.dumps({'port':app.port,'token':app.token}),encoding='utf-8')
    if os.name!='nt':session.chmod(0o600)
    if not args.no_open:
        app.ready_file=args.ready_file
        open_window(url)
    else:print(url,flush=True)
    app.stock.start_background()
    app.automation.start_background()
    app.orders.start_background()
    try:server.serve_forever()
    except KeyboardInterrupt:
        app.batches.cancel.set();app.stock.cancel.set();app.orders.cancel.set();app.catalog.cancel.set();app.stock.closed.set()
        while app.batches.active or app.stock.active:threading.Event().wait(0.2)
    finally:app.stock.closed.set();server.server_close();session.unlink(missing_ok=True);lock.close()
if __name__=='__main__':
    try:main()
    except Exception:
        import traceback
        directory=Path(os.getenv('LOCALAPPDATA',str(Path.home()/'.local/share')))/'WingDesk'
        directory.mkdir(parents=True,exist_ok=True)
        (directory/'startup-error.log').write_text(traceback.format_exc(),encoding='utf-8')
        notify_error('프로그램을 열지 못했습니다. WingDesk 실행을 다시 눌러 주세요.\n계속 문제가 생기면 실행 준비 화면에서 오류 기록 열기를 눌러 주세요.')
        sys.exit(1)
