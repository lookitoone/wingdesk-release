"""Coupang registration workspace: local readiness and reviewed creation."""
from __future__ import annotations
import copy,hashlib,json,re,secrets,threading,time
from core import BASE,Coupang,normalize,now,payload,validate
from productinfo import DEFAULT_POLICY,fill_product,policy,source_info,search_tags

PREDICT='/v2/providers/openapi/apis/api/v1/categorization/predict'
SETTING_FIELDS=[('vendor_id','업체코드'),('wing_id','Wing ID'),('courier','택배사'),('outbound','출고지 주소 연결'),('return_center','반품지 주소 연결'),('return_name','반품지명'),('contact','반품 연락처'),('zipcode','반품 우편번호'),('address','반품 주소'),('address_detail','반품 상세주소')]
LOCKED=('전송 중','전송 대기','결과 확인 필요')

def requirement(message,product,meta):
    """Explain a validation result without choosing factual product values."""
    target='base';label='상품 정보';help='공급사에서 확인한 상품 정보로 입력하세요.';name=''
    if '연습 상품' in message:target='demo';label='실제 상품 가져오기';help='연습용 상품은 쿠팡에 등록할 수 없습니다.'
    elif '이미 전송' in message:target='status';label='등록 결과 확인';help='같은 상품을 다시 보내기 전에 등록 현황에서 결과를 확인하세요.'
    elif '카테고리 정보 조회' in message:target='meta';label='쿠팡 필수항목 불러오기';help='상품 분류에 맞는 입력 항목을 쿠팡에서 불러와야 합니다.'
    elif '카테고리코드' in message:target='category';label='쿠팡 상품 분류';help='이 상품이 쿠팡의 어떤 분류에 해당하는지 선택하세요.'
    elif '이미지 URL' in message and any(str(o.get('name','')) and message.startswith(str(o['name'])+':') for o in product['options']):target='options';label='상품 종류별 사진';help='이 종류에 사용한 상품 사진의 인터넷 주소를 확인하세요.'
    elif '고시정보' in message:target='notices';label='상품 안내정보';help='공급사 자료를 보고 품명·제조사 등 쿠팡이 요구하는 상품 안내정보를 입력하세요.'
    elif '인증' in message:target='certifications';label='인증 대상 여부와 인증정보';help='공급사에서 인증 대상 여부를 확인하세요. 대상이면 인증번호를 입력하고, 대상이 아닐 때만 인증 대상 아님을 선택하세요.'
    elif '구비서류' in message:target='documents';label='제출할 서류';help='쿠팡에서 요구하는 서류를 공급사에 확인한 뒤 입력하세요.'
    elif '속성' in message or any(str(a.get('attributeTypeName','')) and str(a['attributeTypeName'])+':' in message for a in (meta or {}).get('attributes',[])):
        target='attributes';label='상품의 필수 특징';help='수량·색상·크기 등 아래에 표시된 항목을 상품에 맞게 입력하세요. 여러 종류가 있으면 종류마다 입력합니다.'
        name=next((str(a['attributeTypeName']) for a in (meta or {}).get('attributes',[]) if str(a.get('attributeTypeName','')) and str(a['attributeTypeName']) in message),'')
    elif any(word in message for word in ('옵션','재고')):target='options';label='상품 종류와 재고';help='판매할 종류의 이름과 재고를 확인하세요. 품절·단종인 종류는 등록에서 제외됩니다.'
    elif '대표이미지' in message or '이미지 URL' in message:label='상품 사진';help='공급사에서 받은 대표 사진의 인터넷 주소를 입력하세요.'
    elif '상세설명' in message:label='상품 상세설명';help='공급사에서 제공한 상세설명을 입력하세요.'
    elif '원가' in message:label='공급 가격';help='공급사에서 확인한 상품 원가를 입력하세요.'
    elif '품절 또는 단종' in message:label='공급사 판매 상태';help='공급사에서 지금 판매 가능한 상품인지 먼저 확인하세요.'
    text=message.replace('상품 고시정보를 입력하세요.','상품 안내정보(품명·제조사 등)가 비어 있습니다.').replace('인증정보를 확인·입력하세요. 인증 대상이 아니면 NOT_REQUIRED를 명시하세요.','인증 대상인지 확인한 내용이 없습니다.').replace('카테고리에 맞는 고시정보 종류를 선택하세요.','이 상품 분류에 맞는 안내정보 종류를 선택해야 합니다.').replace('고시정보 누락:','비어 있는 상품 안내정보:').replace('카테고리 정보 조회를 먼저 완료하세요.','쿠팡에서 필수 입력 항목을 먼저 불러와야 합니다.')
    match=re.fullmatch(r'(.+): 필수 속성 (.+) 누락',message)
    if match:text=f"{match[1]}: '{match[2]}' 칸이 비어 있습니다."
    if message=='쿠팡 노출 카테고리코드를 입력하세요.':text='쿠팡 상품 분류가 아직 정해지지 않았습니다.'
    if message=='판매 가능한 옵션이 없습니다.':text='지금 등록할 수 있는 상품 종류가 없습니다. 재고와 판매 상태를 확인해 주세요.'
    if message.startswith('필수 인증 누락:'):text='필요한 인증정보가 비어 있습니다: '+message.split(':',1)[1].strip()
    return dict(message=text,detail=message,target=target,label=label,help=help,name=name)

def metadata(value):
    if not isinstance(value,dict):raise ValueError('쿠팡 카테고리 응답을 확인하지 못했습니다.')
    result=copy.deepcopy(value)
    for key in ('attributes','noticeCategories','certifications','requiredDocumentNames'):
        if result.get(key) is None:result[key]=[]
        if not isinstance(result[key],list) or any(not isinstance(x,dict) for x in result[key]):raise ValueError('쿠팡 카테고리 항목 형식이 올바르지 않습니다.')
    for item in result['noticeCategories']:
        if item.get('noticeCategoryDetailNames') is None:item['noticeCategoryDetailNames']=[]
    return result

class Registration:
    def __init__(self,app):
        self.app=app;self.store=app.store;self.credentials=app.credentials;self.lock=threading.RLock();self.tickets={}
    def ids(self,p,limit=1000):
        ids=p.get('ids',[])
        if not isinstance(ids,list) or len(ids)>limit or any(not isinstance(x,str) or not x for x in ids) or len(set(ids))!=len(ids):raise ValueError(f'서로 다른 상품을 최대 {limit}개까지 선택하세요.')
        return ids
    def idle(self):
        if self.app.stock.closed.is_set() or self.app.stock.active or self.app.batches.active:raise ValueError('등록·수집·주문 작업이 끝난 뒤 다시 시도하세요.')
    def shared(self):
        s=self.store.settings();issues=[label+'를 설정하세요.' for key,label in SETTING_FIELDS if not str(s.get(key,'')).strip()]
        if not self.credentials.ready():issues.insert(0,'쿠팡 Access Key와 Secret Key를 저장하세요.')
        return issues
    def state(self,p):
        rows=[];settings=self.store.settings();shared=self.shared()
        for id in self.ids(p):
            product=self.store.get(id);issues=[]
            if product['remote_id'] or product['state'] in LOCKED:issues.append('이미 전송했거나 등록 결과 확인이 필요한 상품입니다.')
            meta=self.store.meta(product['category'])
            meta=metadata(meta) if meta is not None else None
            issues+=validate(product,settings,meta,True)
            # Settings are shown once above the product table.
            issues=[x for x in dict.fromkeys(issues) if x not in [label+'를 설정하세요.' for _,label in SETTING_FIELDS]]
            rows.append(dict(product=product,issues=issues,requirements=[requirement(x,product,meta) for x in issues],ready=not issues and not shared))
        return dict(rows=rows,settings_issues=shared,ready=sum(r['ready'] for r in rows),total=len(rows),connection=self.app.shipping.connection_state(),info_policy=policy(settings.get('product_info_policy')),return_fee=settings.get('return_fee',4000))
    def editor(self,p):
        id=p.get('id')
        if not isinstance(id,str) or not id:raise ValueError('입력할 상품을 선택하세요.')
        result=self.state({'ids':[id]});category=result['rows'][0]['product']['category'];value=self.store.meta(category)
        return dict(result,meta=metadata(value) if value is not None else None)
    def refresh_meta(self,ids):
        client=Coupang(self.credentials)
        for category in sorted({self.store.get(id)['category'] for id in ids}):
            if re.fullmatch(r'[1-9]\d*',category):
                self.store.meta(category,metadata(client.call('GET',BASE+'/meta/category-related-metas/display-category-codes/'+category).get('data')))
    def prepare_information(self,ids,rules):
        """Repair old imports from account-scoped cached supplier facts, then fill locally."""
        catalog=self.app.catalog;cached={row['code']:row.get('mapped') for row in catalog.rows() if not row.get('error') and row.get('mapped') and not row['mapped'].get('issues')}
        updates=[];details=[];skipped=0
        for id in ids:
            old=self.store.get(id)
            if old['remote_id'] or old['state'] in LOCKED or old.get('demo') or old.get('registration_excluded'):skipped+=1;continue
            item=copy.deepcopy(old);mapped=cached.get(old['sku'].upper()) if old['source']=='오너클랜' else None
            if mapped:
                facts=source_info(mapped.get('source_info'));facts.update(source_info(mapped.get('metadata')))
                item['source_info']={**facts,**(item.get('source_info') or {})}
                original=(mapped.get('source_info') or {}).get('options') or []
                # Match actual supplier option labels; never match ambiguous rows by position.
                by_name={}
                for option in original:
                    attrs=option.get('optionAttributes') or []
                    name=' / '.join(str(a.get('name',''))+': '+str(a.get('value','')) for a in attrs) or '단일상품'
                    by_name.setdefault(name,[]).append(attrs)
                for option in item['options']:
                    matches=by_name.get(option.get('name'),[])
                    if not option.get('source_attributes') and len(matches)==1:option['source_attributes']=copy.deepcopy(matches[0])
            meta=self.store.meta(item['category']);meta=metadata(meta) if meta is not None else None
            filled,summary=fill_product(item,meta,rules);normalized=normalize(filled)
            if any(old.get(key)!=value for key,value in normalized.items()):updates.append((id,normalized))
            details.append(dict(id=id,sku=old['sku'],**summary))
        with self.store.connect() as db:
            for id,item in updates:db.execute("UPDATE products SET data=?,state='대기',updated=? WHERE id=?",(json.dumps(item,ensure_ascii=False),now(),id))
        return dict(updated=len(updates),skipped=skipped,fields=sum(len(d['changes']) for d in details),details=details)
    def autofill(self,p):
        ids=self.ids(p)
        if not ids:raise ValueError('자동으로 채울 상품을 선택하세요.')
        rules=policy(p.get('policy',self.store.settings().get('product_info_policy')))
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle()
            if self.credentials.ready():self.refresh_meta(ids)
            summary=self.prepare_information(ids,rules)
            settings=self.store.settings();settings['product_info_policy']=rules;self.store.set_settings(settings)
            return dict(self.state({'ids':ids}),autofill=summary)
    def prepare(self,p):
        """Prepare selected products before displaying readiness; market calls are metadata GETs only."""
        ids=self.ids(p);warnings=[]
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle()
            if self.credentials.ready():
                client=Coupang(self.credentials)
                categories={self.store.get(id)['category'] for id in ids if not self.store.get(id)['remote_id'] and self.store.get(id)['state'] not in LOCKED and not self.store.get(id).get('registration_excluded')}
                for category in sorted(categories):
                    if not re.fullmatch(r'[1-9]\d*',category) or self.store.meta(category) is not None:continue
                    try:self.store.meta(category,metadata(client.call('GET',BASE+'/meta/category-related-metas/display-category-codes/'+category).get('data')))
                    except Exception as ex:warnings.append('분류 '+category+': '+str(ex))
            summary=self.prepare_information(ids,policy(self.store.settings().get('product_info_policy')))
            return dict(self.state({'ids':ids}),autofill=summary,preparation_warnings=warnings)
    def keywords(self,p):
        ids=self.ids(p)
        if not ids:raise ValueError('검색어를 적용할 상품을 선택하세요.')
        tags=search_tags(p.get('tags'));mode=p.get('mode','append')
        if mode not in ('append','replace'):raise ValueError('검색어 적용 방식을 선택하세요.')
        updates=[];skipped=0
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle()
            for id in ids:
                old=self.store.get(id)
                if old['remote_id'] or old['state'] in LOCKED or old.get('demo'):skipped+=1;continue
                combined=search_tags((old.get('search_tags',[]) if mode=='append' else [])+tags)
                item={**old,'search_tags':combined};updates.append((id,normalize(item)))
            with self.store.connect() as db:
                for id,item in updates:db.execute("UPDATE products SET data=?,updated=? WHERE id=?",(json.dumps(item,ensure_ascii=False),now(),id))
            return dict(self.state({'ids':ids}),updated=len(updates),skipped=skipped)
    def save_policy(self,p):
        rules=policy(p.get('policy'))
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle()
            settings=self.store.settings();settings['product_info_policy']=rules;self.store.set_settings(settings)
            return dict(info_policy=rules)
    def exclusion(self,p):
        ids=self.ids(p);excluded=p.get('excluded')
        if not ids or type(excluded) is not bool:raise ValueError('분류할 상품과 등록 제외 여부를 선택하세요.')
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle()
            if self.app.automation.active:raise ValueError('예약·자동 관리 작업이 끝난 뒤 분류하세요.')
            products=[self.store.get(id) for id in ids]
            if any(x['state'] in LOCKED for x in products):raise ValueError('전송 중이거나 등록 결과 확인이 필요한 상품은 먼저 결과를 확인하세요.')
            changed=0;removed=0
            with self.store.connect() as db:
                for id in ids:
                    item=json.loads(db.execute('SELECT data FROM products WHERE id=?',(id,)).fetchone()[0])
                    if bool(item.get('registration_excluded'))==excluded:continue
                    item['registration_excluded']=excluded;changed+=1
                    db.execute('UPDATE products SET data=?,updated=? WHERE id=?',(json.dumps(item,ensure_ascii=False),now(),id))
                # Product IDs are global in this local workspace; cancel their inactive queues atomically.
                for row in db.execute("SELECT account,data FROM automation_data WHERE key='queue'").fetchall():
                    queue=json.loads(row['data'])
                    remaining=[x for x in queue if not (x.get('id') in ids and (excluded or x.get('state')=='등록 제외'))]
                    removed+=len(queue)-len(remaining)
                    if len(remaining)!=len(queue):db.execute("UPDATE automation_data SET data=? WHERE account=? AND key='queue'",(json.dumps(remaining,ensure_ascii=False),row['account']))
            return dict(updated=changed,excluded=excluded,removed_reservations=removed)
    def fingerprint(self,ids,requested):
        values=dict(products=[self.store.get(id) for id in ids],settings=self.store.settings(),keys=dict(self.credentials.values),requested=requested,metas={self.store.get(id)['category']:self.store.meta(self.store.get(id)['category']) for id in ids})
        return hashlib.sha256(json.dumps(values,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    def review(self,p):
        ids=self.ids(p)
        if not ids:raise ValueError('등록할 상품을 선택하세요.')
        requested=p.get('requested',True)
        if type(requested) is not bool:raise ValueError('판매 승인 요청 여부를 선택하세요.')
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle()
            if not self.shared():
                if self.app.shipping.connection_state()['status']!='verified':self.app.shipping.check()
                self.refresh_meta(ids)
            automatic=self.prepare_information(ids,policy(self.store.settings().get('product_info_policy')))
            report=self.state({'ids':ids});report.update(ticket=None,requested=requested)
            report['autofill']=automatic
            if report['ready']!=len(ids):return report
            bodies=[payload(self.store.get(id),self.store.settings(),requested) for id in ids]
            token=secrets.token_urlsafe(28)
            self.tickets={k:v for k,v in self.tickets.items() if v['expires']>time.monotonic()}
            if len(self.tickets)>=20:self.tickets.clear()
            self.tickets[token]=dict(ids=ids,requested=requested,expires=time.monotonic()+600,fingerprint=self.fingerprint(ids,requested))
            report.update(ticket=token,payloads=bodies,expires_in=600)
            return report
    def commit(self,p):
        token=p.get('ticket')
        if not isinstance(token,str):raise ValueError('등록 내용을 먼저 확인하세요.')
        with self.app.stock.lock,self.app.shipping.lock,self.store.lock,self.credentials.lock,self.lock:
            self.idle();ticket=self.tickets.get(token)
            if not ticket or ticket['expires']<=time.monotonic():raise ValueError('등록 확인이 만료됐습니다. 내용을 다시 확인하세요.')
            if ticket['fingerprint']!=self.fingerprint(ticket['ids'],ticket['requested']):
                self.tickets.pop(token,None);raise ValueError('상품·가격·카테고리 또는 쿠팡 설정이 변경됐습니다. 등록 내용을 다시 확인하세요.')
            self.refresh_meta(ticket['ids'])
            report=self.state({'ids':ticket['ids']})
            if report['ready']!=len(ticket['ids']):
                self.tickets.pop(token,None);raise ValueError('쿠팡 필수 항목이 변경됐습니다. 등록 준비 화면에서 다시 확인하세요.')
            self.tickets.pop(token,None)
            result=self.app.batches.start(ticket['ids'],live=True,requested=ticket['requested'])
            # Only a successfully started immediate submission supersedes its reservation.
            automation=self.app.automation
            queue=automation.read('queue',[])
            remaining=[r for r in queue if r['id'] not in ticket['ids']]
            if len(remaining)!=len(queue):automation.write('queue',remaining)
            return result
    def recommend(self,p):
        with self.app.stock.lock,self.store.lock,self.credentials.lock:
            self.idle();product=self.store.get(p.get('id'))
            result=Coupang(self.credentials).call('POST',PREDICT,dict(productName=product['name'],brand=product['brand'],sellerSkuCode=product['sku']))
            value=result.get('data')
            if not isinstance(value,dict) or value.get('autoCategorizationPredictionResultType')!='SUCCESS' or not re.fullmatch(r'[1-9]\d*',str(value.get('predictedCategoryId',''))):raise ValueError('추천 카테고리가 없습니다. 상품명을 구체화하거나 쿠팡 카테고리코드를 직접 입력하세요.')
            return dict(category=str(value['predictedCategoryId']),name=str(value.get('predictedCategoryName','')),message='추천 결과를 상품의 실제 분류와 비교한 뒤 적용하세요.')
    def common(self,p):
        ids=self.ids(p);changes=p.get('changes');category=str(p.get('category',''))
        if not ids or not isinstance(changes,dict) or not changes or not set(changes)<=set(('attributes','notices','certifications','documents')):raise ValueError('적용할 공통 정보를 선택하세요.')
        with self.app.stock.lock,self.store.lock,self.credentials.lock:
            self.idle();prepared=[]
            for id in ids:
                old=self.store.get(id)
                if old['remote_id'] or old['state'] in LOCKED:raise ValueError('전송한 상품의 공통 정보는 수정할 수 없습니다.')
                if not category or old['category']!=category:raise ValueError('같은 쿠팡 카테고리의 상품만 선택하세요.')
                item=copy.deepcopy(old);item.update(copy.deepcopy(changes))
                if 'notices' in changes:item['notice_auto_category']='manual'
                if 'attributes' in changes:
                    if not isinstance(changes['attributes'],list):raise ValueError('공통 속성을 확인하세요.')
                    shared={a.get('attributeTypeName'):a for a in changes['attributes'] if isinstance(a,dict)}
                    for option in item['options']:
                        own={a.get('attributeTypeName'):a for a in option.get('attributes',old['attributes'])}
                        option['attributes']=list((own|shared).values())
                prepared.append((id,normalize(item)))
            with self.store.connect() as db:
                for id,item in prepared:db.execute("UPDATE products SET data=?,state='대기',updated=? WHERE id=?",(json.dumps(item,ensure_ascii=False),now(),id))
            return dict(updated=len(prepared))
