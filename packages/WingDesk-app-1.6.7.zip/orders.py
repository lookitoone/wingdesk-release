"""Persistent multi-store order workspace and reviewed, non-replayed writes."""
from __future__ import annotations
import base64,csv,hashlib,io,json,os,re,secrets,threading,time,uuid
from datetime import datetime,timedelta
from core import now,KST,dpapi,read_table,integer,safe_cell,RemoteRejected,Uncertain
from markets import StoreRegistry,MARKETS
from order_adapters import Adapter,ident,row,item,days

IMPORT_FIELDS={'remote_id':'배송번호 / 상품주문번호','order_id':'주문번호','name':'상품명','option':'옵션','quantity':'수량','total':'상품 결제금액','status':'상태','ordered_at':'주문일','receiver':'수취인','phone':'연락처','zipcode':'우편번호','address':'배송주소','orderer':'주문자','memo_shipping':'배송메시지','courier':'택배사','invoice':'송장번호'}
IMPORT_ALIASES={'remote_id':['배송번호/상품주문번호','배송번호','상품주문번호','주문상품번호','배송묶음번호'],'order_id':['주문번호','주문id'],'name':['상품명','제품명'],'option':['옵션','옵션명'],'quantity':['수량','주문수량'],'total':['상품결제금액','결제금액','판매금액'],'status':['상태','주문상태'],'ordered_at':['주문일','주문일시'],'receiver':['수취인','수령인','수취인명'],'phone':['연락처','수취인연락처'],'zipcode':['우편번호'],'address':['배송주소','주소'],'orderer':['주문자','구매자'],'memo_shipping':['배송메시지','배송메모'],'courier':['택배사'],'invoice':['송장번호','운송장번호']}
STATES=['신규','상품 준비','배송 중','배송 완료','구매 확정','결제 대기','취소','반품','교환','확인 필요']

def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def fingerprint(r):return digest({k:v for k,v in r.items() if k not in ('id','store_id','market','store_name','market_name','memo','updated_at','origin','scope')})

class Orders:
    def __init__(self,store,credentials,batches,stock):
        self.store,self.batches,self.stock=store,batches,stock;self.registry=StoreRegistry(store,credentials);self.lock=threading.RLock();self.cancel=threading.Event();self.active=None;self.tickets={};self.imports={};self.last_auto=0
        with store.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,store_id TEXT,scope TEXT,remote_id TEXT,origin TEXT,data BLOB,UNIQUE(store_id,scope,remote_id,origin));
            CREATE TABLE IF NOT EXISTS order_claims(id TEXT PRIMARY KEY,store_id TEXT,scope TEXT,data BLOB);
            CREATE TABLE IF NOT EXISTS order_ops(id TEXT PRIMARY KEY,order_key TEXT,state TEXT,data BLOB);
            CREATE TABLE IF NOT EXISTS order_settings(id INTEGER PRIMARY KEY,data TEXT);
            CREATE TABLE IF NOT EXISTS order_runs(store_id TEXT PRIMARY KEY,data TEXT);''')
            db.execute("UPDATE order_ops SET state='확인 필요' WHERE state='전송 중'")
        self.job={'state':'대기','message':'','results':[]}
    def pack(self,v):
        raw=json.dumps(v,ensure_ascii=False).encode()
        return b'WD1'+dpapi(raw) if os.name=='nt' else b'JSON'+raw
    def unpack(self,v):
        raw=bytes(v)
        if raw.startswith(b'WD1'):raw=dpapi(raw[3:],True)
        elif raw.startswith(b'JSON'):raw=raw[4:]
        else:raise ValueError('주문 저장 형식을 확인하지 못했습니다.')
        try:return json.loads(raw)
        except (ValueError,UnicodeError):raise ValueError('저장한 주문을 읽지 못했습니다. 같은 Windows 사용자로 실행하세요.') from None
    def settings(self):
        with self.store.connect() as db:r=db.execute('SELECT data FROM order_settings WHERE id=1').fetchone()
        return {'auto':False,'interval':10,**(json.loads(r[0]) if r else {})}
    def save_settings(self,p):
        interval=integer(p.get('interval',10),'동기화 주기',10,120)
        if interval not in (10,15,30,60,120):raise ValueError('주기는 10·15·30·60·120분 중 선택하세요.')
        settings=dict(auto=bool(p.get('auto')),interval=interval)
        with self.store.connect() as db:db.execute('INSERT OR REPLACE INTO order_settings VALUES(1,?)',(json.dumps(settings),))
        self.last_auto=time.monotonic();return settings
    def scopes(self):return {s['id']:self.registry.fingerprint(s['id']) for s in self.registry.all()}
    def all(self):
        scopes=self.scopes();stores={x['id']:x for x in self.registry.all()};rows=[]
        with self.store.connect() as db:raw=db.execute('SELECT * FROM orders').fetchall()
        for x in raw:
            if x['store_id'] not in stores or (x['origin']=='api' and x['scope']!=scopes[x['store_id']]):continue
            r=self.unpack(x['data']);s=stores[x['store_id']]
            r.update(id=x['id'],store_id=x['store_id'],scope=x['scope'],origin=x['origin'],store_name=s['name'],market=s['market'],market_name=MARKETS[s['market']]['name']);rows.append(r)
        return sorted(rows,key=lambda r:(str(r.get('ordered_at','')),r['id']),reverse=True)
    def get(self,id):
        r=next((r for r in self.all() if r['id']==id),None)
        if not r:raise ValueError('현재 상점의 주문을 찾지 못했습니다. 상점 인증 설정 변경 여부를 확인하세요.')
        return r
    def put(self,store_id,r,origin='api',scope=None,db=None):
        scope=scope if scope is not None else (self.registry.fingerprint(store_id) if origin=='api' else '')
        key=digest([store_id,scope,r['remote_id'],origin]);r=dict(r)
        own=db is None
        if own:db=self.store.connect()
        try:
            old=db.execute('SELECT data FROM orders WHERE id=?',(key,)).fetchone()
            if old:r['memo']=self.unpack(old[0]).get('memo','')
            r['updated_at']=now();r.setdefault('memo','')
            for k in ('id','store_id','scope','origin','store_name','market','market_name'):r.pop(k,None)
            db.execute('INSERT OR REPLACE INTO orders VALUES(?,?,?,?,?,?)',(key,store_id,scope,r['remote_id'],origin,self.pack(r)))
            if own:db.commit()
        finally:
            if own:db.close()
        return key
    def claims(self):
        scopes=self.scopes();stores={x['id']:x for x in self.registry.all()};claims={}
        with self.store.connect() as db:
            for x in db.execute('SELECT * FROM order_claims'):
                if scopes.get(x['store_id'])!=x['scope']:continue
                c=self.unpack(x['data']);s=stores[x['store_id']];c.update(store_id=s['id'],store_name=s['name'],market=s['market']);claims[(s['id'],c['type'],c['id'])]=c
        for r in self.all():
            for c in r.get('claims',[]):claims.setdefault((r['store_id'],c['type'],c['id']),dict(c,order_id=r['order_id'],store_id=r['store_id'],store_name=r['store_name'],market=r['market']))
        return list(claims.values())
    def query(self,p):
        rows=self.all();store=p.get('store_id');market=p.get('market');status=p.get('status');q=str(p.get('search','')).strip().lower();counts={s:0 for s in STATES}
        def common(r):return (not store or r['store_id']==store) and (not market or r['market']==market) and (not q or q in json.dumps([r['order_id'],r['remote_id'],r['items'],r.get('receiver',''),r.get('orderer',''),r.get('invoice',''),r.get('memo','')],ensure_ascii=False).lower()) and (not p.get('from') or str(r.get('ordered_at',''))[:10]>=p['from']) and (not p.get('to') or str(r.get('ordered_at',''))[:10]<=p['to'])
        rows=[r for r in rows if common(r)]
        for r in rows:counts[r['status']]=counts.get(r['status'],0)+1
        if status:rows=[r for r in rows if r['status']==status]
        total=len(rows);page=integer(p.get('page',1),'페이지',1,100000);limit=integer(p.get('limit',30),'페이지 크기',1,100)
        # Shipping PII stays inside the detail dialog and exports, not the list response.
        brief=[{k:v for k,v in r.items() if k not in ('address','phone','zipcode','memo_shipping','scope')} for r in rows[(page-1)*limit:page*limit]]
        with self.store.connect() as db:runs={r['store_id']:json.loads(r['data']) for r in db.execute('SELECT * FROM order_runs') if r['store_id'] in self.scopes()}
        ops=[x for x in self.operations() if x['order_key'] in {r['id'] for r in self.all() if common(r)}]
        return dict(rows=brief,total=total,counts=counts,settings=self.settings(),active=bool(self.active),job=self.job,stores=self.registry.state()['stores'],runs={k:{a:b for a,b in v.items() if a!='scope'} for k,v in runs.items() if v.get('scope')==self.scopes()[k]},operations=ops,claims=[c for c in self.claims() if (not store or c['store_id']==store) and (not market or c['market']==market) and (not q or q in json.dumps(c,ensure_ascii=False).lower()) and (not p.get('from') or str(c.get('created_at',''))[:10]>=p['from']) and (not p.get('to') or str(c.get('created_at',''))[:10]<=p['to'])])
    def operations(self):
        ids={r['id'] for r in self.all()}
        with self.store.connect() as db:xs=db.execute('SELECT * FROM order_ops ORDER BY rowid DESC LIMIT 200').fetchall()
        return [dict(id=x['id'],order_key=x['order_key'],state=x['state'],**{k:v for k,v in self.unpack(x['data']).items() if k in ('action','at','message','store_name','order_id')}) for x in xs if x['order_key'] in ids]
    def reserve(self):
        if self.stock.closed.is_set():raise ValueError('프로그램이 종료 중입니다.')
        if self.stock.active or self.batches.active or self.active:raise ValueError('진행 중인 작업이 끝난 뒤 주문 작업을 실행하세요.')
        self.stock.active=True
    def run(self,fn):
        with self.stock.lock,self.lock:
            self.reserve();self.cancel.clear();self.active=uuid.uuid4().hex;self.job=dict(state='진행 중',message='주문 작업을 시작합니다.',results=[])
            def worker():
                try:fn();self.job['state']='중단됨' if self.cancel.is_set() else ('일부 실패' if any(not x.get('success',True) for x in self.job['results']) else '완료')
                except Exception as e:self.job.update(state='확인 필요',message=self.safe_error(e))
                finally:
                    with self.stock.lock,self.lock:self.active=None;self.stock.active=False
            threading.Thread(target=worker,daemon=True).start()
        return {'ok':True}
    def safe_error(self,e):return str(e) if isinstance(e,(ValueError,RemoteRejected,Uncertain)) else '주문 작업 중 오류가 발생했습니다. 기존 내역과 처리 기록을 확인하세요.'
    def sync(self,p):
        today=datetime.now(KST).date();start=p.get('from') or str(today-timedelta(days=6));end=p.get('to') or str(today);list(days(start,end))
        selected=p.get('store_ids') if 'store_ids' in p else [s['id'] for s in self.registry.state()['stores'] if s['enabled'] and s['api_available'] and s['configured']]
        if not isinstance(selected,list) or not selected or len(selected)>50 or len(set(selected))!=len(selected):raise ValueError('주문 수집할 상점을 선택하세요.')
        # Validate all scopes before any network read; disabled stores require explicit enablement.
        for id in selected:
            s=self.registry.get(id)
            if not s.get('enabled'):raise ValueError('주문 수집할 상점을 먼저 활성화하세요.')
            self.registry.client(id)
        return self.run(lambda:self.collect(selected,start,end))
    def collect(self,ids,start,end):
        for id in ids:
            if self.cancel.is_set():break
            name=self.registry.get(id)['name'];scope=self.registry.fingerprint(id);success=False
            try:
                a=Adapter(self.registry,id,self.cancel,lambda s:self.job.update(message=s));rows,claims=a.fetch(start,end)
                if scope!=self.registry.fingerprint(id):raise ValueError('수집 중 상점 인증 정보가 변경되었습니다.')
                if self.cancel.is_set():break
                with self.store.connect() as db:
                    for r in rows:self.put(id,r,scope=scope,db=db)
                    for c in claims:
                        key=digest([id,scope,c['type'],c['id']]);db.execute('INSERT OR REPLACE INTO order_claims VALUES(?,?,?,?)',(key,id,scope,self.pack(c)))
                success=True;message=f'{len(rows)}건 수집 · 클레임 {len(claims)}건';self.registry.tested(id,True)
            except Exception as e:message=self.safe_error(e);self.registry.tested(id,False)
            run=dict(at=now(),success=success,message=message,from_date=start,to_date=end,scope=scope)
            with self.store.connect() as db:db.execute('INSERT OR REPLACE INTO order_runs VALUES(?,?)',(id,json.dumps(run,ensure_ascii=False)))
            self.job['results'].append(dict(store_name=name,success=success,message=message))
        self.job['message']='상점별 수집 결과를 확인하세요. 조회 기간 밖의 주문은 마지막 수집 상태가 표시됩니다.'
        if any(not x['success'] for x in self.job['results']):self.job['state']='일부 실패'
    def test(self,id):
        def work():
            today=str(datetime.now(KST).date());self.collect([id],today,today)
        self.registry.client(id);return self.run(work)
    def memo(self,p):
        value=str(p.get('memo',''))
        if len(value)>2000:raise ValueError('메모는 2,000자 이하로 입력하세요.')
        with self.lock,self.store.lock:
            r=self.get(p.get('id'));r['memo']=value
            with self.store.connect() as db:db.execute('UPDATE orders SET data=? WHERE id=?',(self.pack(r),r['id']))
        return {'ok':True}
    def refresh_one(self,id):
        def work():
            r=self.get(id)
            if r['origin']!='api':raise ValueError('파일 주문은 원본 파일을 다시 가져오세요.')
            a=Adapter(self.registry,r['store_id'],self.cancel);latest=a.detail(r);self.put(r['store_id'],latest)
            self.job['message']='주문 최신 상태를 가져왔습니다.'
        return self.run(work)
    def unresolved(self,id):
        with self.store.connect() as db:return db.execute("SELECT 1 FROM order_ops WHERE order_key=? AND state IN ('전송 중','확인 필요')",(id,)).fetchone() is not None
    def prepare(self,p):
        ids=p.get('ids');action=p.get('action');values=p.get('values') or {}
        if action not in ('confirm','invoice') or not isinstance(ids,list) or not 1<=len(ids)<=20 or len(set(ids))!=len(ids):raise ValueError('서로 다른 주문 1~20건과 처리 방식을 선택하세요.')
        if action=='invoice':
            if len(ids)!=1:raise ValueError('송장은 배송 묶음별로 한 건씩 등록하세요.')
            courier=str(values.get('courier','')).strip();invoice=str(values.get('invoice','')).strip()
            if not re.fullmatch(r'[A-Z0-9_]{2,40}',courier) or not re.fullmatch(r'[A-Za-z0-9-]{5,40}',invoice):raise ValueError('마켓 택배사 코드와 송장번호(5~40자)를 확인하세요.')
            values=dict(courier=courier,invoice=invoice)
        else:values={}
        with self.stock.lock,self.lock:
            self.reserve()
        try:
            preview=[];plans=[]
            for id in ids:
                r=self.get(id)
                if r['origin']!='api':raise ValueError('파일로 가져온 주문은 API 처리할 수 없습니다.')
                if self.unresolved(id):raise ValueError('결과 확인이 필요한 이전 요청이 있습니다. 처리 기록에서 결과 조회를 실행하세요.')
                a=Adapter(self.registry,r['store_id']);n=a.detail(r);a.validate_action(n,action)
                # A claim known from collection remains blocking even if detail omits its history.
                if r.get('claims'):raise ValueError('클레임이 있는 주문은 판매자센터에서 확인하세요.')
                self.put(r['store_id'],n)
                plans.append(dict(id=id,scope=r['scope'],fingerprint=fingerprint(n)))
                preview.append(dict(n,id=id,store_name=r['store_name'],market=r['market']))
            ticket=secrets.token_urlsafe(24)
            with self.lock:
                self.tickets={k:v for k,v in self.tickets.items() if v['expiry']>time.monotonic()};self.tickets[ticket]=dict(plans=plans,action=action,values=values,expiry=time.monotonic()+180)
            return dict(ticket=ticket,action=action,values=values,orders=preview)
        finally:
            with self.stock.lock:self.stock.active=False
    def op(self,key,state,data,id=None):
        id=id or uuid.uuid4().hex
        with self.store.connect() as db:db.execute('INSERT OR REPLACE INTO order_ops VALUES(?,?,?,?)',(id,key,state,self.pack(data)))
        return id
    def achieved(self,n,action,values):
        if action=='confirm':return n['status']=='상품 준비' and not n.get('blocked')
        return str(n.get('invoice'))==values['invoice'] and n['status'] in ('배송 중','배송 완료','구매 확정')
    def execute(self,p):
        with self.lock:
            plan=self.tickets.pop(p.get('ticket'),None)
        if not plan or plan['expiry']<time.monotonic():raise ValueError('처리 내용을 다시 확인하세요. 확인 화면은 3분 동안 유효합니다.')
        def work():
            for x in plan['plans']:
                if self.cancel.is_set():break
                r=self.get(x['id']);data=dict(action=plan['action'],values=plan['values'],at=now(),store_name=r['store_name'],order_id=r['order_id'],store_id=r['store_id'],scope=x['scope']);opid=None
                try:
                    if self.registry.fingerprint(r['store_id'])!=x['scope'] or self.unresolved(r['id']):raise ValueError('상점 인증 정보 또는 이전 처리 상태가 변경되었습니다.')
                    a=Adapter(self.registry,r['store_id'],self.cancel);n=a.detail(r)
                    if fingerprint(n)!=x['fingerprint']:self.put(r['store_id'],n);raise ValueError('주문 상태·수취인·주소·수량 등이 변경되었습니다. 최신 내역을 다시 확인하세요.')
                    a.validate_action(n,plan['action'])
                    opid=self.op(r['id'],'전송 중',data)
                    latest=a.write(n,plan['action'],plan['values']);self.put(r['store_id'],latest)
                    if not self.achieved(latest,plan['action'],plan['values']):raise Uncertain('요청 후 최종 상태를 확인하지 못했습니다. 결과 조회를 실행하세요.')
                    state='완료';data['message']='마켓 재조회로 처리 결과를 확인했습니다.'
                except Exception as e:
                    state='확인 필요' if opid and not isinstance(e,RemoteRejected) else '실패';data['message']=self.safe_error(e)
                self.op(r['id'],state,data,opid);self.job['results'].append(dict(store_name=r['store_name'],order_id=r['order_id'],success=state=='완료',message=data['message']))
            self.job['message']='처리 결과를 확인하세요. 결과가 불명확한 요청은 자동 재전송하지 않습니다.'
        return self.run(work)
    def reconcile(self,id):
        def work():
            with self.store.connect() as db:x=db.execute('SELECT * FROM order_ops WHERE id=?',(id,)).fetchone()
            if not x or x['state']!='확인 필요':raise ValueError('결과 확인이 필요한 처리 기록을 선택하세요.')
            data=self.unpack(x['data']);r=self.get(x['order_key'])
            if data['scope']!=self.registry.fingerprint(r['store_id']):raise ValueError('요청 당시와 상점 인증 정보가 다릅니다.')
            a=Adapter(self.registry,r['store_id'],self.cancel);n=a.detail(r);self.put(r['store_id'],n)
            if self.achieved(n,data['action'],data['values']):state='완료';data['message']='결과 재조회로 완료를 확인했습니다.'
            else:state='확인 필요';data['message']='마켓에서 완료 여부를 확인하지 못했습니다. 판매자센터에서 요청 결과를 확인하세요. 자동 재전송하지 않습니다.'
            self.op(r['id'],state,data,id);self.job['message']=data['message']
        return self.run(work)
    def import_preview(self,p):
        self.registry.get(p.get('store_id'));table=read_table(base64.b64decode(p['data'],validate=True),p['filename']);mapping={}
        for k,aliases in IMPORT_ALIASES.items():
            for i,h in enumerate(table['headers']):
                if re.sub(r'\s+','',h).lower() in aliases or h==k:mapping[k]=i;break
        token=secrets.token_urlsafe(16);self.imports={token:dict(table=table,store_id=p['store_id'],expiry=time.monotonic()+900)}
        return dict(ticket=token,headers=table['headers'],mapping=mapping,fields=IMPORT_FIELDS,sample=table['rows'][:3],count=len(table['rows']))
    def import_commit(self,p):
        with self.stock.lock,self.lock:
            if self.stock.active:raise ValueError('진행 중인 작업이 끝난 뒤 가져오세요.')
            cached=self.imports.pop(p.get('ticket'),None)
            if not cached or cached['expiry']<time.monotonic():raise ValueError('주문 파일을 다시 선택하세요.')
            self.registry.get(cached['store_id']);mapping=p.get('mapping') or {};rows=[];seen=set();errors=[]
            if any(k not in mapping for k in ('remote_id','order_id','name','quantity','status','ordered_at')):raise ValueError('배송/상품주문번호·주문번호·상품명·수량·상태·주문일 열을 연결하세요.')
            for n,values in enumerate(cached['table']['rows'],2):
                try:
                    v={k:values[int(i)] for k,i in mapping.items() if k in IMPORT_FIELDS and i is not None and 0<=int(i)<len(values)}
                    
                    if any(isinstance(v.get(k),(int,float)) and abs(v[k])>=10**15 for k in ('remote_id','order_id')):raise ValueError('긴 주문번호는 엑셀의 텍스트 형식으로 저장하세요. 숫자 형식은 반올림될 수 있습니다.')
                    rid=ident(v.get('remote_id'));oid=ident(v.get('order_id'))
                    if rid in seen:raise ValueError('배송/상품주문번호 중복입니다. 한 행에 배송 묶음 전체 상품명을 적거나 상품주문번호를 사용하세요.')
                    seen.add(rid);s=str(v.get('status','')).strip()
                    if s not in STATES:raise ValueError('상태는 '+', '.join(STATES)+' 중 하나로 입력하세요.')
                    dt=str(v.get('ordered_at') or '')[:10];datetime.strptime(dt,'%Y-%m-%d')
                    quantity=integer(v.get('quantity'),'수량',1,999999);it=item(rid,str(v.get('name') or ''),str(v.get('option') or ''),quantity,v.get('total',0))
                    if not it['name']:raise ValueError('상품명을 입력하세요.')
                    r=row(rid,oid,'',[it]);r.update({k:str(v.get(k) or '') for k in ('ordered_at','receiver','phone','zipcode','address','orderer','memo_shipping','courier','invoice')});r['status']=s;r['raw_status']=s;rows.append(r)
                except (ValueError,TypeError,IndexError) as e:errors.append(dict(row=n,message=str(e)))
            if errors:return dict(added=0,errors=errors[:100],message='오류가 있어 전체 가져오기를 취소했습니다. 원본 파일을 수정한 뒤 다시 선택하세요.')
            with self.store.connect() as db:
                for r in rows:self.put(cached['store_id'],r,origin='file',db=db)
            return dict(added=len(rows),errors=[],message=f'{len(rows)}건을 가져왔습니다. 같은 상점·배송번호의 파일 주문은 갱신합니다.')
    def export(self,p,template=False):
        from openpyxl import Workbook
        book=Workbook();sheet=book.active;sheet.title='주문 양식' if template else '주문 내역'
        headers=list(IMPORT_FIELDS);sheet.append(([] if template else ['상점','마켓'])+list(IMPORT_FIELDS.values())+([] if template else ['메모','최근수집']))
        if not template:
            for r in self.all():
                if p.get('store_id') and p['store_id']!=r['store_id']:continue
                if p.get('market') and p['market']!=r['market']:continue
                if p.get('status') and p['status']!=r['status']:continue
                if p.get('from') and r.get('ordered_at','')[:10]<p['from']:continue
                if p.get('to') and r.get('ordered_at','')[:10]>p['to']:continue
                if p.get('search') and p['search'].lower() not in json.dumps(r,ensure_ascii=False).lower():continue
                v=dict(r,name=' / '.join(i['name'] for i in r['items']),option=' / '.join(i['option'] for i in r['items']),quantity=sum(i['quantity'] for i in r['items']),total=sum(i['total'] for i in r['items']))
                sheet.append([safe_cell(r['store_name']),r['market_name']]+[safe_cell(v.get(k,'')) for k in headers]+[safe_cell(r.get('memo','')),r.get('updated_at','')])
        sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
        from openpyxl.styles import Font,PatternFill
        for cell in sheet[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='254EDB')
        for col in sheet.columns:sheet.column_dimensions[col[0].column_letter].width=24
        out=io.BytesIO();book.save(out);return out.getvalue()
    def start_background(self):
        def loop():
            self.last_auto=time.monotonic()
            while not self.stock.closed.wait(5):
                s=self.settings()
                if s['auto'] and time.monotonic()-self.last_auto>=s['interval']*60 and not self.stock.active and not self.batches.active:
                    self.last_auto=time.monotonic();today=datetime.now(KST).date()
                    ids=[x['id'] for x in self.registry.state()['stores'] if x['api_available'] and x['configured'] and x['enabled']]
                    if ids:
                        try:self.sync({'store_ids':ids,'from':str(today-timedelta(days=30)),'to':str(today)})
                        except ValueError:pass
        threading.Thread(target=loop,daemon=True).start()
