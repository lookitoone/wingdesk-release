"""WingDesk local product store and Coupang adapter. Python 3.11+."""
from __future__ import annotations
import base64, csv, ctypes, hashlib, hmac, io, json, os, re, sqlite3, threading, time, uuid, zipfile
from datetime import datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from pathlib import Path
from urllib import request, error, parse

VERSION = '1.7.1'
BASE = '/v2/providers/seller_api/apis/api/v1/marketplace'
KST = timezone(timedelta(hours=9))
SOURCES = ['오너클랜', '도매매', '나비엠알오', '글로벌엠알오', '직접 입력', '기타']
HEADERS = {'sku':'상품코드','name':'상품명','cost':'원가','image':'대표이미지URL',
 'detail':'상세설명HTML','category':'쿠팡카테고리코드','stock':'재고','shipping':'배송비',
 'supplier_shipping':'공급사배송비','brand':'브랜드','source':'공급사','source_url':'원본URL',
 'availability':'공급상태','markup':'마진율','options':'옵션JSON','notices':'고시정보JSON',
 'certifications':'인증정보JSON','attributes':'속성JSON','documents':'구비서류JSON',
 'unit_count':'구성수량','unit_label':'판매단위','manufacturer':'제조사','origin':'원산지','model':'모델명','search_tags':'검색어'}
ALIASES = {'sku':['상품코드','상품번호','상품id','goodsno','goods_code','판매자상품코드'],
 'name':['상품명','제품명','상품제목'], 'cost':['원가','공급가','도매가','매입가','공급가격'],
 'image':['이미지','대표이미지','이미지url','대표이미지url','대표이미지주소'],
 'detail':['상세설명html','상세설명','상세페이지','상세정보'],
 'category':['쿠팡카테고리코드','노출카테고리코드','displaycategorycode'],
 'stock':['재고','수량','재고수량'], 'shipping':['배송비','판매배송비'],
 'supplier_shipping':['공급사배송비','매입배송비'], 'source':['공급사','도매업체'],
 'source_url':['원본url','상품url','상품주소'], 'availability':['공급상태','품절여부','상품상태'],
 'markup':['마진율','마진','마진율(%)'], 'brand':['브랜드'],
 'options':['옵션json'], 'notices':['고시정보json'], 'attributes':['속성json'],
 'certifications':['인증정보json'], 'documents':['구비서류json'],
 'unit_count':['구성수량','구성개수','판매단위수량','입수'], 'unit_label':['판매단위','수량단위','구성단위'],
 'manufacturer':['제조사','제조자'], 'origin':['원산지','제조국'], 'model':['모델명','모델번호'], 'search_tags':['검색어','검색태그','키워드','searchtags']}

def now(): return datetime.now(KST).isoformat(timespec='seconds')
def num(value, label='금액', minimum=0, maximum=10**10):
    try:
        d = Decimal(str(value).replace(',', '').replace('원','').replace('%','').strip())
    except (InvalidOperation, ValueError): raise ValueError(f'{label}: 올바른 숫자를 입력하세요.')
    if not d.is_finite() or not Decimal(str(minimum)) <= d <= Decimal(str(maximum)):
        raise ValueError(f'{label}: {minimum}~{maximum} 범위여야 합니다.')
    return d
def integer(v, label, minimum=0, maximum=10**10):
    d = num(v, label, minimum, maximum)
    if d != d.to_integral_value(): raise ValueError(f'{label}: 정수를 입력하세요.')
    return int(d)
def price(cost, markup, rounding=10):
    c, m = num(cost,'원가'), num(markup,'마진율',0,1000)
    step = integer(rounding,'올림 단위',1,10000)
    return int((c*(1+m/100)/step).to_integral_value(rounding=ROUND_CEILING)*step)
def is_url(value):
    p = parse.urlsplit(str(value))
    return p.scheme in ('https','http') and bool(p.hostname) and p.username is None
def safe_cell(value):
    if isinstance(value,str) and value.lstrip().startswith(('=', '+', '-', '@')): return "'"+value
    return value
def parse_list(value, label):
    if value is None or value == '': return []
    v = json.loads(value) if isinstance(value,str) else value
    if not isinstance(v,list) or any(not isinstance(x,dict) for x in v):
        raise ValueError(f'{label}: JSON 객체 배열이어야 합니다.')
    return v
def normalize(p):
    if type(p.get('registration_excluded',False)) is not bool:raise ValueError('등록 제외 여부를 확인하세요.')
    result = {k: str(p.get(k,'') or '').strip() for k in
              ('sku','name','image','detail','brand','source_url','manufacturer','origin','model','unit_label')}
    if not result['sku'] or not result['name']: raise ValueError('상품코드와 상품명이 필요합니다.')
    if len(result['name']) > 100: raise ValueError('상품명은 100자 이하로 입력하세요.')
    result.update(source=str(p.get('source') or '직접 입력'),
      cost=integer(p.get('cost',0),'원가'), markup=float(num(p.get('markup',30),'마진율',0,1000)),
      rounding=integer(p.get('rounding',10),'올림 단위',1,10000),
      shipping=integer(p.get('shipping',3000),'배송비'),
      supplier_shipping=integer(p.get('supplier_shipping',3000),'공급사배송비'),
      fee=float(num(p.get('fee',10.8),'예상 수수료율',0,99)),
      stock=integer(p.get('stock',0),'재고',0,99999),
      category=re.sub(r'\.0$','',str(p.get('category','') or '').strip()),
      availability=str(p.get('availability') or '정상'),
      demo=bool(p.get('demo',False)), memo=str(p.get('memo','')))
    if result['availability'] not in ('정상','품절','단종'): raise ValueError('공급상태는 정상 / 품절 / 단종 중 선택하세요.')
    for k in ('options','notices','attributes','certifications','documents'):
        result[k] = parse_list(p.get(k,[]),HEADERS[k])
    for option in result['options']:
        if 'attributes' in option:option['attributes']=parse_list(option['attributes'],'옵션 속성')
        if 'cost' in option:option['cost']=integer(option['cost'],'옵션 원가')
        if 'stock' in option:option['stock']=integer(option['stock'],'옵션 재고',0,99999)
        if 'unitCount' in option:option['unitCount']=integer(option['unitCount'],'옵션 단위수량',1,100000)
    if len(result['options'])>200: raise ValueError('쿠팡 상품당 옵션은 최대 200개입니다.')
    from productinfo import source_info,fill_product,search_tags
    result['source_info']=source_info(p.get('source_info'))
    result['search_tags']=search_tags(p.get('search_tags'))
    result['notice_auto_category']=str(p.get('notice_auto_category') or '')[:200]
    result['registration_excluded']=p.get('registration_excluded',False)
    result['composition_auto']=bool(p.get('composition_auto',False))
    result['unit_count']=integer(p['unit_count'],'구성 수량',1,100000) if p.get('unit_count') not in (None,'') else None
    if len(result['unit_label'])>20:raise ValueError('판매 단위는 20자 이하로 입력하세요.')
    result['auto_info']=copy_info=p.get('auto_info') or []
    if not isinstance(copy_info,list) or any(not isinstance(x,dict) for x in copy_info):raise ValueError('자동 채움 내역 형식을 확인하세요.')
    result,_=fill_product(result)
    result['sale_price'] = price(result['cost'],result['markup'],result['rounding'])
    return result

class Store:
    def __init__(self, directory):
        self.directory=Path(directory); self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory/'wingdesk.sqlite3'; self.lock=threading.RLock()
        with self.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, source TEXT, sku TEXT,
             data TEXT NOT NULL, state TEXT NOT NULL DEFAULT '대기', remote_id TEXT DEFAULT '',
             created TEXT, updated TEXT, UNIQUE(source,sku));
             CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY, data TEXT);
             CREATE TABLE IF NOT EXISTS product_notes(category TEXT PRIMARY KEY, content TEXT NOT NULL);
             CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, data TEXT);
             CREATE TABLE IF NOT EXISTS meta(category TEXT PRIMARY KEY, data TEXT, fetched TEXT);''')
            # A crash after POST may have created a remote item. Never silently retry it.
            db.execute("UPDATE products SET state='결과 확인 필요' WHERE state IN ('전송 중','전송 대기')")
            for row in db.execute('SELECT id,data FROM jobs').fetchall():
                j=json.loads(row['data'])
                if j.get('state') in ('진행 중','준비 중'):
                    j['state']='중단됨'; j['message']='프로그램이 종료되었습니다. 전송한 상품은 Wing에서 확인하세요.'
                    db.execute('UPDATE jobs SET data=? WHERE id=?',(json.dumps(j,ensure_ascii=False),row['id']))
    def connect(self):
        db=sqlite3.connect(self.path,timeout=30); db.row_factory=sqlite3.Row; return db
    def product_notes(self):
        with self.connect() as db:
            return {row['category']:row['content'] for row in db.execute('SELECT category,content FROM product_notes')}
    def save_product_note(self, category, content):
        if category not in ('pending','registered') or not isinstance(content,str) or len(content)>10000:
            raise ValueError('메모는 10,000자 이하로 입력하세요.')
        with self.lock,self.connect() as db:
            db.execute('INSERT OR REPLACE INTO product_notes(category,content) VALUES(?,?)',(category,content))
    def products(self):
        with self.connect() as db: rows=db.execute('SELECT * FROM products ORDER BY created DESC').fetchall()
        return [self.unpack(r) for r in rows]
    def unpack(self,r):
        p=json.loads(r['data']); p.update(id=r['id'],state=r['state'],remote_id=r['remote_id'],created=r['created'],updated=r['updated'])
        from productinfo import sync_composition
        p=sync_composition(p)
        p['profit']=round(p['sale_price']*(1-p['fee']/100)-p['cost']+p['shipping']-p['supplier_shipping'])
        return p
    def get(self,id):
        with self.connect() as db: r=db.execute('SELECT * FROM products WHERE id=?',(id,)).fetchone()
        if r is None: raise ValueError('상품을 찾을 수 없습니다.')
        return self.unpack(r)
    def save(self,p,id=None):
        p=normalize(p)
        with self.lock,self.connect() as db:
            if id:
                old=self.get(id)
                if old['remote_id'] or old['state'] in ('전송 중','전송 대기','결과 확인 필요'):
                    raise ValueError('전송한 상품은 이 화면에서 수정할 수 없습니다. Wing에서 확인하세요.')
                db.execute("UPDATE products SET source=?,sku=?,data=?,state='대기',updated=? WHERE id=?",
                           (p['source'],p['sku'],json.dumps(p,ensure_ascii=False),now(),id))
            else:
                id=uuid.uuid4().hex
                db.execute('INSERT INTO products(id,source,sku,data,created,updated) VALUES(?,?,?,?,?,?)',
                  (id,p['source'],p['sku'],json.dumps(p,ensure_ascii=False),now(),now()))
        return self.get(id)
    def state(self,id,state,remote_id=None):
        with self.lock,self.connect() as db:
            if remote_id is None: db.execute('UPDATE products SET state=?,updated=? WHERE id=?',(state,now(),id))
            else: db.execute('UPDATE products SET state=?,remote_id=?,updated=? WHERE id=?',(state,str(remote_id),now(),id))
    def delete(self,ids):
        with self.lock,self.connect() as db:
            for id in ids:
                p=self.get(id)
                if p['remote_id'] or p['state'] in ('전송 중','전송 대기','결과 확인 필요'):
                    raise ValueError('전송한 상품은 로컬 삭제할 수 없습니다.')
            for id in ids: db.execute('DELETE FROM products WHERE id=?',(id,))
    def bulk(self,ids,changes):
        allowed={'markup','rounding','shipping','supplier_shipping','fee','availability','category'}
        if not set(changes) <= allowed: raise ValueError('허용되지 않은 일괄 변경 항목입니다.')
        with self.lock,self.connect() as db:
            updates=[]
            for id in ids:
                old=self.get(id)
                if old['remote_id'] or old['state'] in ('전송 중','전송 대기','결과 확인 필요'):
                    raise ValueError('전송한 상품은 일괄 수정할 수 없습니다.')
                p=normalize({**old,**changes});updates.append((p,id))
            for p,id in updates:
                db.execute("UPDATE products SET data=?,state='대기',updated=? WHERE id=?",(json.dumps(p,ensure_ascii=False),now(),id))
        return len(updates)
    def settings(self):
        with self.connect() as db: r=db.execute('SELECT data FROM settings WHERE id=1').fetchone()
        return json.loads(r['data']) if r else {}
    def set_settings(self,p):
        with self.connect() as db: db.execute('INSERT OR REPLACE INTO settings(id,data) VALUES(1,?)',(json.dumps(p,ensure_ascii=False),))
    def job(self,j):
        with self.lock,self.connect() as db: db.execute('INSERT OR REPLACE INTO jobs(id,data) VALUES(?,?)',(j['id'],json.dumps(j,ensure_ascii=False)))
    def jobs(self):
        with self.connect() as db: rows=db.execute('SELECT data FROM jobs ORDER BY rowid DESC LIMIT 100').fetchall()
        return [json.loads(r[0]) for r in rows]
    def meta(self,category,data=None):
        with self.connect() as db:
            if data is not None:
                db.execute('INSERT OR REPLACE INTO meta VALUES(?,?,?)',(str(category),json.dumps(data,ensure_ascii=False),now()))
                return data
            r=db.execute('SELECT data FROM meta WHERE category=?',(str(category),)).fetchone()
        return json.loads(r[0]) if r else None

def dpapi(data, decrypt=False):
    if os.name!='nt': raise ValueError('영구 키 저장은 Windows에서만 지원합니다.')
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_ubyte))]
    raw=ctypes.create_string_buffer(data); source=Blob(len(data),ctypes.cast(raw,ctypes.POINTER(ctypes.c_ubyte)));target=Blob()
    func=ctypes.windll.crypt32.CryptUnprotectData if decrypt else ctypes.windll.crypt32.CryptProtectData
    description_type=ctypes.POINTER(wintypes.LPWSTR) if decrypt else wintypes.LPCWSTR
    func.argtypes=[ctypes.POINTER(Blob),description_type,ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
    func.restype=wintypes.BOOL
    ok=func(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target))
    if not ok: raise OSError('Windows API 키 암호화/복호화 실패')
    try: return ctypes.string_at(target.pbData,target.cbData)
    finally:
        free=ctypes.windll.kernel32.LocalFree
        free.argtypes=[ctypes.c_void_p];free.restype=ctypes.c_void_p
        free(target.pbData)

def clean_key(value,label):
    value=str(value or '')
    # Remove only clipboard whitespace / invisible formatting; do not change
    # case or replace visible characters in authentication material.
    value=re.sub(r'[\s\u200b-\u200f\u2060\ufeff]','',value)
    if value and (len(value)>512 or not re.fullmatch(r'[A-Za-z0-9._~+/=\-]+',value)):
        raise ValueError(label+'에 사용할 수 없는 문자가 있습니다. Wing의 API 키 값만 다시 복사해 주세요. 입력한 키는 지우지 않았습니다.')
    return value

class Credentials:
    def __init__(self,directory):
        self.path=Path(directory)/'credentials.dpapi';self.values={};self.lock=threading.RLock();self.load_error=''
        if os.name=='nt' and self.path.exists():
            try:
                values=json.loads(dpapi(self.path.read_bytes(),True).decode())
                if not isinstance(values,dict):raise ValueError('invalid key storage')
                self.values={k:values.get(k,'') for k in ('access_key','secret_key')}
            except (OSError,ValueError,UnicodeError):
                self.load_error='저장한 API 키를 읽지 못했습니다. 같은 Windows 사용자로 실행하거나 API 키를 다시 입력해 저장해 주세요.'
    def candidate(self,p):
        if p.get('clear_keys'):return {}
        values=dict(self.values)
        for k,label in [('access_key','Access Key'),('secret_key','Secret Key')]:
            value=clean_key(p.get(k,''),label)
            if value:values[k]=value
        return values
    def set(self,p):
        with self.lock:
            values=self.candidate(p)
            if p.get('clear_keys'):
                try:self.path.unlink(missing_ok=True)
                except OSError:raise ValueError('저장한 API 키를 삭제하지 못했습니다. 다른 WingDesk 창을 닫고 다시 시도해 주세요.') from None
            elif os.name=='nt':
                temporary=self.path.with_suffix('.tmp')
                try:
                    temporary.write_bytes(dpapi(json.dumps(values).encode()))
                    os.replace(temporary,self.path)
                except OSError:
                    raise ValueError('API 키를 Windows에 저장하지 못했습니다. 입력한 내용은 유지됩니다. 연결 오류 기록을 저장하고 다시 시도해 주세요.') from None
                finally:
                    try:temporary.unlink(missing_ok=True)
                    except OSError:pass
            self.values=values;self.load_error=''
    def ready(self):return all(self.values.get(k) for k in ('access_key','secret_key'))

class RemoteRejected(Exception): pass
class Uncertain(Exception): pass
class Coupang:
    def __init__(self,credentials):
        with credentials.lock:self.keys=dict(credentials.values)
        self.directory=credentials.path.parent
    @staticmethod
    def auth(method,path,query,keys,stamp=None):
        stamp=stamp or datetime.now(timezone.utc).strftime('%y%m%dT%H%M%SZ')
        message=stamp+method+path+query
        sig=hmac.new(keys['secret_key'].encode(),message.encode(),hashlib.sha256).hexdigest()
        return f"CEA algorithm=HmacSHA256, access-key={keys['access_key']}, signed-date={stamp}, signature={sig}"
    def call(self,method,path,body=None,params=None):
        from apierrors import friendly_error,record,rejection_message
        for k,label in [('access_key','Access Key'),('secret_key','Secret Key')]:self.keys[k]=clean_key(self.keys.get(k,''),label)
        if not self.keys.get('access_key') or not self.keys.get('secret_key'):raise ValueError('먼저 Access Key와 Secret Key를 모두 저장하세요.')
        query=parse.urlencode(params or {})
        try:
            req=request.Request('https://api-gateway.coupang.com'+path+('?' +query if query else ''),
              data=json.dumps(body,ensure_ascii=False).encode() if body is not None else None,method=method,
              headers={'Authorization':self.auth(method,path,query,self.keys),'Content-Type':'application/json;charset=UTF-8','X-EXTENDED-TIMEOUT':'90000'})
            # No redirects or automatic replay of writes carrying authorization.
            class NoRedirect(request.HTTPRedirectHandler):
                def redirect_request(self,*args):return None
            with request.build_opener(NoRedirect()).open(req,timeout=95) as response:
                raw=response.read(4*1024*1024)
            result=json.loads(raw)
        except error.HTTPError as ex:
            raw_error=ex.read(1024*1024).decode('utf-8',errors='replace')
            msg=friendly_error(ex.code,raw_error,method)
            record(self.directory,VERSION,method,path,msg,ex.code)
            if ex.code>=500 or ex.code==408:raise Uncertain(msg) from None
            if method=='POST' and path==BASE+'/seller-products' and ex.code in (400,409,422):
                try:parsed_error=json.loads(raw_error)
                except (ValueError,TypeError):parsed_error=None
                if isinstance(parsed_error,dict):
                    value=parsed_error.get('data');rid=value.get('sellerProductId') if isinstance(value,dict) else value
                    if str(rid or '').isdigit():
                        msg='쿠팡이 상품 ID와 오류를 함께 반환했습니다. Wing에서 실제 등록 여부를 확인하세요. 자동으로 다시 전송하지 않습니다.'
                        record(self.directory,VERSION,method,path,msg,ex.code);raise Uncertain(msg) from None
                    msg=rejection_message(ex.code,parsed_error,method,self.keys.values(),body)
            raise RemoteRejected(msg) from None
        except UnicodeError:
            msg='API 키 또는 업체코드에 사용할 수 없는 문자가 있습니다. Wing에서 값을 다시 복사해 저장하세요.'
            record(self.directory,VERSION,method,path,msg)
            raise ValueError(msg) from None
        except (error.URLError,TimeoutError,OSError,ValueError):
            msg=friendly_error(None,'',method);record(self.directory,VERSION,method,path,msg)
            raise Uncertain(msg) from None
        if not isinstance(result,dict):
            msg=friendly_error(None,'',method);record(self.directory,VERSION,method,path,msg);raise Uncertain(msg)
        # Numeric status is accepted only for documented order operations.
        order_read = method=='GET' and re.fullmatch(r'/v2/providers/openapi/apis/api/v(?:[56]/vendors/[A-Za-z0-9]+/(?:ordersheets(?:/[0-9]+)?|returnRequests)|4/vendors/[A-Za-z0-9]+/exchangeRequests)',path)
        order_write = (method=='PATCH' and re.fullmatch(r'/v2/providers/openapi/apis/api/v4/vendors/[A-Za-z0-9]+/ordersheets/acknowledgement',path)) or (method=='POST' and re.fullmatch(r'/v2/providers/openapi/apis/api/v4/vendors/[A-Za-z0-9]+/orders/invoices',path))
        if (order_read or order_write) and str(result.get('code'))=='200' and isinstance(result.get('data'),(list,dict)):
            result={**result,'code':'SUCCESS'}
        if method=='POST' and path=='/v2/providers/openapi/apis/api/v1/categorization/predict' and str(result.get('code'))=='200' and isinstance(result.get('data'),dict) and 'autoCategorizationPredictionResultType' in result['data']:
            result={**result,'code':'SUCCESS'}
        # Order/return reads use numeric 200, rather than product API SUCCESS.
        if method=='GET' and re.fullmatch(r'/v2/providers/openapi/apis/api/v[56]/vendors/[A-Za-z0-9]+/(ordersheets|returnRequests)',path) and str(result.get('code'))=='200' and isinstance(result.get('data'),list):
            result={**result,'code':'SUCCESS'}
        if str(result.get('code'))=='200' and isinstance(result.get('data'),dict):
            inner=result['data']
            if 'code' in inner:result=inner
            elif str(result.get('message','')).upper()=='SUCCESS':result={'code':'SUCCESS','data':inner}
        # The outbound address-list API documents an unwrapped content /
        # pagination response, unlike the product APIs. Restrict this exception
        # to that exact read-only endpoint.
        if method=='GET' and path=='/v2/providers/marketplace_openapi/apis/api/v2/vendor/shipping-place/outbound' and 'code' not in result and isinstance(result.get('content'),list) and isinstance(result.get('pagination'),dict):
            result={'code':'SUCCESS','data':result}
        if str(result.get('code','')).upper()=='ERROR':
            # A contradictory product ID must never make the product eligible for replay.
            value=result.get('data');rid=value.get('sellerProductId') if isinstance(value,dict) else value
            if method=='POST' and path==BASE+'/seller-products' and str(rid or '').isdigit():
                msg='쿠팡이 상품 ID와 오류를 함께 반환했습니다. Wing에서 실제 등록 여부를 확인하세요. 자동으로 다시 전송하지 않습니다.'
                record(self.directory,VERSION,method,path,msg);raise Uncertain(msg)
            record(self.directory,VERSION,method,path,'쿠팡이 요청 실패(ERROR)를 반환했습니다. 상품별 상세 사유는 등록 현황에서 확인하세요.')
            raise RemoteRejected(rejection_message(None,result,method,self.keys.values(),body))
        if str(result.get('code','')).upper()!='SUCCESS':
            msg=friendly_error(None,result,method);record(self.directory,VERSION,method,path,msg);raise Uncertain(msg)
        return result
    def redact(self,s):
        for k in self.keys.values():
            if k: s=s.replace(k,'[숨김]')
        return s

def payload(p,s,requested=False):
    options=p['options'] or [{'name':'단일상품','stock':p['stock'],'attributes':p['attributes']}]
    items=[]
    for index,o in enumerate(options):
        if o.get('discontinued') or str(o.get('status','')) in ('단종','품절'): continue
        cost=o.get('cost',p['cost']); sp=price(cost,p['markup'],p['rounding'])
        image=o.get('image') or p['image']
        items.append(dict(itemName=str(o.get('name') or f'옵션 {index+1}'),originalPrice=sp,salePrice=sp,
          maximumBuyCount=integer(o.get('stock',p['stock']),'옵션 재고',0,99999), maximumBuyForPerson=0,
          maximumBuyForPersonPeriod=1,outboundShippingTimeDay=integer(s.get('shipping_days',2),'출고 소요일',1,30),
          unitCount=integer(o.get('unitCount',p.get('unit_count') or 1),'단위수량',1,100000),adultOnly='EVERYONE',taxType='TAX',
          parallelImported='NOT_PARALLEL_IMPORTED',overseasPurchased='NOT_OVERSEAS_PURCHASED',pccNeeded=False,
          externalVendorSku=f"{p['source']}:{p['sku']}:{index+1}",
          barcode='',emptyBarcode=True,emptyBarcodeReason='판매자 확인: 바코드 없음',
          searchTags=p.get('search_tags',[]),certifications=p['certifications'],images=[{'imageOrder':0,'imageType':'REPRESENTATION','vendorPath':image}],
          notices=p['notices'],attributes=o.get('attributes',p['attributes']),
          contents=[{'contentsType':'TEXT','contentDetails':[{'content':p['detail'],'detailType':'TEXT'}]}],
          offerCondition='NEW',offerDescription=''))
    return dict(displayCategoryCode=integer(p['category'] or 0,'카테고리코드'),sellerProductName=p['name'],
      vendorId=str(s.get('vendor_id','')),vendorUserId=str(s.get('wing_id','')),displayProductName=p['name'],brand=p['brand'],
      generalProductName=p['name'],manufacture=p.get('manufacturer',''),saleStartedAt=datetime.now(KST).strftime('%Y-%m-%dT%H:%M:%S'),saleEndedAt='2099-12-31T23:59:59',
      deliveryMethod='SEQUENCIAL',deliveryCompanyCode=s.get('courier',''),
      deliveryChargeType='FREE' if p['shipping']==0 else 'NOT_FREE',deliveryCharge=p['shipping'],freeShipOverAmount=0,
      deliveryChargeOnReturn=integer(s.get('return_fee',4000),'반품 배송비'),remoteAreaDeliverable='N',unionDeliveryType='NOT_UNION_DELIVERY',
      returnCenterCode=s.get('return_center',''),returnChargeName=s.get('return_name',''),companyContactNumber=s.get('contact',''),
      returnZipCode=s.get('zipcode',''),returnAddress=s.get('address',''),returnAddressDetail=s.get('address_detail',''),
      returnCharge=integer(s.get('return_fee',4000),'반품 배송비'),
      outboundShippingPlaceCode=integer(s.get('outbound',0) or 0,'출고지 코드'),requested=bool(requested),items=items,
      requiredDocuments=[{'templateName':d.get('templateName',''),
          **({'documentPath':d['documentPath']} if d.get('documentPath') else
             {'vendorDocumentPath':d.get('vendorDocumentPath') or d.get('vendorPath','')})} for d in p['documents']])

def validate(p,s,meta=None,live=False):
    issues=[]
    if p.get('registration_excluded'):issues.append('등록 제외로 분류한 상품입니다. 상품 목록에서 등록 대상으로 되돌리세요.')
    if p.get('demo'): issues.append('연습 상품입니다. 실제 등록은 차단됩니다.')
    if p['availability']!='정상': issues.append('공급사 상품이 품절 또는 단종 상태입니다.')
    if p['cost']<=0: issues.append('원가를 입력하세요.')
    if not is_url(p['image']): issues.append('공개된 대표이미지 URL을 입력하세요.')
    if not p['detail']: issues.append('상세설명 HTML을 입력하세요.')
    if not re.fullmatch(r'[1-9]\d*',p['category']): issues.append('쿠팡 노출 카테고리코드를 입력하세요.')
    for k,label in [('vendor_id','업체코드'),('wing_id','Wing ID'),('courier','택배사'),('outbound','출고지 주소 연결'),
       ('return_center','반품지 주소 연결'),('return_name','반품지명'),('contact','반품 연락처'),('zipcode','반품 우편번호'),
       ('address','반품 주소'),('address_detail','반품 상세주소')]:
        if not str(s.get(k,'')).strip(): issues.append(label+'를 설정하세요.')
    if not p['notices']: issues.append('상품 고시정보를 입력하세요.')
    try: body=payload(p,s)
    except (ValueError,KeyError,TypeError) as ex: return issues+[str(ex)]
    if not body['items']: issues.append('판매 가능한 옵션이 없습니다.')
    names=set()
    for it in body['items']:
        if it['itemName'] in names: issues.append('옵션명이 중복됩니다.')
        names.add(it['itemName'])
        if len(it['itemName'])>150: issues.append('옵션명은 150자 이하로 입력하세요.')
        if it['maximumBuyCount']<=0: issues.append(f"{it['itemName']}: 재고를 확인하세요.")
        if not is_url(it['images'][0]['vendorPath']): issues.append(f"{it['itemName']}: 이미지 URL을 확인하세요.")
        for c in it['certifications']:
            if not c.get('certificationType'): issues.append('인증 종류를 입력하세요.')
        if meta:
            attrs={a.get('attributeTypeName'):a.get('attributeValueName') for a in it['attributes'] if isinstance(a,dict)}
            groups={}
            for a in meta.get('attributes',[]):
                n=a.get('attributeTypeName'); value=attrs.get(n); g=str(a.get('groupNumber','NONE'))
                if a.get('required')=='MANDATORY' and a.get('exposed')!='NONE':
                    if g in ('NONE','0','None',''): 
                        if not value: issues.append(f'{it["itemName"]}: 필수 속성 {n} 누락')
                    else: groups.setdefault(g,[]).append(n)
                if value and a.get('inputType')=='SELECT' and value not in a.get('inputValues',[]):
                    issues.append(f'{n}: 허용값 중 선택하세요.')
                if value and a.get('dataType')=='NUMBER' and a.get('inputType')!='SELECT':
                    units=a.get('usableUnits') or []
                    matched=re.fullmatch(r'\s*([0-9]+(?:\.[0-9]+)?)\s*(.*?)\s*',str(value))
                    if not matched or (units and matched[2] not in units):issues.append(f'{n}: 숫자와 허용 단위를 확인하세요.')
                if value and a.get('dataType')=='DATE':
                    try:datetime.strptime(str(value),'%Y-%m-%d')
                    except ValueError:issues.append(f'{n}: YYYY-MM-DD 날짜 형식을 입력하세요.')
            for g,ns in groups.items():
                if sum(bool(attrs.get(n)) for n in ns)!=1: issues.append(f'속성 그룹 {g}: {", ".join(ns)} 중 하나를 입력하세요.')
            selected={n.get('noticeCategoryName') for n in it['notices']}
            categories={x.get('noticeCategoryName'):x for x in meta.get('noticeCategories',[])}
            if not selected or not selected <= set(categories): issues.append('카테고리에 맞는 고시정보 종류를 선택하세요.')
            for n in selected:
                provided={x.get('noticeCategoryDetailName'):x.get('content') for x in it['notices'] if x.get('noticeCategoryName')==n}
                for requirement in categories.get(n,{}).get('noticeCategoryDetailNames',[]):
                    detail=requirement.get('noticeCategoryDetailName')
                    if requirement.get('required')=='MANDATORY' and not provided.get(detail): issues.append('고시정보 누락: '+str(detail))
            certs={x.get('certificationType'):x for x in it['certifications']}
            choices={c.get('certificationType'):c for c in meta.get('certifications',[])}
            for typ,entry in certs.items():
                if choices and typ not in choices:issues.append('이 카테고리에서 지원하지 않는 인증 종류입니다: '+str(typ))
                if choices.get(typ,{}).get('dataType')=='CODE' and not str(entry.get('certificationCode') or '').strip():issues.append('선택한 인증번호를 입력하세요: '+str(choices[typ].get('name',typ)))
            if 'NOT_REQUIRED' in certs and len(certs)>1:issues.append('인증 대상 아님과 다른 인증정보를 동시에 선택할 수 없습니다.')
            for c in meta.get('certifications',[]):
                typ=c.get('certificationType')
                if c.get('required')=='MANDATORY' and (typ not in certs or (c.get('dataType')=='CODE' and not certs[typ].get('certificationCode'))):
                    issues.append('필수 인증 누락: '+str(c.get('name',typ)))
            docs={d.get('templateName') for d in p['documents'] if d.get('vendorPath') or d.get('vendorDocumentPath') or d.get('documentPath')}
            for d in meta.get('requiredDocumentNames',[]):
                if d.get('required')=='MANDATORY' and d.get('templateName') not in docs: issues.append('필수 구비서류 누락: '+str(d.get('templateName')))
    if live and not meta: issues.append('카테고리 정보 조회를 먼저 완료하세요.')
    return list(dict.fromkeys(issues))

def read_table(raw,filename,sheet=None,header_row=1):
    if len(raw)>12*1024*1024: raise ValueError('파일은 12MB 이하로 업로드하세요.')
    suffix=Path(filename).suffix.lower()
    if suffix=='.xlsx':
        from openpyxl import load_workbook
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            if sum(i.file_size for i in z.infolist())>80*1024*1024: raise ValueError('압축 해제된 엑셀이 너무 큽니다.')
        w=load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
        sheets=w.sheetnames
        s=w[sheet or sheets[0]]
        if s.max_column>200 or s.max_row>10000: raise ValueError('엑셀은 200열, 10,000행 이하로 나누어 주세요.')
        rows=list(s.iter_rows(values_only=True));w.close()
    elif suffix=='.csv':
        sheets=['CSV']
        for encoding in ('utf-8-sig','cp949'):
            try: content=raw.decode(encoding);break
            except UnicodeDecodeError: continue
        else: raise ValueError('CSV 인코딩은 UTF-8 또는 CP949를 사용하세요.')
        rows=list(csv.reader(io.StringIO(content)))
        if len(rows)>10000 or any(len(r)>200 for r in rows): raise ValueError('파일은 200열, 10,000행 이하로 나누어 주세요.')
    else: raise ValueError('.xlsx 또는 .csv 파일만 지원합니다. .xls는 .xlsx로 저장하세요.')
    index=integer(header_row,'머리글 행',1,10000)-1
    if index>=len(rows): raise ValueError('머리글 행을 찾을 수 없습니다.')
    headers=[str(v or '').strip() for v in rows[index]]
    if not headers or not any(headers): raise ValueError('선택한 행에 열 이름이 없습니다.')
    suggestions={}
    for k,aliases in ALIASES.items():
        for i,h in enumerate(headers):
            n=re.sub(r'\s+','',h).lower()
            if n in aliases or n==k: suggestions[k]=i;break
    data=[[str(v) if isinstance(v,datetime) else v for v in r] for r in rows[index+1:] if any(v is not None and v!='' for v in r)]
    return dict(headers=headers,rows=data,sheets=sheets,mapping=suggestions)

def import_rows(store,rows,mapping,source):
    if 'sku' not in mapping or 'name' not in mapping or 'cost' not in mapping: raise ValueError('상품코드 / 상품명 / 원가 열을 연결하세요.')
    result=dict(added=0,duplicate=0,errors=[])
    for i,row in enumerate(rows):
        try:
            p={k:row[int(col)] for k,col in mapping.items() if col is not None and 0<=int(col)<len(row) and row[int(col)] is not None and row[int(col)]!=''}
            p.setdefault('source',source)
            a=str(p.get('availability','정상')).strip()
            if a in ('Y','품절','일시품절'): p['availability']='품절'
            elif a in ('단종','판매중지'): p['availability']='단종'
            elif a in ('N','정상','판매중','판매가능'): p['availability']='정상'
            store.save(p);result['added']+=1
        except sqlite3.IntegrityError: result['duplicate']+=1
        except (ValueError,TypeError,KeyError,IndexError) as ex: result['errors'].append({'row':i+1,'message':str(ex)})
    return result

class Batches:
    def __init__(self,store,credentials): self.store=store;self.credentials=credentials;self.lock=threading.Lock();self.cancel=threading.Event();self.active=None
    def start(self,ids,live=False,requested=False):
        if not isinstance(ids,list) or not ids or len(ids)>1000 or any(not isinstance(x,str) or not x for x in ids) or len(set(ids))!=len(ids): raise ValueError('한 번에 1~1,000개의 서로 다른 상품을 선택하세요.')
        with self.lock,self.store.lock:
            if self.active: raise ValueError('진행 중인 작업을 먼저 완료하세요.')
            s=self.store.settings();ps=[self.store.get(id) for id in ids]
            if live:
                if not self.credentials.ready(): raise ValueError('쿠팡 API 키를 설정하세요.')
                errors=[]
                for p in ps:
                    if p['remote_id'] or p['state'] in ('결과 확인 필요','전송 중','전송 대기'): errors.append(p['sku']+': 이미 전송했거나 등록 여부 확인이 필요합니다.')
                    errors.extend(p['sku']+': '+e for e in validate(p,s,self.store.meta(p['category']),True))
                if errors: raise ValueError('\n'.join(errors[:40]))
            snapshot=[(p,payload(p,s,requested) if live else None) for p in ps]
            j=dict(id=uuid.uuid4().hex,created=now(),started=now(),updated=now(),current=None,state='진행 중',mode='실제 전송' if live else '모의 검사',requested=bool(requested),total=len(ids),done=0,results=[])
            self.store.job(j);self.active=j['id'];self.cancel.clear()
            if live:
                for p in ps:self.store.state(p['id'],'전송 대기')
            threading.Thread(target=self.run,args=(j,snapshot,s,live,Coupang(self.credentials)),daemon=True).start()
        return j
    def run(self,j,snapshot,s,live,client):
        try:
            for p,body in snapshot:
                if self.cancel.is_set():break
                j['current']=dict(product_id=p['id'],sku=p['sku'],name=p['name'],option_count=len(body['items']) if live else len(p['options']) or 1)
                j['updated']=now();self.store.job(j)
                row=dict(product_id=p['id'],sku=p['sku'],name=p['name'],remote_id='')
                if not live:
                    issues=validate(p,s,self.store.meta(p['category']))
                    row.update(state='수정 필요' if issues else '기본 검사 통과',message='\n'.join(issues) or '로컬 필수 항목 검사 통과. 실제 등록 여부는 쿠팡 응답으로 확인합니다.')
                else:
                    self.store.state(p['id'],'전송 중')
                    try:
                        result=client.call('POST',BASE+'/seller-products',body)
                        rid=result.get('data')
                        if isinstance(rid,dict):rid=rid.get('sellerProductId')
                        if not str(rid or '').isdigit():raise Uncertain('등록 상품 ID가 응답에 없습니다. Wing에서 확인하세요.')
                        state='등록됨·확인 필요' if result.get('errorItems') or result.get('details') else ('승인 요청됨' if body['requested'] else '임시저장됨')
                        from apierrors import response_details
                        detail=response_details(result,client.keys.values(),body)
                        row.update(state=state,remote_id=str(rid),message=detail or ('쿠팡이 상품 ID와 확인할 항목을 반환했습니다. Wing에서 등록 내용과 상태를 확인하세요.' if state=='등록됨·확인 필요' else '쿠팡에 상품이 생성되고 판매 승인 요청을 보냈습니다. 심사 결과는 쿠팡 상태 조회에서 확인하세요.' if body['requested'] else '쿠팡에 상품을 임시저장했습니다. 판매 승인 요청 전 상태입니다.'))
                        self.store.state(p['id'],state,rid)
                    except RemoteRejected as ex:
                        row.update(state='실패',message=str(ex));self.store.state(p['id'],'실패')
                    except Exception as ex:
                        row.update(state='결과 확인 필요',message=str(ex) if isinstance(ex,Uncertain) else '예상하지 못한 전송 오류. Wing에서 등록 여부를 확인하세요.')
                        self.store.state(p['id'],'결과 확인 필요')
                j['results'].append(row);j['done']+=1;j['current']=None;j['updated']=now();self.store.job(j)
                if live:
                    self.cancel.wait(0.5)
                    if row['state']=='결과 확인 필요':self.cancel.set()
            if live:
                done={r['product_id'] for r in j['results']}
                for p,_ in snapshot:
                    if p['id'] not in done:self.store.state(p['id'],'대기')
            j['state']='중단됨' if j['done']<j['total'] else '완료'
            j['current']=None;j['updated']=now()
            self.store.job(j)
        finally:
            with self.lock:self.active=None

def template_bytes():
    from openpyxl import Workbook
    w=Workbook();s=w.active;s.title='상품목록';s.append(list(HEADERS.values()))
    s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
    for c in s[1]:c.font=__import__('openpyxl').styles.Font(color='FFFFFF',bold=True);c.fill=__import__('openpyxl').styles.PatternFill('solid',fgColor='2457E8')
    for col in s.columns:s.column_dimensions[col[0].column_letter].width=24
    notes=w.create_sheet('작성안내')
    for row in [('항목','설명'),('필수','상품코드·상품명·원가. 실제 등록 전에 이미지·상세설명·카테고리·재고·고시·인증을 입력하세요.'),
      ('마진율','원가에 더하는 비율(%). 판매가=원가×(1+마진율/100), 설정한 단위로 올림.'),('공급상태','정상 / 품절 / 단종'),
      ('옵션JSON','[{"name":"블랙","cost":12000,"stock":20,"unitCount":1,"attributes":[{"attributeTypeName":"색상","attributeValueName":"블랙"}]}]'),
      ('속성JSON','[{"attributeTypeName":"수량","attributeValueName":"1개"}] 카테고리 조회 결과에 맞게 입력'),
      ('고시정보JSON','[{"noticeCategoryName":"기타 재화","noticeCategoryDetailName":"품명 및 모델명","content":"실제 내용"}]'),
      ('인증정보JSON','[{"certificationType":"NOT_REQUIRED","certificationCode":""}] 인증 비대상임을 확인한 경우에만 사용'),
      ('구비서류JSON','[{"templateName":"서류명","vendorPath":"https://공개URL/서류.jpg"}]'),
      ('원본 자료','첨부된 프로그램 자료-1.xlsx는 요구사항 문서입니다. 상품 데이터 파일은 아닙니다.')]:notes.append(row)
    notes.column_dimensions['A'].width=24;notes.column_dimensions['B'].width=120
    out=io.BytesIO();w.save(out);return out.getvalue()
