"""Human-readable shipping settings using Coupang's documented logistics API.

Sources: https://developers.coupang.com/ko/api/logistics
https://developers.coupang.com/ko/api/products/product-creation
No account data, addresses or credentials are supplied in this package.
"""
from __future__ import annotations
import hashlib,json,re,secrets,threading,time,os
from core import Coupang,RemoteRejected,Uncertain,integer,now

COURIERS=[('CJGLS','CJ대한통운'),('HYUNDAI','롯데택배'),('HANJIN','한진택배'),
 ('KGB','로젠택배'),('EPOST','우체국택배'),('KDEXP','경동택배'),
 ('DAESIN','대신택배'),('HDEXP','합동택배'),('ILYANG','일양택배'),
 ('CHUNIL','천일특송'),('KUNYOUNG','건영택배'),('NHLOGIS','농협택배'),
 ('CVS','CVS택배'),('DIRECT','업체직송'),('DHL','DHL'),('UPS','UPS'),('FEDEX','FedEx')]
OUTBOUND_FIELDS=('outbound_name','outbound_contact','outbound_zipcode','outbound_address',
 'outbound_address_detail','outbound_address_type','outbound_jibun')
RETURN_FIELDS=('return_name','contact','zipcode','address','address_detail')
ALLOWED={'vendor_id','wing_id','courier','return_fee','shipping_days','return_mode',*OUTBOUND_FIELDS,*RETURN_FIELDS}
OUTBOUND_PATH='/v2/providers/marketplace_openapi/apis/api/v2/vendor/shipping-place/outbound'

def return_mode(s):
    return s.get('return_mode') or ('registered' if s.get('return_center') not in (None,'','NO_RETURN_CENTERCODE') else 'direct')

def fingerprint(s):
    # Used only locally to bind a preview to the saved account and address.
    fields=('vendor_id','wing_id',*OUTBOUND_FIELDS)
    return hashlib.sha256(json.dumps({k:s.get(k,'') for k in fields},sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def clean_address(s):return re.sub(r'\s+','',str(s or '')).casefold()

def formatted_phone(value):
    value=str(value or '').strip().replace(' ','')
    if value.isdigit():
        if len(value)==11:value=value[:3]+'-'+value[3:7]+'-'+value[7:]
        elif value.startswith('02') and len(value) in (9,10):value=value[:2]+'-'+value[2:-4]+'-'+value[-4:]
        elif len(value)==10:value=value[:3]+'-'+value[3:6]+'-'+value[6:]
    if not re.fullmatch(r'\d{2,4}-\d{3,4}-\d{4}',value):raise ValueError('출고지 연락처를 확인해 주세요. 예: 010-1234-5678')
    return value

def outbound_body(s):
    vendor=str(s.get('vendor_id','')).strip();user=str(s.get('wing_id','')).strip()
    if not re.fullmatch(r'A[A-Za-z0-9]{1,30}',vendor):raise ValueError('업체코드를 확인해 주세요.')
    if not user:raise ValueError('Wing 로그인 ID를 입력해 주세요.')
    name=str(s.get('outbound_name','')).strip();address=str(s.get('outbound_address','')).strip()
    detail=str(s.get('outbound_address_detail','')).strip();zipcode=str(s.get('outbound_zipcode','')).strip()
    if not name or len(name)>50:raise ValueError('출고지 이름을 50자 이내로 입력해 주세요.')
    if not re.fullmatch(r'\d{5,6}',zipcode):raise ValueError('출고지 우편번호를 숫자 5~6자리로 입력해 주세요.')
    if not address or len(address)>150:raise ValueError('출고지 주소를 150자 이내로 입력해 주세요.')
    if not detail or len(detail)>200:raise ValueError('출고지 상세주소를 200자 이내로 입력해 주세요.')
    phone=formatted_phone(s.get('outbound_contact',''))
    kind=s.get('outbound_address_type') or 'ROADNAME'
    if kind not in ('JIBUN','ROADNAME'):raise ValueError('출고지 주소 종류를 선택해 주세요.')
    def place(kind,address):return dict(addressType=kind,countryCode='KR',companyContactNumber=phone,
        phoneNumber2='',returnZipCode=zipcode,returnAddress=address,returnAddressDetail=detail)
    addresses=[place(kind,address)]
    if kind=='ROADNAME':
        jibun=str(s.get('outbound_jibun','')).strip()
        if not jibun or len(jibun)>150:raise ValueError('새 도로명 출고지를 등록하려면 지번주소도 입력해 주세요. 기존 주소는 주소 가져오기로 선택할 수 있습니다.')
        addresses.append(place('JIBUN',jibun))
    return dict(vendorId=vendor,userId=user,shippingPlaceName=name,global_='false',usable='true',placeAddresses=addresses)

class Shipping:
    def __init__(self,store,credentials):
        self.store=store;self.credentials=credentials;self.lock=threading.RLock();self.choices={};self.plans={}
        self.connection=None

    def connection_identity(self):
        s=self.store.settings()
        keys=dict(self.credentials.values)
        values=[s.get('vendor_id',''),s.get('wing_id',''),keys.get('access_key',''),keys.get('secret_key','')]
        return hashlib.sha256(json.dumps(values,ensure_ascii=False).encode()).hexdigest()

    def connection_state(self):
        if not self.credentials.ready():return dict(status='not_configured',message='키 미입력 · 연결 미확인',checked_at='')
        result=self.connection
        if not result or result['identity']!=self.connection_identity():
            return dict(status='not_checked',message='저장된 키 있음 · 연결 미확인',checked_at='')
        if result['status']=='verified' and time.monotonic()-result['epoch']>=600:
            return dict(status='not_checked',message='연결 재확인 필요',checked_at=result['checked_at'])
        return {k:v for k,v in result.items() if k in ('status','message','checked_at')}

    def save(self,p):
        with self.lock,self.store.lock,self.credentials.lock:
            old=self.store.settings();values={k:str(v).strip() for k,v in p.items() if k in ALLOWED}
            s={**old,**values}
            for k,label,default,low,high in [('return_fee','반품 배송비',4000,0,1000000),('shipping_days','출고 소요일',2,1,30)]:
                if k in values:s[k]=str(integer(values[k] or default,label,low,high))
            if s.get('return_mode') not in (None,'','direct','registered'):raise ValueError('반품지 사용 방식을 확인해 주세요.')
            if s.get('outbound_address_type') not in (None,'','JIBUN','ROADNAME'):raise ValueError('주소 종류를 확인해 주세요.')
            if values.get('courier') and values['courier'] not in dict(COURIERS) and values['courier']!=old.get('courier'):
                raise ValueError('목록에서 택배사를 선택해 주세요.')
            account_changed=any(s.get(k,'')!=old.get(k,'') for k in ('vendor_id','wing_id'))
            def outbound_value(values,k):return values.get(k) or ('ROADNAME' if k=='outbound_address_type' else '')
            if account_changed or any(outbound_value(s,k)!=outbound_value(old,k) for k in OUTBOUND_FIELDS):s['outbound']=''
            if return_mode(s)=='direct':s['return_center']='NO_RETURN_CENTERCODE'
            elif account_changed or return_mode(old)!='registered' or any(s.get(k,'')!=old.get(k,'') for k in RETURN_FIELDS):s['return_center']=''
            self.credentials.candidate(p)  # Validate the whole key pair before any write.
            previous=dict(self.credentials.values);load_error=self.credentials.load_error
            encrypted=self.credentials.path.read_bytes() if self.credentials.path.exists() else None
            self.credentials.set(p)
            try:self.store.set_settings(s)
            except Exception:
                self.credentials.values=previous;self.credentials.load_error=load_error
                if encrypted is None:self.credentials.path.unlink(missing_ok=True)
                else:
                    temporary=self.credentials.path.with_suffix('.rollback')
                    temporary.write_bytes(encrypted);os.replace(temporary,self.credentials.path)
                raise ValueError('설정 저장을 완료하지 못했습니다. 입력한 내용과 기존 API 키를 유지했습니다. 다시 저장해 주세요.') from None
            return s

    def check(self):
        # Check both supported read-only endpoints, even when no addresses have
        # been registered. Response parsing is shared with actual address reads.
        with self.lock,self.store.lock,self.credentials.lock:
            identity=self.connection_identity()
            self.connection=dict(status='checking',message='쿠팡 연결 확인 중',identity=identity,checked_at='',epoch=time.monotonic())
            try:
                outbound=self._pages('outbound',first_only=True)
                returns=self._pages('return',first_only=True)
            except Exception:
                self.connection=dict(status='failed',message='쿠팡 연결 확인 실패',identity=identity,checked_at=now(),epoch=time.monotonic())
                raise
            self.connection=dict(status='verified',message='쿠팡 연결 확인됨 · 출고지·반품지 조회 성공',identity=identity,checked_at=now(),epoch=time.monotonic())
            return dict(connected=True,message='쿠팡 연결 성공 · 출고지와 반품지 조회 가능',outbound_count=len(outbound),return_count=len(returns),connection=self.connection_state())

    def _pages(self,kind,first_only=False):
        s=self.store.settings();vendor=str(s.get('vendor_id',''))
        if not re.fullmatch(r'A[A-Za-z0-9]{1,30}',vendor):raise ValueError('먼저 업체코드와 API 키를 저장해 주세요.')
        if kind not in ('outbound','return'):raise ValueError('주소 종류가 올바르지 않습니다.')
        path=OUTBOUND_PATH if kind=='outbound' else f'/v2/providers/openapi/apis/api/v5/vendors/{vendor}/returnShippingCenters'
        client=Coupang(self.credentials);rows=[]
        for page in range(1,101):
            result=client.call('GET',path,params={'pageNum':page,'pageSize':50})
            data=result.get('data');data=data if isinstance(data,dict) else result
            content=data.get('content');pagination=data.get('pagination')
            if not isinstance(content,list) or not isinstance(pagination,dict):raise ValueError('쿠팡 주소 목록 응답을 확인할 수 없습니다. Wing에서 주소 정보를 확인해 주세요.')
            rows.extend(content)
            try:pages=int(pagination['totalPages'])
            except (KeyError,ValueError,TypeError):raise ValueError('쿠팡 주소 목록의 페이지 정보를 확인할 수 없습니다.')
            if pages<0:raise ValueError('쿠팡 주소 목록의 페이지 정보를 확인할 수 없습니다.')
            if page>=pages or first_only:break
        else:raise ValueError('등록된 주소가 너무 많습니다. Wing에서 주소를 정리한 뒤 다시 가져와 주세요.')
        result=[]
        for row in rows:
            if not isinstance(row,dict) or row.get('usable') in (False,'false','N'):continue
            if kind=='return' and row.get('vendorId') and row['vendorId']!=vendor:continue
            code=str(row.get('outboundShippingPlaceCode' if kind=='outbound' else 'returnCenterCode',''))
            if not code.isdigit() or int(code)<=0:continue
            places=row.get('placeAddresses') or []
            if not isinstance(places,list):continue
            domestic=[a for a in places if isinstance(a,dict) and a.get('countryCode','KR')=='KR' and a.get('addressType')!='OVERSEA']
            for index,a in enumerate(domestic):
                if not a.get('returnAddress'):continue
                result.append(dict(code=code,name=str(row.get('shippingPlaceName','')),phone=str(a.get('companyContactNumber','')),
                    zipcode=str(a.get('returnZipCode','')),address=str(a['returnAddress']),detail=str(a.get('returnAddressDetail','')),
                    address_type=a.get('addressType') or 'JIBUN',jibun=next((str(x['returnAddress']) for x in domestic if x.get('addressType')=='JIBUN' and x.get('returnAddress')),''),
                    courier=str(row.get('deliverName','')),kind=kind))
        return result

    def load(self,kind):
        with self.lock:
            rows=self._pages(kind);vendor=self.store.settings().get('vendor_id','');now=time.monotonic()
            self.choices={k:v for k,v in self.choices.items() if v[2]>now};items=[]
            for row in rows:
                key=secrets.token_urlsafe(16);self.choices[key]=(row,vendor,now+600)
                items.append({k:v for k,v in row.items() if k!='code'}|{'selection':key})
            return dict(items=items)

    def _apply(self,row):
        s=self.store.settings()
        if row['kind']=='outbound':
            s.update(outbound=row['code'],outbound_name=row['name'],outbound_contact=row['phone'],outbound_zipcode=row['zipcode'],
                outbound_address=row['address'],outbound_address_detail=row['detail'],outbound_address_type=row['address_type'],outbound_jibun=row['jibun'])
        else:
            s.update(return_center=row['code'],return_mode='registered',return_name=row['name'],contact=row['phone'],
                zipcode=row['zipcode'],address=row['address'],address_detail=row['detail'])
        self.store.set_settings(s)

    def choose(self,selection):
        with self.lock,self.store.lock:
            value=self.choices.pop(selection,None)
            if not value or value[2]<time.monotonic():raise ValueError('주소 목록을 다시 가져와 주세요.')
            row,vendor,_=value
            if self.store.settings().get('vendor_id','')!=vendor:raise ValueError('판매자 정보가 변경되었습니다. 주소 목록을 다시 가져와 주세요.')
            self._apply(row)

    def prepare(self):
        with self.lock,self.store.lock:
            s=self.store.settings()
            # Reuse exact existing addresses before requiring a second address
            # form or issuing a non-idempotent creation request.
            if not s.get('outbound_address'):raise ValueError('출고지 주소를 먼저 입력하거나 가져와 주세요.')
            matches=[r for r in self._pages('outbound') if clean_address(r['address'])==clean_address(s.get('outbound_address'))
                and clean_address(r['detail'])==clean_address(s.get('outbound_address_detail')) and r['zipcode']==s.get('outbound_zipcode')]
            codes={r['code'] for r in matches}
            if len(codes)==1:
                self._apply(matches[0]);return {'connected':True}
            if len(codes)>1:raise ValueError('같은 주소의 출고지가 여러 개 있습니다. 주소 가져오기에서 사용할 출고지를 선택해 주세요.')
            body=outbound_body(s);body['global']=body.pop('global_');key=fingerprint(s)
            if key in s.get('outbound_pending',{}):raise ValueError('앞선 출고지 등록 결과를 확인하지 못했습니다. Wing에서 등록 여부를 확인한 뒤 주소 가져오기로 연결해 주세요. 자동으로 다시 등록하지 않습니다.')
            ticket=secrets.token_urlsafe(16);now=time.monotonic()
            self.plans={k:v for k,v in self.plans.items() if v[2]>now};self.plans[ticket]=(key,body,now+600)
            return dict(connected=False,ticket=ticket,preview=dict(name=s['outbound_name'],phone=formatted_phone(s['outbound_contact']),
                zipcode=s['outbound_zipcode'],address=s['outbound_address'],detail=s['outbound_address_detail'],jibun=s.get('outbound_jibun','')))

    def register(self,ticket):
        with self.lock,self.store.lock:
            value=self.plans.pop(ticket,None)
            if not value or value[2]<time.monotonic():raise ValueError('등록할 주소를 다시 확인해 주세요.')
            key,body,_=value;s=self.store.settings()
            if fingerprint(s)!=key:raise ValueError('출고지 또는 판매자 정보가 변경되었습니다. 등록 내용을 다시 확인해 주세요.')
            pending=dict(s.get('outbound_pending',{}))
            if key in pending:raise ValueError('앞선 출고지 등록 결과를 먼저 확인해 주세요.')
            pending[key]=True;s['outbound_pending']=pending;self.store.set_settings(s)
            try:
                result=Coupang(self.credentials).call('POST',f"/v2/providers/openapi/apis/api/v5/vendors/{body['vendorId']}/outboundShippingCenters",body)
                data=result.get('data',{})
                if not isinstance(data,dict):raise Uncertain('출고지 등록 응답을 확인할 수 없습니다. Wing에서 등록 여부를 확인해 주세요.')
                if data.get('resultCode')=='FAIL':raise RemoteRejected(Coupang(self.credentials).redact(str(data.get('resultMessage','출고지 등록을 거절했습니다.'))))
                code=str(data.get('resultMessage',''))
                if data.get('resultCode')!='SUCCESS' or not code.isdigit() or int(code)<=0:raise Uncertain('출고지 등록 결과를 확인할 수 없습니다. 주소 가져오기로 확인해 주세요.')
            except RemoteRejected:
                s=self.store.settings();s['outbound_pending'].pop(key,None);self.store.set_settings(s);raise
            except Uncertain:raise
            except Exception as ex:raise Uncertain('출고지 등록 결과를 확인하지 못했습니다. Wing에서 등록 여부를 확인한 뒤 주소 가져오기를 눌러 주세요.') from ex
            s=self.store.settings();s.update(outbound=code);s['outbound_pending'].pop(key,None);self.store.set_settings(s)
            return {'connected':True}
