"""Fetch an explicitly selected product image without accessing local networks."""
import http.client
import ipaddress
import socket
import ssl
from urllib.parse import urlsplit, urljoin


def public_image(url, limit=6 * 1024 * 1024):
    for _ in range(4):
        p = urlsplit(url)
        if p.scheme not in ('https', 'http') or not p.hostname or p.username or p.password or p.fragment:
            raise ValueError('공개된 상품 이미지 주소만 사용할 수 있습니다.')
        try:
            port = p.port or (443 if p.scheme == 'https' else 80)
            if port != (443 if p.scheme == 'https' else 80):
                raise ValueError()
            addresses = socket.getaddrinfo(p.hostname, port, type=socket.SOCK_STREAM)
            if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
                raise ValueError()
        except (OSError, ValueError):
            raise ValueError('상품 이미지의 공개 인터넷 주소를 확인하세요.') from None
        # Pin the validated address. TLS still validates the original hostname.
        address = addresses[0][4][0]
        connection = http.client.HTTPConnection(p.hostname, port, timeout=25)
        sock = None
        try:
            sock = socket.create_connection((address, port), timeout=25)
            if p.scheme == 'https':
                sock = ssl.create_default_context().wrap_socket(sock, server_hostname=p.hostname)
            connection.sock = sock
            path = p.path or '/'
            if p.query:
                path += '?' + p.query
            connection.request('GET', path, headers={'User-Agent': 'WingDesk/1.7 image reader', 'Accept': 'image/png,image/jpeg,image/webp'})
            response = connection.getresponse()
            if response.status in (301, 302, 303, 307, 308):
                location = response.getheader('Location')
                if not location:
                    raise ValueError('이미지 이동 주소가 없습니다.')
                url = urljoin(url, location)
                continue
            if response.status != 200:
                raise ValueError('이미지를 읽지 못했습니다. 사진 파일을 직접 선택해 주세요.')
            raw = response.read(limit + 1)
            if not raw or len(raw) > limit:
                raise ValueError('이미지는 6MB 이하 파일을 선택하세요.')
            if raw.startswith(b'\x89PNG\r\n\x1a\n'):
                mime = 'image/png'
            elif raw.startswith(b'\xff\xd8\xff'):
                mime = 'image/jpeg'
            elif raw[:4] == b'RIFF' and raw[8:12] == b'WEBP':
                mime = 'image/webp'
            else:
                raise ValueError('PNG·JPG·WEBP 사진 파일이 필요합니다.')
            return raw, mime
        except (OSError, http.client.HTTPException):
            raise ValueError('이미지를 읽지 못했습니다. 사진 파일을 직접 선택해 주세요.') from None
        finally:
            connection.close()
            if sock:
                sock.close()
    raise ValueError('이미지 주소 이동이 너무 많습니다. 사진 파일을 직접 선택하세요.')
