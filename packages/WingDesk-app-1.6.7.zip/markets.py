"""Named stores, Windows-protected keys and bounded marketplace transports."""
from __future__ import annotations
import base64,hashlib,hmac,json,os,re,threading,time,uuid
from pathlib import Path
from urllib import request,error,parse
from types import SimpleNamespace
from core import Coupang,dpapi,now,RemoteRejected,Uncertain

MARKETS={
 'coupang':dict(name='쿠팡',live=True,fields=[('vendor_id','업체코드',False),('wing_id','Wing ID',False),('access_key','Access Key',True),('secret_key','Secret Key',True)],guide='https://developers.coupang.com/ko'),
 'naver':dict(name='스마트스토어',live=True,fields=[('client_id','애플리케이션 ID',True),('client_secret','애플리케이션 시크릿',True)],guide='https://apicenter.commerce.naver.com/docs/auth'),
 'auction':dict(name='옥션 2.0',live=True,fields=[('master_id','ESM 마스터 ID',False),('seller_id','옥션 판매자 ID',False),('issuer','API 발급 시 등록한 발행자 도메인',False),('secret_key','ESM API Secret Key',True)],guide='https://etapi.gmarket.com/pages/API-가이드'),
 'gmarket':dict(name='G마켓 2.0',live=True,fields=[('master_id','ESM 마스터 ID',False),('seller_id','G마켓 판매자 ID',False),('issuer','API 발급 시 등록한 발행자 도메인',False),('secret_key','ESM API Secret Key',True)],guide='https://etapi.gmarket.com/pages/API-가이드'),
 '11st':dict(name='11번가',live=False,fields=[('seller_id','판매자 ID',False),('api_key','OPEN API KEY',True)],guide='https://openapi.11st.co.kr/openapi/OpenApiFrontMain.tmall',reason='공식 주문 API 상세 규격 확인 필요 · 주문 파일 가져오기 지원'),
 'lotteon':dict(name='롯데ON',live=False,fields=[('seller_id','판매자 ID',False),('api_key','OPEN API 인증키',True)],guide='https://api.lotteon.com',reason='판매자용 주문 API 규격 확인 필요 · 주문 파일 가져오기 지원'),
 'kakao':dict(name='카카오 톡스토어',live=True,fields=[('admin_key','연동대행사 ADMIN KEY',True),('seller_key','판매자 API 인증키',True)],guide='https://shopping-developers.kakao.com'),
 'gsshop':dict(name='GS SHOP',live=False,fields=[('seller_id','협력사 코드',False),('api_key','제휴 API 인증키',True)],guide='https://partners.gsshop.com/api/apiMain',reason='제휴 API 협의·전문 확인 필요 · 주문 파일 가져오기 지원'),
 'toss_legacy':dict(name='(구)토스',live=False,fields=[('seller_id','이전 판매자 ID',False)],guide='https://shopping-docs.toss.im/dev',reason='구형 연동 규격 확인 필요 · 토스 신규 상점 또는 주문 파일 사용'),
 'toss':dict(name='토스쇼핑',live=True,fields=[('access_key','Access Key',True),('secret_key','Secret Key',True)],guide='https://shopping-docs.toss.im/dev/api-1/token'),
}

class StoreRegistry:
    def __init__(self,store,credentials):
        self.store,self.credentials=store,credentials;self.lock=threading.RLock();self.secrets={};self.verified={};self.tokens={};self.load_error=''
        self.path=store.directory/'market-credentials.dpapi'
        with store.connect() as db:db.execute('CREATE TABLE IF NOT EXISTS market_stores(id TEXT PRIMARY KEY,data TEXT NOT NULL)')
        if os.name=='nt' and self.path.exists():
            try:
                value=json.loads(dpapi(self.path.read_bytes(),True).decode())
                if not isinstance(value,dict):raise ValueError()
                self.secrets=value
            except Exception:self.load_error='상점 인증 정보를 읽지 못했습니다. 같은 Windows 사용자로 실행하거나 키를 다시 입력하세요.'
    def legacy(self):
        s=self.store.settings();vendor=s.get('vendor_id','')
        if not vendor:return None
        identity=hashlib.sha256(json.dumps([vendor,s.get('wing_id','')],ensure_ascii=False).encode()).hexdigest()[:20]
        return dict(id='legacy-'+identity,market='coupang',name='기존 쿠팡 상점',vendor_id=vendor,wing_id=s.get('wing_id',''),legacy=True,enabled=True,primary=True)
    def all(self):
        with self.store.connect() as db:items=[json.loads(r[0]) for r in db.execute('SELECT data FROM market_stores ORDER BY rowid')]
        legacy=self.legacy()
        
        if legacy:legacy['primary']=not any(x.get('primary') for x in items)
        return ([legacy] if legacy else [])+items
    def get(self,id):
        item=next((x for x in self.all() if x['id']==id),None)
        if item is None:raise ValueError('상점을 선택하세요. 연결 설정이 변경된 상점은 다시 선택해야 합니다.')
        return item
    def keys(self,id):
        p=self.get(id)
        if p.get('legacy'):
            with self.credentials.lock:return {**p,**self.credentials.values}
        with self.lock:return {**p,**self.secrets.get(id,{})}
    def fingerprint(self,id):
        keys=self.keys(id);market=self.get(id)['market'];identity={k:keys.get(k,'') for k,_,_ in MARKETS[market]['fields']}
        return hashlib.sha256(json.dumps([market,identity],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    def public(self,p):
        spec=MARKETS[p['market']];keys=self.keys(p['id']);receipt=self.verified.get(p['id'])
        configured=all(keys.get(k) for k,_,_ in spec['fields'])
        status='not_configured' if not configured else 'not_checked'
        if not spec['live']:status='setup_required'
        elif receipt and receipt['fingerprint']==self.fingerprint(p['id']) and time.monotonic()-receipt['epoch']<600:status=receipt['status']
        return dict(**p,market_name=spec['name'],api_available=spec['live'],configured=configured,status=status,
                    checked_at=receipt['at'] if receipt and receipt['fingerprint']==self.fingerprint(p['id']) else '',
                    has_credentials={k:bool(keys.get(k)) for k,_,_ in spec['fields']},reason=spec.get('reason',''),key_load_error=self.load_error)
    def state(self):return dict(stores=[self.public(p) for p in self.all()],markets=[dict(id=k,**v) for k,v in MARKETS.items()])
    def save(self,p):
        with self.lock,self.store.lock:
            if self.load_error:raise ValueError('기존 상점 인증 파일을 읽지 못했습니다. 키를 보호하기 위해 덮어쓰지 않습니다. 기존 Windows 사용자 계정으로 실행하세요.')
            id=p.get('id');old=self.get(id) if id else None
            if old and old.get('legacy'):raise ValueError('기존 쿠팡 상점은 쿠팡 연결 설정에서 수정하세요.')
            market=old['market'] if old else p.get('market')
            if market not in MARKETS:raise ValueError('마켓을 선택하세요.')
            name=str(p.get('name','')).strip()
            if not name or len(name)>40:raise ValueError('상점 별칭을 1~40자로 입력하세요.')
            if any(x['name']==name and x['id']!=id for x in self.all()):raise ValueError('다른 별칭을 입력하세요.')
            id=id or uuid.uuid4().hex;item=dict(id=id,market=market,name=name,enabled=bool(p.get('enabled',True)),primary=bool(p.get('primary',False)),created=(old or {}).get('created',now()))
            private=dict(self.secrets.get(id,{}))
            values=p.get('credentials',{})
            if not isinstance(values,dict):raise ValueError('상점 인증 정보를 확인하세요.')
            for k,label,secret in MARKETS[market]['fields']:
                value=str(values.get(k,'')).strip()
                if value:
                    if len(value)>2000 or any(ord(c)<32 for c in value):raise ValueError(label+' 입력값을 확인하세요.')
                    if secret:private[k]=value
                    else:item[k]=value
                elif not secret:item[k]=(old or {}).get(k,'')
            previous=dict(self.secrets);encrypted=self.path.read_bytes() if self.path.exists() else None
            self.secrets={**previous,id:private}
            try:
                if os.name=='nt':
                    dest=self.path.with_suffix('.tmp');dest.write_bytes(dpapi(json.dumps(self.secrets).encode()));os.replace(dest,self.path)
                with self.store.connect() as db:
                    if item['primary']:
                        for row in db.execute('SELECT id,data FROM market_stores').fetchall():
                            other=json.loads(row['data']);other['primary']=False;db.execute('UPDATE market_stores SET data=? WHERE id=?',(json.dumps(other,ensure_ascii=False),row['id']))
                    db.execute('INSERT OR REPLACE INTO market_stores VALUES(?,?)',(id,json.dumps(item,ensure_ascii=False)))
            except Exception:
                self.secrets=previous
                if os.name=='nt':
                    if encrypted is None:self.path.unlink(missing_ok=True)
                    else:self.path.write_bytes(encrypted)
                raise ValueError('상점 정보를 저장하지 못했습니다. 기존 정보는 유지합니다.') from None
            self.verified.pop(id,None);self.tokens.pop(id,None)
            return self.public(item)
    def client(self,id):
        store=self.get(id);spec=MARKETS[store['market']]
        if not spec['live']:raise ValueError(spec['reason'])
        keys=self.keys(id)
        if not all(keys.get(k) for k,_,_ in spec['fields']):raise ValueError('상점의 인증 정보를 먼저 입력하세요.')
        if store['market']=='coupang':
            return Coupang(SimpleNamespace(lock=threading.RLock(),values={k:keys[k] for k in ('access_key','secret_key')},path=self.credentials.path))
        return MarketClient(self,id,keys)
    def tested(self,id,success):self.verified[id]=dict(fingerprint=self.fingerprint(id),status='verified' if success else 'failed',at=now(),epoch=time.monotonic())

ALLOWED_HOSTS={'api.commerce.naver.com','sa2.esmplus.com','kapi.kakao.com','oauth2.cert.toss.im','shopping-fep.toss.im'}
def http_json(method,url,body=None,headers=None,form=False):
    p=parse.urlsplit(url)
    if p.scheme!='https' or p.hostname not in ALLOWED_HOSTS or p.port not in (None,443) or p.username:raise ValueError('지원하지 않는 마켓 API 주소입니다.')
    raw=(parse.urlencode(body).encode() if form else json.dumps(body,ensure_ascii=False).encode()) if body is not None else None
    class NoRedirect(request.HTTPRedirectHandler):
        def redirect_request(self,*a):return None
    req=request.Request(url,data=raw,method=method,headers={'Content-Type':'application/x-www-form-urlencoded' if form else 'application/json',**(headers or {})})
    try:
        with request.build_opener(NoRedirect()).open(req,timeout=35) as r:
            raw=r.read(8*1024*1024+1)
        if len(raw)>8*1024*1024:raise ValueError()
        return json.loads(raw)
    except error.HTTPError as ex:
        message=f'마켓 API 요청 실패 (HTTP {ex.code}). 인증키·권한·허용 IP와 입력값을 확인하세요.'
        if ex.code in (408,) or ex.code>=500:raise Uncertain(message) from None
        raise RemoteRejected(message) from None
    except (OSError,TimeoutError,ValueError):raise Uncertain('마켓 응답을 확인하지 못했습니다. 처리 요청은 자동 재전송하지 않습니다.') from None

class MarketClient:
    def __init__(self,registry,id,keys):self.registry,self.id,self.keys=registry,id,keys;self.market=registry.get(id)['market']
    def token(self):
        cached=self.registry.tokens.get(self.id)
        if cached and cached[0]==self.registry.fingerprint(self.id) and cached[2]>time.monotonic():return cached[1]
        if self.market=='naver':
            try:import bcrypt
            except ImportError:raise ValueError('스마트스토어 인증 모듈을 읽지 못했습니다. Windows 배포본을 다시 실행하세요.') from None
            stamp=str(int(time.time()*1000));password=(self.keys['client_id']+'_'+stamp).encode()
            try:sign=base64.b64encode(bcrypt.hashpw(password,self.keys['client_secret'].encode())).decode()
            except ValueError:raise ValueError('스마트스토어 애플리케이션 시크릿 형식을 확인하세요.') from None
            r=http_json('POST','https://api.commerce.naver.com/external/v1/oauth2/token',dict(client_id=self.keys['client_id'],timestamp=stamp,grant_type='client_credentials',client_secret_sign=sign,type='SELF'),form=True)
        elif self.market=='toss':
            r=http_json('POST','https://oauth2.cert.toss.im/token',dict(grant_type='client_credentials',client_id=self.keys['access_key'],client_secret=self.keys['secret_key'],scope='toss-shopping-fep:write'),form=True)
        else:raise ValueError('토큰 인증을 지원하지 않는 마켓입니다.')
        if not isinstance(r,dict) or not r.get('access_token'):raise ValueError('마켓 인증 토큰을 확인하지 못했습니다.')
        self.registry.tokens[self.id]=(self.registry.fingerprint(self.id),r['access_token'],time.monotonic()+max(1,int(r.get('expires_in',3600))-60))
        return r['access_token']
    def call(self,method,path,body=None,params=None):
        keys=self.keys
        if self.market in ('naver','toss'):
            host='https://api.commerce.naver.com/external' if self.market=='naver' else 'https://shopping-fep.toss.im'
            headers={'Authorization':'Bearer '+self.token()}
        elif self.market in ('auction','gmarket'):
            def enc(o):return base64.urlsafe_b64encode(json.dumps(o,separators=(',',':')).encode()).rstrip(b'=').decode()
            head=enc(dict(alg='HS256',typ='JWT',kid=keys['master_id']))
            payload=enc(dict(iss=keys['issuer'],sub='sell',aud='sa.esmplus.com',ssi=('A:' if self.market=='auction' else 'G:')+keys['seller_id'],iat=int(time.time())))
            signature=base64.urlsafe_b64encode(hmac.new(keys['secret_key'].encode(),(head+'.'+payload).encode(),hashlib.sha256).digest()).rstrip(b'=').decode()
            host='https://sa2.esmplus.com';headers={'Authorization':'Bearer '+head+'.'+payload+'.'+signature}
        elif self.market=='kakao':
            host='https://kapi.kakao.com';headers={'Authorization':'KakaoAK '+keys['admin_key'],'Target-Authorization':'KakaoAK '+keys['seller_key'],'channel-ids':'101'}
        else:raise ValueError('마켓의 API 연동이 준비되지 않았습니다.')
        r=http_json(method,host+path+('?' +parse.urlencode(params) if params else ''),body,headers)
        if self.market=='toss':
            if not isinstance(r,dict) or r.get('resultType')!='SUCCESS':raise RemoteRejected('토스쇼핑이 요청을 처리하지 못했습니다. 상점 인증과 조회 조건을 확인하세요.')
            return r.get('success')
        if self.market in ('auction','gmarket'):
            if not isinstance(r,dict) or r.get('ResultCode')!=0:raise RemoteRejected('ESM API가 요청을 처리하지 못했습니다. 인증·조회 조건을 확인하세요.')
            return r.get('Data',r.get('data'))
        return r
