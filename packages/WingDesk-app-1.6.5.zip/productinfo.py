"""Local, evidence-based registration preparation; never fetches pages or creates listings.

Quantity comes from sales composition, not supplier inventory or carton limits.
Detail-page references are an explicit bulk policy; actual mandatory codes remain required.
"""
from __future__ import annotations
import copy,json,re,unicodedata
from html.parser import HTMLParser

DEFAULT_POLICY=dict(notice_reference=True,certification_detail=True,fallback_count=1,fallback_unit='개',basic_preset=True)
COUNT_UNITS=('세트','개입','매입','팩','개','매','장','병','포','캔','박스','스틱','권','캡슐','통','정','봉','마리','롤','켤레','쌍','대','조','종','피스','box','pcs','pc','ea','set')
UNIT_ALIASES={'ea':'개','pcs':'개','pc':'개','set':'세트','box':'박스','개입':'개','매입':'매'}
SOURCE_KEYS={'model','production','origin','productNotificationInformation','certificateInformation','coupangCategoryFullName','unit_count','unit_label'}

def compact(value):return re.sub(r'[\s_\-/()·]+','',unicodedata.normalize('NFKC',str(value or ''))).casefold()
def policy(value=None):
    if value is None:return dict(DEFAULT_POLICY)
    if not isinstance(value,dict) or set(value)-set(DEFAULT_POLICY):raise ValueError('상품 정보 자동 채움 설정을 확인하세요.')
    p={**DEFAULT_POLICY,**value}
    if any(type(p[k]) is not bool for k in ('notice_reference','certification_detail','basic_preset')):raise ValueError('자동 채움과 기본 등록 프리셋 사용 여부를 확인하세요.')
    if p['fallback_count'] is not None and (type(p['fallback_count']) is not int or not 1<=p['fallback_count']<=100000):raise ValueError('기본 구성 수량은 1~100,000 사이로 입력하세요.')
    if p['fallback_unit'] not in COUNT_UNITS:raise ValueError('기본 판매 단위를 선택하세요.')
    return p

def source_info(value):
    if not isinstance(value,dict):return {}
    result={k:copy.deepcopy(v) for k,v in value.items() if k in SOURCE_KEYS}
    try:
        if len(json.dumps(result,ensure_ascii=False).encode())>256*1024:raise ValueError('공급사 상품 안내정보가 너무 큽니다.')
    except (TypeError,RecursionError):raise ValueError('공급사 상품 안내정보 형식을 확인하세요.') from None
    return result

class DetailText(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.parts=[];self.hidden=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','template','noscript'):self.hidden+=1
        if not self.hidden:
            if tag in ('p','div','br','tr','td','th','li'):self.parts.append('\n')
            if tag=='img':self.parts.extend(' '+str(v)+' ' for k,v in attrs if k in ('alt','title') and v)
    def handle_endtag(self,tag):
        if tag in ('script','style','template','noscript') and self.hidden:self.hidden-=1
        if tag in ('p','div','tr','td','th','li'):self.parts.append('\n')
    def handle_data(self,text):
        if not self.hidden:self.parts.append(text)
def detail_text(value):
    p=DetailText();p.feed(str(value or '')[:2*1024*1024]);return unicodedata.normalize('NFKC',' '.join(p.parts))
def pairs(value):
    if isinstance(value,str) and value.lstrip().startswith(('{','[')):
        try:value=json.loads(value)
        except ValueError:return
    if isinstance(value,dict):
        name=next((value[k] for k in ('attributeTypeName','name','title','label','noticeCategoryDetailName') if value.get(k)),None)
        val=next((value[k] for k in ('attributeValueName','value','content') if value.get(k) not in (None,'')),None)
        if name is not None and val is not None:yield str(name),str(val)
        for k,v in value.items():
            if isinstance(v,(dict,list)):yield from pairs(v)
            elif v is not None:yield str(k),str(v)
    elif isinstance(value,list):
        for v in value:yield from pairs(v)
def sources(p,o=None,plain=None):
    info=p.get('source_info') or {};result=[]
    if o:
        attrs=o.get('source_attributes') or []
        result.append(('공급사 옵션',dict(pairs(attrs))))
        result.append(('옵션명',str(o.get('name') or '')))
    result.extend([('공급사 고시',dict(pairs(info.get('productNotificationInformation')))),('상품명',p.get('name','')),('상세설명',detail_text(p.get('detail')) if plain is None else plain)])
    return result
def unit(value):return UNIT_ALIASES.get(str(value).casefold(),str(value))
def count_candidates(text):
    expression=r'(?<![A-Za-z0-9.])(\d{1,6})\s*('+ '|'.join(sorted(COUNT_UNITS,key=len,reverse=True))+r')(?=$|[^A-Za-z가-힣]|세트|묶음|구성|포장)'
    text=unicodedata.normalize('NFKC',str(text));result=set()
    for m in re.finditer(expression,text,re.I):
        context=text[max(0,m.start()-25):m.start()]
        if re.search(r'재고|최대|최소|주문한도|묶음배송|배송가능|박스\s*(?:입수|당)',context):continue
        if 1<=int(m[1])<=100000:result.add((int(m[1]),unit(m[2])))
    return result
def quantity(p,o=None,plain=None):
    if o and o.get('unitCount') and o.get('unit_label'):return (int(o['unitCount']),unit(o['unit_label'])),'입력한 옵션 구성 수량'
    if p.get('unit_count') and p.get('unit_label'):return (int(p['unit_count']),unit(p['unit_label'])),'입력한 구성 수량'
    for attrs in (((o or {}).get('attributes') or []),p.get('attributes') or []):
        values={v for a in attrs if compact(a.get('attributeTypeName')) in ('수량','개수','구성수량','판매수량','단위수량') for v in count_candidates(a.get('attributeValueName',''))}
        if len(values)==1:return next(iter(values)),'입력한 수량 속성'
        if len(values)>1:return None,'입력한 수량 속성에서 서로 다른 값이 발견됨'
    for label,text in sources(p,o,plain):
        if isinstance(text,dict):
            text=' '.join(v for k,v in text.items() if compact(k) in ('수량','구성수량','구성개수','판매단위','판매수량','단위수량','입수','구성'))
        choices=count_candidates(text)
        if len(choices)==1:return next(iter(choices)),label
        if len(choices)>1:return None,label+'에서 구성 수량이 여러 개 발견됨'
    return None,''
def choose_unit(found,attribute):
    n,u=found;allowed=attribute.get('usableUnits') or []
    choices=[x for x in allowed if unit(x)==u]
    if allowed and not choices:return None
    return str(n)+(choices[0] if choices else u)
def text_value(attribute,evidence):
    name=str(attribute.get('attributeTypeName') or '');key=compact(name)
    color=key in ('색상','컬러','color');size=('사이즈' in key or key in ('크기','size'))
    synonyms={'color':('색상','컬러','color'),'size':('사이즈','크기','size','패션의류잡화사이즈')}
    values=attribute.get('inputValues') or []
    for label,text in evidence:
        if isinstance(text,dict):
            direct=[v for k,v in text.items() if compact(k)==key or color and compact(k) in synonyms['color'] or size and compact(k) in synonyms['size']]
            if len(set(direct))==1:
                candidate=direct[0].strip()
                if attribute.get('inputType')!='SELECT' or candidate in values:return candidate,label
            text=' '.join(text.values())
        if attribute.get('inputType')=='SELECT':
            matched=[]
            for v in values:
                if not isinstance(v,str) or not v:continue
                pattern=re.escape(v)
                if re.fullmatch(r'[A-Za-z0-9]+',v):pattern=r'(?<![A-Za-z0-9])'+pattern+r'(?![A-Za-z0-9])'
                if re.search(pattern,str(text),re.I):matched.append(v)
                elif color:
                    groups=(('화이트','흰색','백색','white'),('블랙','검정','검은색','흑색','black'),('레드','빨강','적색','red'),('블루','파랑','청색','blue'),('그레이','회색','gray','grey'))
                    aliases=next((g for g in groups if v.casefold() in g),())
                    if any(x in str(text).casefold() for x in aliases):matched.append(v)
            if len(set(matched))==1:return matched[0],label
            if len(set(matched))>1:return None,''
        elif (color or size) and attribute.get('dataType')!='NUMBER':
            terms=('반투명','투명','화이트','블랙','백색','흑색','검정','흰색','빨강','파랑','회색','노랑','녹색','갈색','베이지','핑크','실버','골드') if color else ('FREE','프리사이즈','대형','중형','소형','XXL','XL','XS','S','M','L')
            found=[]
            for term in terms:
                pattern=re.escape(term)
                if re.fullmatch(r'[A-Za-z]+',term):pattern=r'(?<![A-Za-z0-9])'+pattern+r'(?![A-Za-z0-9])'
                if re.search(pattern,str(text),re.I) and not (term=='투명' and '반투명' in str(text)):found.append(term)
            if len(set(found))==1:return found[0],label
            if len(set(found))>1:return None,''
        elif attribute.get('dataType')=='NUMBER':
            allowed=attribute.get('usableUnits') or []
            if allowed:
                found={(m[1],m[2]) for m in re.finditer(r'(?<![A-Za-z0-9.])(\d+(?:\.\d+)?)\s*('+'|'.join(re.escape(u) for u in sorted(allowed,key=len,reverse=True))+r')(?![A-Za-z])',str(text),re.I)}
                if len(found)==1:return ''.join(next(iter(found))),label
    return None,''
def known_certifications(info,meta):
    result=[];allowed={c.get('certificationType'):c for c in meta.get('certifications',[])}
    def walk(value):
        if isinstance(value,list):
            for x in value:walk(x)
        if not isinstance(value,dict):return
        typ=value.get('certificationType');code=value.get('certificationCode')
        if typ in allowed and (allowed[typ].get('dataType')!='CODE' or str(code or '').strip()):result.append(dict(certificationType=typ,certificationCode=str(code or '')))
        for x in value.values():
            if isinstance(x,(dict,list)):walk(x)
    walk(info.get('certificateInformation'))
    return result

def fill_product(product,meta=None,settings=None):
    """Return a copy and per-field provenance. Existing explicit values win."""
    p=copy.deepcopy(product);rules=policy(settings);changes=[];notes=[]
    def changed(field,value,via,option=''):
        changes.append(dict(field=field,value=value,source=via,option=option))
    info=source_info(p.get('source_info') or {})
    plain=detail_text(p.get('detail'));has_detail=bool(plain.strip() or re.search(r'<img\b',str(p.get('detail') or ''),re.I))
    for key,source in [('manufacturer','production'),('origin','origin'),('model','model')]:
        if not p.get(key) and isinstance(info.get(source),str) and info[source].strip():p[key]=info[source].strip();changed(key,p[key],'공급사 정보')
    options=p.get('options') or [None]
    for o in options:
        found,via=quantity(p,o,plain)
        target=o if o is not None else p
        if found:
            if not p.get('unit_count') and o is None:p['unit_count']=found[0];p['unit_label']=found[1];changed('구성 수량',str(found[0])+found[1],via)
            if o is not None and 'unitCount' not in o:o['unitCount']=found[0];o['unit_label']=found[1];changed('구성 수량',str(found[0])+found[1],via,o.get('name',''))
        if meta is None:continue
        own=target.setdefault('attributes',[])
        if o is not None:
            combined={a.get('attributeTypeName'):a for a in (p.get('attributes') or [])+own};own[:]=list(combined.values())
        existing={a.get('attributeTypeName'):a for a in own}
        evidence=sources(p,o,plain)
        for a in meta.get('attributes',[]):
            name=a.get('attributeTypeName');old=existing.get(name)
            if not name or old and str(old.get('attributeValueName') or '').strip():continue
            # Fill mandatory attributes and actual purchase options; leave optional search filters alone.
            if a.get('exposed')=='NONE' or a.get('required')!='MANDATORY' and a.get('exposed')!='EXPOSED':continue
            group=str(a.get('groupNumber','NONE'))
            if group not in ('NONE','0','None','') and any(existing.get(x.get('attributeTypeName'),{}).get('attributeValueName') for x in meta.get('attributes',[]) if str(x.get('groupNumber','NONE'))==group):continue
            value=None;origin=''
            if compact(name) in ('수량','개수','구성수량','판매수량','단위수량'):
                if found:value=choose_unit(found,a);origin=via
                elif (o or {}).get('unitCount') or p.get('unit_count'):
                    count=(o or {}).get('unitCount') or p['unit_count']
                    base=a.get('basicUnit') if a.get('basicUnit') not in (None,'','없음') else rules['fallback_unit']
                    value=choose_unit((count,unit(base)),a);origin='입력한 구성 수량과 카테고리 단위'
                elif not via and rules['fallback_count'] is not None:
                    desired='세트' if any(word in p.get('name','').casefold() for word in ('세트','set')) else rules['fallback_unit']
                    value=choose_unit((rules['fallback_count'],unit(desired)),a);origin='기본 판매 단위 설정'
                if not value and via:notes.append(via+' · '+str(name)+' 확인 필요')
            else:value,origin=text_value(a,evidence)
            if value and a.get('inputType')=='SELECT' and value not in (a.get('inputValues') or []):value=None
            if value:
                item=dict(attributeTypeName=name,attributeValueName=value)
                if a.get('exposed') in ('EXPOSED','NONE'):item['exposed']=a['exposed']
                own[:]=[x for x in own if x.get('attributeTypeName')!=name];own.append(item);existing[name]=item
                changed(name,value,origin,(o or {}).get('name',''))
    if meta is not None:
        categories=meta.get('noticeCategories') or []
        selected={x.get('noticeCategoryName') for x in p.get('notices',[])}
        category=next((c for c in categories if c.get('noticeCategoryName') in selected),categories[0] if categories else None)
        if category and has_detail:
            name=category['noticeCategoryName'];existing={(x.get('noticeCategoryName'),x.get('noticeCategoryDetailName')):x for x in p.get('notices',[])}
            notices=[x for x in p.get('notices',[]) if x.get('noticeCategoryName')==name]
            supplier=dict(pairs(info.get('productNotificationInformation')))
            for d in category.get('noticeCategoryDetailNames') or []:
                field=d.get('noticeCategoryDetailName');old=existing.get((name,field))
                if not field or old and str(old.get('content') or '').strip():continue
                value='상세페이지 참조' if rules['notice_reference'] else next((v for k,v in supplier.items() if compact(k)==compact(field)),'')
                if value:
                    notices=[x for x in notices if x.get('noticeCategoryDetailName')!=field];notices.append(dict(noticeCategoryName=name,noticeCategoryDetailName=field,content=value));changed('고시: '+field,value,'상세페이지 참조 설정' if rules['notice_reference'] else '공급사 고시')
            p['notices']=notices
        certs=meta.get('certifications') or [];mandatory=[c for c in certs if c.get('required')=='MANDATORY'];allowed={c.get('certificationType') for c in certs}
        actual=known_certifications(info,meta)
        existing=p.get('certifications') or []
        reference_only=all(c.get('certificationType') in ('NOT_REQUIRED','PRESENTED_IN_DETAIL_PAGE') for c in existing)
        if rules['basic_preset'] and reference_only and not actual:
            if mandatory:notes.append('기본 프리셋의 인증 대상 아님 적용 제외 · 쿠팡 필수 인증정보 확인 필요')
            elif not certs or 'NOT_REQUIRED' in allowed:
                preset=[dict(certificationType='NOT_REQUIRED',certificationCode='')]
                if existing!=preset:p['certifications']=preset;changed('인증정보','인증·신고 대상 아님','기본 등록 프리셋')
            else:notes.append('기본 프리셋의 인증 대상 아님 적용 제외 · 해당 카테고리에서 지원하지 않음')
        if not p.get('certifications'):
            if actual:p['certifications']=actual;changed('인증정보','공급사 인증정보','공급사 정보')
            elif not mandatory and rules['certification_detail'] and 'PRESENTED_IN_DETAIL_PAGE' in allowed and has_detail:
                p['certifications']=[dict(certificationType='PRESENTED_IN_DETAIL_PAGE',certificationCode='')];changed('인증정보','상세설명에 표시','상세페이지 참조 설정')
            elif not certs:
                p['certifications']=[dict(certificationType='NOT_REQUIRED',certificationCode='')];changed('인증정보','카테고리 인증 항목 없음','쿠팡 카테고리 정보')
            else:
                text=' '.join(str(v) for k,v in pairs(info.get('certificateInformation')))
                if not mandatory and 'NOT_REQUIRED' in allowed and re.search(r'인증\s*(?:대상\s*)?(?:아님|해당\s*없음)|비인증\s*대상',text):
                    p['certifications']=[dict(certificationType='NOT_REQUIRED',certificationCode='')];changed('인증정보','인증 대상 아님','공급사 인증 원문')
    p['auto_info']=(p.get('auto_info') or [])+changes
    p['auto_info']=p['auto_info'][-300:]
    return p,dict(changes=changes,notes=list(dict.fromkeys(notes)))
