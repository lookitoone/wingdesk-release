"""Conservative supplier monitoring and verified Coupang sales removal.

Public supplier page parsers are bound to an exact product identity. Never
infer deletion from HTTP 404, authentication errors or an empty search result.
Coupang endpoints: https://developers.coupang.com/ko/api/products
"""
from __future__ import annotations
import hashlib,json,re,secrets,threading,time
from html.parser import HTMLParser
from urllib import request,error,parse
from core import Coupang,RemoteRejected,Uncertain,BASE,now,integer
BAD={'품절','단종','삭제'}

def supplier_ref(url):
    p=parse.urlsplit(str(url));host=(p.hostname or '').lower()
    if p.scheme!='https' or p.username or p.password or p.port not in (None,443):raise ValueError('공급사의 HTTPS 상품 주소를 입력해 주세요.')
    if host in ('ownerclan.com','www.ownerclan.com') and p.path=='/V2/product/view.php':
        code=parse.parse_qs(p.query).get('selfcode',[''])[0].upper()
        if re.fullmatch(r'W[A-Z0-9]{6}',code):return '오너클랜',code,'https://ownerclan.com/V2/product/view.php?selfcode='+code
    if host in ('domeggook.com','www.domeggook.com','mobile.domeggook.com'):
        m=re.fullmatch(r'/(\d+)/?',p.path)
        if m:return '도매매',m[1],'https://www.domeggook.com/'+m[1]+'?market=dome'
    if host in ('navimro.com','www.navimro.com'):
        m=re.fullmatch(r'/(g|p)/([A-Za-z0-9]+)/?',p.path)
        if m:return '나비엠알오',m[2],'https://www.navimro.com/'+m[1]+'/'+m[2]+'/'
    raise ValueError('오너클랜·도매꾹/도매매·나비엠알오의 상품 주소를 확인해 주세요.')

class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True);self.scripts=[];self.tags=[];self.text=[];self.script=None;self.buf=[];self.hidden=0;self.stack=[];self.headers=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs);self.tags.append((tag,d))
        if tag not in ('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'):self.stack.append((tag,d))
        if tag=='script':self.script=d.get('type','');self.buf=[]
        if tag in ('script','style'):self.hidden+=1
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i][0]==tag:self.stack=self.stack[:i];break
        if tag=='script' and self.script is not None:
            self.scripts.append((self.script,''.join(self.buf)));self.script=None
        if tag in ('script','style'):self.hidden=max(0,self.hidden-1)
    def handle_data(self,data):
        if self.script is not None:self.buf.append(data)
        if not self.hidden:self.text.append(data)
        if not self.hidden and any('product_information_header' in d.get('class','').split() for t,d in self.stack):self.headers.append(data)

def outcome(state,reason,variants=None):return dict(state=state,reason=reason,variants=variants or [])
def availability(value):
    return {'InStock':'정상','OutOfStock':'품절','SoldOut':'품절','Discontinued':'단종'}.get(str(value).split('/')[-1],'확인 필요')

def page_status(source,code,url,html):
    page=Page();page.feed(html);visible=' '.join(page.text)
    # Exact visible exception labels only. Never search generic "품절" over
    # a page: styles, FAQs and recommendation cards also contain it.
    explicit=[t.strip() for t in page.text if t.strip()]
    deleted={'삭제된 상품입니다.','삭제된 상품입니다','삭제된 상품으로 판매가 불가능합니다.'}
    if len(visible)<2000 and any(t in deleted for t in explicit):return outcome('삭제','공급사 오류 화면에 삭제된 상품으로 표시됨')
    if source=='도매매':
        og=[d.get('content','') for t,d in page.tags if t=='meta' and d.get('property')=='og:url']
        identity=any(parse.urlsplit(u).hostname in ('domeggook.com','www.domeggook.com') and parse.urlsplit(u).path.rstrip('/')=='/'+code for u in og)
        if not identity:return outcome('확인 필요','공급사 상품번호를 확인하지 못함')
        statuses=re.findall(r'\bvar\s+itemStatus\s*=\s*[\'"]([^\'"]+)[\'"]',html)
        if not statuses or len(set(statuses))!=1:return outcome('확인 필요','공급사 판매상태를 확인하지 못함')
        status={'진행중':'정상','최소재고부족':'품절','품절':'품절','판매종료':'단종','기간종료':'단종'}.get(statuses[0],'확인 필요')
        return outcome(status,'공급사 판매상태: '+statuses[0])
    if source=='오너클랜':
        # The product header is a rendered text marker, not recommendation links.
        identity=bool(re.fullmatch(r'\s*상품코드\s+'+re.escape(code)+r'\s*',' '.join(page.headers)))
        if not identity:return outcome('확인 필요','공급사 상품코드를 확인하지 못함')
        classes=[d.get('class','').split() for t,d in page.tags]
        if any('detail_box4_soldout' in c for c in classes):return outcome('품절','상품 구매 영역에 품절 표시')
        if any(d.get('id')=='cartBtn' for t,d in page.tags) and any('detail_box4' in c for c in classes):return outcome('정상','상품 구매 영역과 상품코드 확인')
        return outcome('확인 필요','공급사 구매 가능 상태를 확인하지 못함')
    if source=='나비엠알오':
        nodes=[]
        def walk(v):
            if isinstance(v,list):
                for x in v:walk(x)
            elif isinstance(v,dict):
                nodes.append(v)
                for k in ('@graph','itemListElement','hasVariant','item'):
                    if k in v:walk(v[k])
        for kind,script in page.scripts:
            if kind=='application/ld+json':
                try:walk(json.loads(script))
                except (ValueError,TypeError):pass
        def same(u):
            try:return supplier_ref(str(u).split('#')[0])[2]==url
            except ValueError:return False
        groups=[n for n in nodes if n.get('@type')=='ProductGroup' and (str(n.get('productGroupID',''))==code and same(n.get('url','')))]
        variants=[n for n in nodes if n.get('@type')=='Product' and (same(n.get('url','')) or same((n.get('isVariantOf') or {}).get('@id','')))]
        values=[]
        for n in variants:
            offers=n.get('offers',{});offers=offers if isinstance(offers,list) else [offers]
            states=[availability(o.get('availability')) for o in offers if isinstance(o,dict)]
            state=states[0] if states and len(set(states))==1 else '확인 필요'
            values.append(dict(code=str(n.get('url','')).strip('/').split('/')[-1],name=str(n.get('description') or n.get('name','')),state=state))
        if values:
            states=[x['state'] for x in values]
            if '확인 필요' in states:state='확인 필요'
            elif '정상' in states:state='정상'
            elif set(states)<={'품절','단종'}:state='단종' if set(states)=={'단종'} else '품절'
            else:state='확인 필요'
            # A truncated option list must not stop an entire product. A group
            # needs a complete, identified list before all-out can be trusted.
            if state in BAD and '/g/' in url:
                lists=[n for n in nodes if n.get('@type')=='ItemList' and same(n.get('url',''))]
                codes=[x['code'] for x in values]
                complete=any(str(n.get('numberOfItems'))==str(len(codes)) for n in lists)
                if not complete or len(set(codes))!=len(codes):
                    return outcome('확인 필요','전체 옵션 수를 확인하지 못함 · 전체 판매 상태 유지',values)
            return outcome(state,'공급사 옵션별 구매 가능 상태 확인',values)
        if groups:
            return outcome(availability((groups[0].get('offers') or {}).get('availability')),'공급사 상품그룹 판매상태 확인')
        return outcome('확인 필요','공급사 상품번호와 옵션 상태를 확인하지 못함')
    return outcome('확인 필요','지원하지 않는 공급사')

class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self,*args):return None

def check_supplier(url):
    source,code,url=supplier_ref(url)
    try:
        req=request.Request(url,headers={'User-Agent':'WingDesk/'+__import__('core').VERSION,'Cache-Control':'no-cache'})
        with request.build_opener(NoRedirect()).open(req,timeout=20) as r:
            raw=r.read(4*1024*1024+1);charset=r.headers.get_content_charset()
            if len(raw)>4*1024*1024:return outcome('확인 필요','공급사 응답 크기가 허용 범위를 넘음')
        charset=charset or ('cp949' if source=='도매매' else 'utf-8')
        html=raw.decode(charset,errors='replace')
        return page_status(source,code,url,html)
    except error.HTTPError as ex:return outcome('확인 필요',f'공급사 HTTP {ex.code} · 삭제로 단정하지 않음')
    except Exception:return outcome('확인 필요','공급사 연결 또는 응답 오류 · 판매 상태 유지')

class StockWatch:
    def __init__(self,store,credentials,batches):
        self.store=store;self.credentials=credentials;self.batches=batches;self.lock=threading.RLock();self.active=False;self.cancel=threading.Event();self.plans={};self.closed=threading.Event()
        with self.store.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS stock_watch(product_id TEXT PRIMARY KEY,data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS stock_events(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id TEXT,data TEXT NOT NULL);''')
        self.thread=None
    def start_background(self):
        if self.thread is None:
            self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()
    def read(self,id):
        with self.store.connect() as db:r=db.execute('SELECT data FROM stock_watch WHERE product_id=?',(id,)).fetchone()
        return json.loads(r[0]) if r else dict(enabled=False,url='',policy='stop',status='미확인',result='')
    def write(self,id,v):
        with self.store.connect() as db:db.execute('INSERT OR REPLACE INTO stock_watch VALUES(?,?)',(id,json.dumps(v,ensure_ascii=False)))
    def event(self,id,kind,message):
        with self.store.connect() as db:
            db.execute('INSERT INTO stock_events(product_id,data) VALUES(?,?)',(id,json.dumps(dict(at=now(),kind=kind,message=message),ensure_ascii=False)))
    def state(self):
        rows=[]
        for p in self.store.products():
            if p.get('demo'):continue
            v=self.read(p['id']);rows.append(dict(id=p['id'],name=p['name'],source=p['source'],sku=p['sku'],remote_id=p['remote_id'],**v))
        with self.store.connect() as db:events=[dict(product_id=r['product_id'],**json.loads(r['data'])) for r in db.execute('SELECT * FROM stock_events ORDER BY id DESC LIMIT 100')]
        settings=self.store.settings()
        return dict(rows=rows,events=events,active=self.active,auto=bool(settings.get('stock_auto')),interval=int(settings.get('stock_interval',60)))
    def settings(self,p):
        interval=integer(p.get('interval',60),'확인 간격',10,1440)
        with self.lock,self.store.lock:
            s=self.store.settings();s.update(stock_auto=bool(p.get('auto')),stock_interval=interval);self.store.set_settings(s)
        return self.state()
    def configure(self,p):
        with self.lock,self.store.lock:
            if self.active:raise ValueError('품절 확인이 끝난 뒤 설정해 주세요.')
            product=self.store.get(p['id']);source,code,url=supplier_ref(p.get('url') or product.get('source_url'))
            if product['source'] not in (source,'도매꾹' if source=='도매매' else source):raise ValueError('상품의 공급사와 원본 주소가 다릅니다.')
            if str(product['sku']).upper()!=code.upper():raise ValueError('상품코드와 원본 주소의 상품번호가 다릅니다. 올바른 주소를 연결해 주세요.')
            policy=p.get('policy','stop')
            if policy not in ('stop','delete'):raise ValueError('공급사 삭제 시 처리 방식을 선택해 주세요.')
            old=self.read(product['id']);v=dict(old,enabled=bool(p.get('enabled')),url=url,policy=policy)
            if old.get('url')!=url or old.get('enabled')!=v['enabled']:
                v.update(status='미확인',confirmations=0,last_check_epoch=0,last_bad_epoch=0,result='주소 연결됨 · 첫 확인 대기')
            self.write(product['id'],v);return self.state()
    def start(self,ids=None):
        with self.lock:
            if self.closed.is_set():raise ValueError('프로그램이 종료 중입니다. 다시 실행한 뒤 확인해 주세요.')
            if self.active or self.batches.active:raise ValueError('진행 중인 작업이 끝난 뒤 확인해 주세요.')
            if ids is None:
                ids=[r['id'] for r in self.state()['rows'] if r.get('enabled')]
                ids.sort(key=lambda id:self.read(id).get('last_check_epoch',0));ids=ids[:20]
            if not isinstance(ids,list) or len(ids)>20 or len(set(ids))!=len(ids):raise ValueError('한 번에 최대 20개를 확인할 수 있습니다.')
            if not ids:raise ValueError('상품의 원본 주소를 연결하고 품절 관리를 켜 주세요.')
            for id in ids:
                self.store.get(id)
                if not self.read(id).get('enabled'):raise ValueError('먼저 해당 상품의 품절 관리를 켜 주세요.')
            self.active=True;self.cancel.clear();threading.Thread(target=self.run,args=(ids,),daemon=True).start()
        return {'ok':True}
    def loop(self):
        while not self.closed.wait(30):
            s=self.store.settings()
            if s.get('stock_auto') and not self.active and not self.batches.active:
                ready=[r for r in self.state()['rows'] if r.get('enabled') and time.time()-r.get('last_check_epoch',0)>=int(s.get('stock_interval',60))*60]
                if ready:
                    try:self.start([r['id'] for r in sorted(ready,key=lambda r:r.get('last_check_epoch',0))[:20]])
                    except ValueError:pass
    def run(self,ids):
        try:
            for id in ids:
                if self.cancel.is_set():break
                try:self.check_one(id)
                except Exception:
                    self.event(id,'확인 오류','공급사 확인을 완료하지 못함 · 매장 결과는 Wing에서 확인해 주세요.')
                self.cancel.wait(1)
        finally:
            with self.lock:self.active=False
    def check_one(self,id):
        with self.lock:
            v=self.read(id);url=v['url'];previous=dict(v)
        evidence=check_supplier(url);epoch=time.time();status=evidence['state']
        with self.lock,self.store.lock:
            v=self.read(id)
            if v.get('url')!=url or not v.get('enabled'):return
            count=0
            if status in BAD:
                if previous.get('status')==status and previous.get('confirmations',0)>0:
                    count=previous['confirmations']+(1 if epoch-previous.get('last_bad_epoch',0)>=600 else 0)
                else:count=1
            v.update(status=status,variants=evidence['variants'],reason=evidence['reason'],last_check=now(),last_check_epoch=epoch,confirmations=count)
            if count and (count>previous.get('confirmations',0) or previous.get('status')!=status):v['last_bad_epoch']=epoch
            if status=='정상':v['result']='판매 가능 · 중지한 상품은 Wing에서 재개해 주세요.' if v.get('operations') else '판매 가능'
            elif status in BAD:v['result']='같은 상태를 10분 이상 간격으로 한 번 더 확인한 뒤 처리' if count<2 else '공급사 상태 확인됨'
            else:v['result']='확인 필요 · 판매 상태 유지'
            self.write(id,v)
        self.event(id,'공급사 확인',status+' · '+evidence['reason'])
        if status in BAD and count>=2:
            self.mark_unavailable(id,status)
            if not self.store.get(id)['remote_id']:
                v=self.read(id);v['result']='공급사 '+status+' · 쿠팡 미등록 상품';self.write(id,v);return
            if v.get('delete_result')=='deleted':
                v['result']='쿠팡 매장 삭제 완료 · 로컬 이력 보관';self.write(id,v);return
            if not self.store.settings().get('stock_auto'):
                v['result']='공급사 '+status+' 확인됨 · 매장 처리 대기';self.write(id,v);return
            try:self.apply(id,delete=status=='삭제' and v.get('policy')=='delete',automatic=True)
            except Exception as ex:
                v=self.read(id);v['result']=str(ex) if isinstance(ex,(ValueError,RemoteRejected,Uncertain)) else '처리 오류 · Wing에서 확인해 주세요.';self.write(id,v);self.event(id,'처리 확인 필요',v['result'])
    def mark_unavailable(self,id,status):
        with self.store.lock,self.store.connect() as db:
            p=self.store.get(id);p['availability']='품절' if status=='품절' else '단종';p['stock']=0
            for o in p.get('options',[]):o.update(stock=0,status=p['availability'])
            for k in ('id','state','remote_id','created','updated','profit'):p.pop(k,None)
            db.execute('UPDATE products SET data=?,updated=? WHERE id=?',(json.dumps(p,ensure_ascii=False),now(),id))
    def remote_items(self,p,client):
        rid=str(p['remote_id'])
        if not re.fullmatch(r'[1-9]\d*',rid):raise ValueError('쿠팡 등록상품 ID를 확인해 주세요.')
        data=client.call('GET',BASE+'/seller-products/'+rid).get('data')
        if not isinstance(data,dict) or data.get('vendorId')!=self.store.settings().get('vendor_id'):raise ValueError('현재 판매자의 쿠팡 상품인지 확인할 수 없습니다.')
        rows=data.get('items');prefix=p['source']+':'+p['sku']+':'
        if not isinstance(rows,list) or not rows:raise ValueError('판매 승인 후 옵션 ID가 발급되면 처리할 수 있습니다.')
        ids=[]
        for row in rows:
            sku=str(row.get('externalVendorSku',''));item=str(row.get('vendorItemId',''))
            if not sku.startswith(prefix) or not sku[len(prefix):].isdigit() or not re.fullmatch(r'[1-9]\d*',item):raise ValueError('쿠팡 옵션과 공급사 상품코드가 일치하지 않습니다. Wing에서 확인해 주세요.')
            ids.append(item)
        if len(set(ids))!=len(ids):raise ValueError('쿠팡 옵션 ID가 중복되어 있습니다.')
        return ids
    def fingerprint(self,id):
        p=self.store.get(id);v=self.read(id)
        return hashlib.sha256(json.dumps([p['remote_id'],p['source'],p['sku'],v.get('url'),v.get('policy'),self.store.settings().get('vendor_id'),self.store.settings().get('wing_id')],ensure_ascii=False).encode()).hexdigest()
    def prepare(self,id,delete=False):
        with self.lock:
            if self.closed.is_set():raise ValueError('프로그램이 종료 중입니다. 다시 실행해 주세요.')
            if self.active or self.batches.active:raise ValueError('진행 중인 작업이 끝난 뒤 처리해 주세요.')
            p=self.store.get(id)
            if p.get('demo'):raise ValueError('연습 상품은 매장 변경을 할 수 없습니다.')
            ids=self.remote_items(p,Coupang(self.credentials));ticket=secrets.token_urlsafe(16);epoch=time.monotonic()
            self.plans={k:v for k,v in self.plans.items() if v[3]>epoch};self.plans[ticket]=(id,bool(delete),self.fingerprint(id),epoch+600)
            return dict(ticket=ticket,name=p['name'],sku=p['sku'],options=len(ids),delete=bool(delete))
    def execute(self,ticket):
        with self.lock:
            plan=self.plans.pop(ticket,None)
            if not plan or plan[3]<time.monotonic():raise ValueError('처리할 상품을 다시 확인해 주세요.')
            id,delete,fingerprint,_=plan
            if self.fingerprint(id)!=fingerprint:raise ValueError('상품 또는 판매자 설정이 바뀌었습니다. 처리 내용을 다시 확인해 주세요.')
            if self.active:raise ValueError('품절 확인 작업이 끝난 뒤 처리해 주세요.')
            return self.apply(id,delete)
    def apply(self,id,delete=False,automatic=False):
        with self.lock:
            if self.closed.is_set():raise ValueError('프로그램이 종료 중입니다. 다시 실행해 주세요.')
            if automatic and not self.store.settings().get('stock_auto'):
                v=self.read(id);v['result']='자동 반영 꺼짐 · 매장 처리 대기';self.write(id,v);return self.state()
            was_active=self.active;self.active=True
            try:
                # Freeze the seller and API keys until this action finishes.
                with self.store.lock,self.credentials.lock:return self._apply(id,delete)
            finally:self.active=was_active
    def _apply(self,id,delete=False):
        with self.lock:
            if self.batches.active:raise ValueError('쿠팡 등록 작업이 끝난 뒤 처리해 주세요.')
            p=self.store.get(id);v=self.read(id)
            if p.get('demo'):raise ValueError('연습 상품은 실제 매장 변경을 할 수 없습니다.')
            if v.get('delete_result') in ('sending','unknown','deleted'):raise ValueError('매장 삭제 결과는 Wing에서 확인해 주세요. 자동으로 다시 삭제하지 않습니다.')
            client=Coupang(self.credentials);ids=self.remote_items(p,client);operations=dict(v.get('operations',{}))
            for item in ids:
                state=client.call('GET',BASE+'/vendor-items/'+item+'/inventories').get('data')
                if not isinstance(state,dict) or not isinstance(state.get('onSale'),bool):raise Uncertain('쿠팡 옵션 판매상태를 확인하지 못했습니다.')
                if state['onSale']:
                    if operations.get(item) in ('sending','unknown'):raise Uncertain('이전 판매 중지 결과를 Wing에서 확인해 주세요.')
                    operations[item]='sending';v['operations']=operations;self.write(id,v)
                    try:client.call('PUT',BASE+'/vendor-items/'+item+'/sales/stop')
                    except RemoteRejected:
                        operations[item]='rejected';self.write(id,dict(v,operations=operations));raise
                    except Exception:
                        operations[item]='unknown';self.write(id,dict(v,operations=operations));raise Uncertain('판매 중지 결과를 확인하지 못했습니다. 결과 다시 확인을 눌러 주세요.')
                    verify=client.call('GET',BASE+'/vendor-items/'+item+'/inventories').get('data')
                    if not isinstance(verify,dict) or verify.get('onSale') is not False:raise Uncertain('판매 중지 후 상태가 확인되지 않았습니다. 결과 다시 확인을 눌러 주세요.')
                operations[item]='stopped';v['operations']=operations;self.write(id,v)
            self.store.state(id,'판매 중지됨');v['result']='쿠팡 판매 중지 완료';self.write(id,v);self.event(id,'판매 중지','쿠팡의 모든 연결 옵션 판매 중지 확인')
            if delete:
                v['delete_result']='sending';self.write(id,v)
                try:
                    result=client.call('DELETE',BASE+'/seller-products/'+str(p['remote_id']))
                    if str(result.get('data'))!=str(p['remote_id']):raise Uncertain('삭제된 등록상품 ID를 확인하지 못했습니다.')
                except RemoteRejected:
                    v['delete_result']='rejected';self.write(id,v);raise
                except Exception:
                    v['delete_result']='unknown';self.write(id,v);raise Uncertain('매장 삭제 결과를 확인하지 못했습니다. Wing에서 확인해 주세요. 자동으로 다시 삭제하지 않습니다.')
                v.update(delete_result='deleted',result='쿠팡 매장 삭제 완료 · 로컬 이력 보관');self.write(id,v);self.store.state(id,'매장 삭제됨');self.event(id,'매장 삭제','모든 옵션 판매 중지 후 쿠팡 상품 삭제 완료')
            return self.state()
