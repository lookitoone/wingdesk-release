'use strict';
(async()=>{
  let token='';
  try{token=sessionStorage.getItem('wingdesk-session')||'';}catch(e){return;}
  if(!token)return;
  try{
    const response=await fetch('/api/state',{headers:{'X-WingDesk-Session':token}});
    if(response.ok){
      location.replace('/?token='+encodeURIComponent(token)+location.hash);
    }else if(response.status===401){
      sessionStorage.removeItem('wingdesk-session');
    }
  }catch(e){/* Leave the visible restart instructions in place. */}
})();
