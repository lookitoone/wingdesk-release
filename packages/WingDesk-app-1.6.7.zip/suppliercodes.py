"""Import supplier identifiers without inventing saleable product data."""
from __future__ import annotations
import base64,re,secrets,threading,time,unicodedata
from pathlib import Path
from core import now,integer

SOURCE='오너클랜'
MAX_BYTES=1024*1024

def parse_codes(text):
    if not isinstance(text,str):raise ValueError('상품코드 텍스트를 입력하세요.')
    if len(text.encode('utf-8'))>MAX_BYTES:raise ValueError('상품코드 파일은 1MB 이하로 선택하세요.')
    text=unicodedata.normalize('NFKC',text.lstrip('\ufeff'))
    values=[v for v in re.split(r'[,;\s]+',text.strip()) if v]
    if len(values)>10000:raise ValueError('한 번에 10,000개 이하의 코드로 나누어 가져오세요.')
    codes=[];seen=set();duplicate=0;invalid=[];invalid_count=0
    for index,value in enumerate(values,1):
        if len(value)>=2 and value[0]==value[-1] and value[0] in ('"',"'"):value=value[1:-1]
        value=value.upper()
        if index==1 and value in ('상품코드','SKU','PRODUCTCODE'):continue
        if not re.fullmatch(r'W[A-Z0-9]{6}',value):
            invalid_count+=1
            if len(invalid)<50:invalid.append(dict(position=index,value=value[:100]))
            continue
        if value in seen:duplicate+=1;continue
        codes.append(value);seen.add(value)
    if not values:raise ValueError('상품코드를 입력하거나 TXT 파일을 선택하세요.')
    return dict(codes=codes,total=len(values),valid=len(codes),duplicate=duplicate,invalid_count=invalid_count,invalid=invalid)

def read_code_file(data,filename):
    if Path(str(filename)).suffix.lower()!='.txt':raise ValueError('상품코드 파일은 .txt를 선택하세요. 상품 정보 파일은 아래 XLSX·CSV 가져오기를 사용하세요.')
    if not isinstance(data,str) or len(data)>MAX_BYTES*4//3+8:raise ValueError('상품코드 파일은 1MB 이하로 선택하세요.')
    try:raw=base64.b64decode(data,validate=True)
    except (ValueError,TypeError):raise ValueError('파일을 다시 선택하세요.') from None
    if len(raw)>MAX_BYTES:raise ValueError('상품코드 파일은 1MB 이하로 선택하세요.')
    encodings=('utf-16',) if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else ('utf-8-sig','cp949')
    for encoding in encodings:
        try:return raw.decode(encoding)
        except UnicodeError:pass
    raise ValueError('UTF-8·CP949·UTF-16 텍스트 파일로 저장해 주세요.')

def product_url(code):return 'https://ownerclan.com/V2/product/view.php?selfcode='+code

class SupplierCodes:
    def __init__(self,store):
        self.store=store;self.lock=threading.RLock();self.previews={}
        with store.connect() as db:db.execute('CREATE TABLE IF NOT EXISTS supplier_codes(source TEXT,code TEXT,created TEXT,PRIMARY KEY(source,code))')
    def state(self,p=None):
        p=p or {};products={x['sku'].upper():x for x in self.store.products() if x['source']==SOURCE}
        with self.store.connect() as db:raw=db.execute('SELECT code,created FROM supplier_codes WHERE source=? ORDER BY rowid DESC',(SOURCE,)).fetchall()
        rows=[]
        for x in raw:
            product=products.get(x['code']);rows.append(dict(code=x['code'],source=SOURCE,url=product_url(x['code']),created=x['created'],product_id=product['id'] if product else '',name=product['name'] if product else '',status='상품 정보 있음' if product else '상품 정보 필요',remote_id=product.get('remote_id','') if product else ''))
        total=len(rows);pending=sum(not r['product_id'] for r in rows);q=str(p.get('search','')).strip().upper()
        rows=[r for r in rows if (not q or q in r['code'] or q in r['name'].upper()) and (not p.get('pending') or not r['product_id'])]
        page=integer(p.get('page',1),'페이지',1,100000);size=50
        return dict(rows=rows[(page-1)*size:page*size],total=total,pending=pending,matched=total-pending,filtered=len(rows),page=page,size=size)
    def preview(self,p):
        text=read_code_file(p.get('data'),p.get('filename')) if 'data' in p else p.get('text')
        result=parse_codes(text)
        with self.store.connect() as db:existing={r[0] for r in db.execute('SELECT code FROM supplier_codes WHERE source=?',(SOURCE,))}
        result['existing']=sum(c in existing for c in result['codes']);result['new']=len(result['codes'])-result['existing']
        with self.lock:
            epoch=time.monotonic();self.previews={k:v for k,v in self.previews.items() if v['expires']>epoch}
            if len(self.previews)>=8:self.previews.pop(next(iter(self.previews)))
            ticket=secrets.token_urlsafe(20);self.previews[ticket]=dict(codes=result['codes'],expires=epoch+900)
        return dict(result,ticket=ticket,sample=[dict(code=c,url=product_url(c)) for c in result['codes'][:50]])
    def commit(self,p):
        with self.lock,self.store.lock:
            plan=self.previews.pop(p.get('ticket'),None)
            if not plan or plan['expires']<time.monotonic():raise ValueError('상품코드를 다시 읽고 미리보기를 확인하세요.')
            if not plan['codes']:raise ValueError('보관할 수 있는 상품코드가 없습니다.')
            added=0
            with self.store.connect() as db:
                for code in plan['codes']:
                    added+=db.execute('INSERT OR IGNORE INTO supplier_codes VALUES(?,?,?)',(SOURCE,code,now())).rowcount
        return dict(added=added,duplicate=len(plan['codes'])-added,message=f'새 코드 {added}개 보관 · 기존 코드 {len(plan["codes"])-added}개 유지. 상품 정보는 별도로 입력하거나 공급사 엑셀로 가져오세요.')
